'use strict';

function openSidebar() {
  document.getElementById('sidebar').classList.add('open');
  document.getElementById('sidebarOverlay').classList.add('show');
  document.getElementById('hamburgerBtn').setAttribute('aria-expanded', 'true');
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('show');
  document.getElementById('hamburgerBtn').setAttribute('aria-expanded', 'false');
}

document.addEventListener('DOMContentLoaded', () => {

  // ── Modals ──────────────────────────────────────────────────
  document.querySelectorAll('[data-modal-open]').forEach(btn => {
    btn.addEventListener('click', () => {
      const m = document.getElementById(btn.dataset.modalOpen);
      if (m) { m.style.display = 'flex'; m.querySelector('.form-control')?.focus(); }
    });
  });
  document.querySelectorAll('[data-modal-close]').forEach(btn => {
    btn.addEventListener('click', () => btn.closest('.modal-overlay').style.display = 'none');
  });
  document.querySelectorAll('.modal-overlay').forEach(ov => {
    ov.addEventListener('click', e => { if (e.target === ov) ov.style.display = 'none'; });
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') document.querySelectorAll('.modal-overlay').forEach(o => o.style.display = 'none');
  });

  // ── Type chips ───────────────────────────────────────────────
  document.querySelectorAll('.type-chips').forEach(group => {
    group.querySelectorAll('.type-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        group.querySelectorAll('.type-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        const inp = group.dataset.input;
        if (inp) { const el = document.getElementById(inp); if (el) el.value = chip.dataset.value || chip.textContent.trim(); }
      });
    });
  });

  // ── Attendance live counter ──────────────────────────────────
  function updateAttCounter() {
    const total   = document.querySelectorAll('.att-btn[data-status="present"]').length;
    const present = document.querySelectorAll('.att-btn.present').length;
    const el = document.getElementById('att-counter');
    if (el) el.textContent = present + ' / ' + total;
    const pct = document.getElementById('att-pct');
    if (pct && total) pct.textContent = Math.round(present / total * 100) + '%';
    const bar = document.getElementById('att-bar');
    if (bar && total) bar.style.width = Math.round(present / total * 100) + '%';
  }

  document.querySelectorAll('.att-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const row = btn.dataset.row;
      const status = btn.dataset.status;
      document.querySelectorAll(`.att-btn[data-row="${row}"]`).forEach(b => b.classList.remove('present', 'absent'));
      btn.classList.add(status);
      const inp = document.querySelector(`input[name="attendance[${row}]"]`);
      if (inp) inp.value = status;
      updateAttCounter();
      const tr = btn.closest('tr') || btn.closest('.stu-row');
      if (tr) {
        tr.style.background = status === 'present' ? 'var(--color-success-bg)' : status === 'absent' ? 'var(--color-danger-bg)' : '';
      }
    });
  });

  document.getElementById('markAllPresent')?.addEventListener('click', () => {
    document.querySelectorAll('.att-btn[data-status="present"]').forEach(b => b.click());
  });
  document.getElementById('markAllAbsent')?.addEventListener('click', () => {
    document.querySelectorAll('.att-btn[data-status="absent"]').forEach(b => b.click());
  });

  updateAttCounter();

  // ── Auto-dismiss flash ───────────────────────────────────────
  setTimeout(() => {
    document.querySelectorAll('.alert').forEach(el => {
      el.style.transition = 'opacity .5s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 500);
    });
  }, 3500);

  // ── Table search ─────────────────────────────────────────────
  document.querySelectorAll('[data-search-table]').forEach(inp => {
    inp.addEventListener('input', () => {
      const q = inp.value.toLowerCase();
      document.querySelectorAll(`#${inp.dataset.searchTable} tbody tr, #${inp.dataset.searchTable} .stu-row`).forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  });

  // ── Collapsible group rows ────────────────────────────────────
  document.querySelectorAll('[data-toggle-target]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = document.getElementById(btn.dataset.toggleTarget);
      if (!target) return;
      const open = target.style.display !== 'none';
      target.style.display = open ? 'none' : '';
      btn.setAttribute('aria-expanded', !open);
      const icon = btn.querySelector('.toggle-icon');
      if (icon) icon.textContent = open ? '▼' : '▲';
    });
  });

});
