# תפנית – מערכת ניהול תוכניות נוער

> **URL:** https://net.tafnit-il.org.il  
> **DB:** `netafnit` | **משתמש DB:** `nettafnitadmin`  
> **PHP:** 8.1+ | **MySQL:** 5.7+ / MariaDB 10.4+

---

## 📁 מבנה התיקיות

```
tafnit/
├── config/
│   ├── app.php          ← קבועי אפליקציה (שם, URL, תפקידים)
│   ├── database.php     ← חיבור PDO ל-netafnit
│   ├── schema.sql       ← יצירת כל הטבלאות
│   └── seed.sql         ← נתוני ברירת מחדל + משתמשים
├── includes/
│   ├── auth.php         ← session, CSRF, requireLogin/Role
│   ├── helpers.php      ← h(), formatDate(), auditLog()...
│   ├── header.php       ← HTML head + sidebar + topbar
│   └── footer.php       ← סגירת HTML
├── assets/
│   ├── css/
│   │   ├── variables.css
│   │   ├── base.css
│   │   ├── layout.css
│   │   └── components.css
│   └── js/app.js
├── pages/
│   ├── students.php        ← רשימה, הוספה, הקפאה
│   ├── student_detail.php  ← תיק חניך + נוכחות + metadata
│   ├── student_edit.php    ← עריכה + שדות metadata
│   ├── activities.php      ← רשימה + יצירה
│   ├── activity_detail.php ← סימון נוכחות + הערות
│   ├── groups.php          ← ניהול קבוצות + שיוך חניכים
│   ├── my_group.php        ← תצוגת מדריך
│   ├── reports.php         ← דוח נוכחות + CSV
│   ├── programs.php        ← ניהול תוכניות (admin)
│   ├── users.php           ← ניהול משתמשים (admin)
│   ├── activity_types.php  ← סוגי פעילות + metadata fields
│   ├── metadata.php        ← שדות מותאמים לתוכנית
│   └── audit.php           ← יומן פעולות
├── index.php    ← מסך כניסה
├── logout.php
├── dashboard.php
├── .htaccess    ← Apache config
└── .gitignore
```

---

## 🚀 התקנה מלאה

### שלב 1 – צור מסד נתונים

בלוח הבקרה של הספק (cPanel / phpMyAdmin):

```sql
CREATE DATABASE netafnit CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'nettafnitadmin'@'localhost' IDENTIFIED BY 'STRONG_PASSWORD_HERE';
GRANT ALL PRIVILEGES ON netafnit.* TO 'nettafnitadmin'@'localhost';
FLUSH PRIVILEGES;
```

### שלב 2 – הרץ את הסכמה

```bash
mysql -u nettafnitadmin -p netafnit < config/schema.sql
mysql -u nettafnitadmin -p netafnit < config/seed.sql
```

### שלב 3 – עדכן את הסיסמה ב-config/database.php

```php
define('DB_PASS', 'STRONG_PASSWORD_HERE');
```

**⚠️ אל תעלה config/database.php עם הסיסמה ל-GitHub!**  
השתמש ב-`.env` או הגדר אותה ישירות בשרת בלבד.

### שלב 4 – העלה ל-GitHub והעבר לשרת

```bash
# מחשב מקומי
git init
git add .
git commit -m "Initial commit – tafnit v1.0"
git remote add origin https://github.com/YOUR_ORG/tafnit.git
git push -u origin main

# בשרת
cd /var/www/net.tafnit-il.org.il
git clone https://github.com/YOUR_ORG/tafnit.git .
# ערוך config/database.php בשרת (לא דרך git!)
nano config/database.php
```

### שלב 5 – הגדרת Apache

```apache
<VirtualHost *:443>
    ServerName net.tafnit-il.org.il
    DocumentRoot /var/www/net.tafnit-il.org.il

    <Directory /var/www/net.tafnit-il.org.il>
        AllowOverride All
        Require all granted
    </Directory>

    SSLEngine on
    SSLCertificateFile    /etc/ssl/certs/tafnit.crt
    SSLCertificateKeyFile /etc/ssl/private/tafnit.key

    ErrorLog  /var/log/apache2/tafnit_error.log
    CustomLog /var/log/apache2/tafnit_access.log combined
</VirtualHost>
```

---

## 👤 משתמשי ברירת מחדל (seed)

| שם משתמש    | סיסמה       | תפקיד    |
|-------------|-------------|----------|
| `admin`     | `Admin1234!` | מנהל     |
| `coordinator`| `Admin1234!`| רכז      |
| `instructor1`| `Admin1234!`| מדריך    |
| `instructor2`| `Admin1234!`| מדריך    |

**⚠️ שנה את הסיסמאות מיד לאחר ההתקנה!**

---

## 🗄️ מבנה מסד הנתונים (13 טבלאות)

| טבלה | תיאור |
|------|-------|
| `users` | משתמשי מערכת (admin / coordinator / instructor) |
| `programs` | תוכניות (מנהיגות, קהילה...) |
| `groups` | קבוצות בתוך תוכנית |
| `students` | חניכים |
| `group_student` | שיוך חניך לקבוצה |
| `metadata_fields` | שדות מותאמים לתוכנית |
| `metadata_values` | ערכי metadata לחניך |
| `activity_types` | סוגי פעילות + הגדרות |
| `activity_type_fields` | שדות metadata לסוג פעילות |
| `activities` | פעילויות (תאריך, שעה, מיקום) |
| `activity_students` | נוכחות לפעילות |
| `activity_field_values` | metadata לחניך בפעילות |
| `audit_logs` | יומן פעולות |

---

## 🔒 אבטחה

- כל טפסים מוגנים ב-CSRF token
- PDO prepared statements – ללא SQL injection
- bcrypt לסיסמאות
- Session timeout אחרי 8 שעות
- `config/` ו-`includes/` חסומים ב-.htaccess
- Redirect לגרסה HTTPS תמיד

---

## 📱 Mobile First

- עברית RTL מלאה (`direction: rtl`)
- Sidebar נפתח/נסגר במובייל
- טבלאות הופכות ל-cards במסכים < 600px
- Touch targets ≥ 40px
- Bottom sheet modals
- פונט Heebo (Google Fonts) מותאם לעברית

---

## 🔄 עדכונים עתידיים

```bash
# בשרת
cd /var/www/net.tafnit-il.org.il
git pull origin main
# אין צורך ב-migrate – הסכמה לא משתנה אוטומטית
```

אם שינית את `schema.sql` – הרץ ידנית את ה-ALTER TABLE הרלוונטיים.

---

גרסה 1.0 | תפנית – מערכת ניהול תוכניות נוער
