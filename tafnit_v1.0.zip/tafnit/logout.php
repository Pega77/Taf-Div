<?php
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/includes/auth.php';
startSession();
if (!empty($_SESSION['user_id'])) {
    require_once __DIR__ . '/config/database.php';
    require_once __DIR__ . '/includes/helpers.php';
    try { auditLog(getDB(), $_SESSION['user_id'], 'logout', 'user', $_SESSION['user_id']); } catch(Throwable) {}
}
session_unset();
session_destroy();
header('Location: ' . APP_URL . '/index.php');
exit;
