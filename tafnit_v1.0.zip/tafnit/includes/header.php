<?php
// includes/header.php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
requireLogin();
$_user  = currentUser();
$_flash = getFlash();
$activePage = $activePage ?? '';
$pageTitle  = $pageTitle  ?? APP_NAME;
?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#2E7D32">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<title><?= h($pageTitle) ?> – <?= h(APP_NAME) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Heebo:wght@300;400;500;600;700&family=Secular+One&display=swap">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/variables.css">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/base.css">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/layout.css">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/components.css">
</head>
<body>

<!-- ══ Mobile overlay when sidebar open ══ -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

<div class="app-shell">

  <!-- ══ SIDEBAR ══ -->
  <aside class="sidebar" id="sidebar" role="navigation" aria-label="תפריט ראשי">
    <div class="sidebar-header">
      <img src="<?= h(APP_LOGO) ?>" alt="לוגו תפנית" class="sidebar-logo-img"
           onerror="this.style.display='none';document.getElementById('sidebar-logo-fallback').style.display='flex'">
      <div id="sidebar-logo-fallback" class="sidebar-logo-fallback" style="display:none">
        <span>תפנית</span>
      </div>
      <button class="sidebar-close-btn" onclick="closeSidebar()" aria-label="סגור תפריט">✕</button>
    </div>

    <nav class="sidebar-nav">

      <?php if (!isInstructor()): ?>
      <div class="nav-section">כללי</div>
      <a href="<?= APP_URL ?>/dashboard.php"
         class="nav-item<?= $activePage === 'dashboard' ? ' active' : '' ?>">
        <i class="nav-icon">📊</i><span>דשבורד</span>
      </a>
      <?php endif; ?>

      <?php if (isAdmin()): ?>
      <a href="<?= APP_URL ?>/pages/programs.php"
         class="nav-item<?= $activePage === 'programs' ? ' active' : '' ?>">
        <i class="nav-icon">🗂️</i><span>תוכניות</span>
      </a>
      <?php endif; ?>

      <?php if (!isInstructor()): ?>
      <a href="<?= APP_URL ?>/pages/groups.php"
         class="nav-item<?= $activePage === 'groups' ? ' active' : '' ?>">
        <i class="nav-icon">👥</i><span>קבוצות</span>
      </a>
      <a href="<?= APP_URL ?>/pages/students.php"
         class="nav-item<?= $activePage === 'students' ? ' active' : '' ?>">
        <i class="nav-icon">🎒</i><span>חניכים</span>
      </a>
      <a href="<?= APP_URL ?>/pages/activities.php"
         class="nav-item<?= $activePage === 'activities' ? ' active' : '' ?>">
        <i class="nav-icon">📅</i><span>פעילויות</span>
      </a>
      <a href="<?= APP_URL ?>/pages/reports.php"
         class="nav-item<?= $activePage === 'reports' ? ' active' : '' ?>">
        <i class="nav-icon">📈</i><span>דוחות</span>
      </a>
      <?php endif; ?>

      <?php if (isInstructor()): ?>
      <div class="nav-section">הקבוצה שלי</div>
      <a href="<?= APP_URL ?>/pages/my_group.php"
         class="nav-item<?= $activePage === 'my_group' ? ' active' : '' ?>">
        <i class="nav-icon">👥</i><span>הקבוצה שלי</span>
      </a>
      <a href="<?= APP_URL ?>/pages/activities.php"
         class="nav-item<?= $activePage === 'activities' ? ' active' : '' ?>">
        <i class="nav-icon">📅</i><span>פעילויות</span>
      </a>
      <?php endif; ?>

      <?php if (isAdmin()): ?>
      <div class="nav-section">הגדרות</div>
      <a href="<?= APP_URL ?>/pages/users.php"
         class="nav-item<?= $activePage === 'users' ? ' active' : '' ?>">
        <i class="nav-icon">👤</i><span>משתמשים</span>
      </a>
      <a href="<?= APP_URL ?>/pages/activity_types.php"
         class="nav-item<?= $activePage === 'activity_types' ? ' active' : '' ?>">
        <i class="nav-icon">🏷️</i><span>סוגי פעילות</span>
      </a>
      <a href="<?= APP_URL ?>/pages/metadata.php"
         class="nav-item<?= $activePage === 'metadata' ? ' active' : '' ?>">
        <i class="nav-icon">🔧</i><span>שדות מותאמים</span>
      </a>
      <a href="<?= APP_URL ?>/pages/audit.php"
         class="nav-item<?= $activePage === 'audit' ? ' active' : '' ?>">
        <i class="nav-icon">📋</i><span>יומן פעולות</span>
      </a>
      <?php endif; ?>

    </nav>

    <div class="sidebar-footer">
      <div class="user-card">
        <div class="user-avatar"><?= h(initials($_user['name'])) ?></div>
        <div class="user-info">
          <div class="user-name"><?= h($_user['name']) ?></div>
          <div class="user-role"><?= h(roleLabel($_user['role'])) ?></div>
        </div>
        <a href="<?= APP_URL ?>/logout.php" class="logout-btn" title="יציאה">🚪</a>
      </div>
    </div>
  </aside>

  <!-- ══ MAIN AREA ══ -->
  <div class="main-area" id="mainArea">

    <!-- Topbar -->
    <header class="topbar" role="banner">
      <div class="topbar-left">
        <button class="hamburger-btn" onclick="openSidebar()" aria-label="פתח תפריט" aria-expanded="false" id="hamburgerBtn">
          <span></span><span></span><span></span>
        </button>
        <img src="<?= h(APP_LOGO) ?>" alt="לוגו" class="topbar-logo"
             onerror="this.style.display='none'">
        <h1 class="topbar-title"><?= h($pageTitle) ?></h1>
      </div>
      <div class="topbar-right">
        <a href="<?= APP_URL ?>/logout.php" class="topbar-logout" aria-label="יציאה">🚪</a>
      </div>
    </header>

    <?php if ($_flash): ?>
    <div class="flash-wrap" role="alert">
      <div class="alert alert-<?= h($_flash['type']) ?>"><?= h($_flash['message']) ?></div>
    </div>
    <?php endif; ?>

    <!-- Page content -->
    <main class="page-content" id="pageContent">
