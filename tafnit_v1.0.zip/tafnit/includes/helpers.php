<?php
// includes/helpers.php

function h(mixed $v): string {
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function sanitize(string $v): string {
    return trim(strip_tags($v));
}

function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

function formatDate(?string $d, string $fmt = 'd/m/Y'): string {
    if (!$d) return '—';
    try { return (new DateTime($d))->format($fmt); }
    catch (Exception) { return $d; }
}

function formatTime(?string $t): string {
    if (!$t) return '';
    return substr($t, 0, 5);
}

function roleLabel(string $role): string {
    return ROLE_LABELS[$role] ?? $role;
}

function initials(string $name): string {
    $parts = explode(' ', trim($name));
    if (count($parts) >= 2) return mb_substr($parts[0], 0, 1) . mb_substr($parts[1], 0, 1);
    return mb_substr($name, 0, 2);
}

function attendanceColor(int $pct): string {
    if ($pct >= 75) return 'var(--color-success)';
    if ($pct >= 50) return 'var(--color-warning)';
    return 'var(--color-danger)';
}

function statusBadge(string $status): string {
    return match($status) {
        'active'   => '<span class="badge badge-success">פעיל</span>',
        'frozen'   => '<span class="badge badge-warning">מוקפא</span>',
        'inactive' => '<span class="badge badge-muted">לא פעיל</span>',
        default    => '<span class="badge">' . h($status) . '</span>',
    };
}

function genderLabel(?string $g): string {
    return match($g) {
        'male'   => 'זכר',
        'female' => 'נקבה',
        'other'  => 'אחר',
        default  => '—',
    };
}

function auditLog(PDO $db, int $userId, string $action, string $entityType, int $entityId = 0, ?array $details = null): void {
    try {
        $db->prepare("INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address) VALUES (?,?,?,?,?,?)")
           ->execute([$userId, $action, $entityType, $entityId, $details ? json_encode($details, JSON_UNESCAPED_UNICODE) : null, $_SERVER['REMOTE_ADDR'] ?? null]);
    } catch (Throwable) {}
}
