    </main><!-- /page-content -->
  </div><!-- /main-area -->
</div><!-- /app-shell -->

<?php
// APP_URL כבר מוגדר מ-config/app.php שנטען לפני header.php
echo '<script src="' . APP_URL . '/assets/js/app.js"></script>';
?>
</body>
</html>
