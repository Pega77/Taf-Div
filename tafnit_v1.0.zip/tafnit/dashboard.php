<?php
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

requireLogin();
requireRole([ROLE_ADMIN, ROLE_COORDINATOR]);
$db = getDB();

$totalStudents   = (int)$db->query("SELECT COUNT(*) FROM students WHERE status='active' AND deleted_at IS NULL")->fetchColumn();
$frozenStudents  = (int)$db->query("SELECT COUNT(*) FROM students WHERE status='frozen'")->fetchColumn();
$totalGroups     = (int)$db->query("SELECT COUNT(*) FROM `groups` WHERE status='active'")->fetchColumn();
$monthActivities = (int)$db->query("SELECT COUNT(*) FROM activities WHERE deleted_at IS NULL AND MONTH(activity_date)=MONTH(CURDATE()) AND YEAR(activity_date)=YEAR(CURDATE())")->fetchColumn();

$avgAtt = (int)($db->query("SELECT ROUND(100*SUM(participation_status='present')/NULLIF(COUNT(*),0)) FROM activity_students")->fetchColumn() ?? 0);

$recentActs = $db->query("
    SELECT a.id, a.activity_date, a.activity_time, g.name AS group_name,
           p.name AS program_name, at.name AS type_name, at.color,
           COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS pc,
           COUNT(acs.id) AS tc
    FROM activities a
    JOIN `groups` g ON g.id=a.group_id
    JOIN programs p ON p.id=a.program_id
    JOIN activity_types at ON at.id=a.activity_type_id
    LEFT JOIN activity_students acs ON acs.activity_id=a.id
    WHERE a.deleted_at IS NULL
    GROUP BY a.id ORDER BY a.activity_date DESC, a.created_at DESC LIMIT 8
")->fetchAll();

$lowAtt = $db->query("
    SELECT g.id, g.name, p.name AS prog,
           ROUND(100*SUM(acs.participation_status='present')/NULLIF(COUNT(acs.id),0)) AS pct
    FROM `groups` g
    JOIN programs p ON p.id=g.program_id
    LEFT JOIN activities a ON a.group_id=g.id AND a.deleted_at IS NULL
    LEFT JOIN activity_students acs ON acs.activity_id=a.id
    WHERE g.status='active'
    GROUP BY g.id HAVING pct IS NOT NULL AND pct < 70
    ORDER BY pct ASC LIMIT 5
")->fetchAll();

$pageTitle = 'דשבורד'; $activePage = 'dashboard';
require_once __DIR__ . '/includes/header.php';
?>
<div class="stats-grid">
  <div class="stat-card"><div class="stat-icon">🎒</div><div class="stat-value"><?= $totalStudents ?></div><div class="stat-label">חניכים פעילים</div></div>
  <div class="stat-card"><div class="stat-icon">👥</div><div class="stat-value"><?= $totalGroups ?></div><div class="stat-label">קבוצות</div></div>
  <div class="stat-card"><div class="stat-icon">📅</div><div class="stat-value"><?= $monthActivities ?></div><div class="stat-label">פעילויות החודש</div></div>
  <div class="stat-card"><div class="stat-icon">✅</div><div class="stat-value"><?= $avgAtt ?>%</div><div class="stat-label">נוכחות ממוצעת</div></div>
</div>

<?php if ($frozenStudents): ?>
<div class="alert alert-warning">❄️ <?= $frozenStudents ?> חניכים מוקפאים – <a href="<?= APP_URL ?>/pages/students.php?status=frozen">צפה</a></div>
<?php endif; ?>

<div class="card">
  <div class="card-header">
    <span class="card-title">פעילויות אחרונות</span>
    <a href="<?= APP_URL ?>/pages/activities.php" class="btn btn-ghost btn-sm">הכל ←</a>
  </div>
  <?php if ($recentActs): ?>
  <div class="table-wrapper mobile-cards">
    <table class="data-table" id="dashTable">
      <thead><tr><th>תאריך</th><th>קבוצה</th><th>סוג</th><th>נוכחות</th></tr></thead>
      <tbody>
        <?php foreach ($recentActs as $a): ?>
        <?php $pct = $a['tc'] ? round($a['pc']/$a['tc']*100) : 0; ?>
        <tr>
          <td data-label="תאריך"><?= formatDate($a['activity_date']) ?><?= $a['activity_time'] ? ' ' . formatTime($a['activity_time']) : '' ?></td>
          <td data-label="קבוצה"><a href="<?= APP_URL ?>/pages/activity_detail.php?id=<?= $a['id'] ?>"><?= h($a['group_name']) ?></a></td>
          <td data-label="סוג"><span class="badge badge-primary"><?= h($a['type_name']) ?></span></td>
          <td data-label="נוכחות">
            <div style="display:flex;align-items:center;gap:8px">
              <div class="progress-bar" style="width:70px"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
              <span style="font-size:.8rem;font-weight:600;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php else: ?>
  <div class="empty-state"><div class="empty-icon">📅</div><p>אין פעילויות עדיין</p></div>
  <?php endif; ?>
</div>

<?php if ($lowAtt): ?>
<div class="card">
  <div class="card-title" style="color:var(--color-danger);margin-bottom:12px">⚠️ קבוצות עם נוכחות נמוכה</div>
  <?php foreach ($lowAtt as $g): ?>
  <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--color-border)">
    <div>
      <a href="<?= APP_URL ?>/pages/groups.php" style="font-weight:500;font-size:.9rem"><?= h($g['name']) ?></a>
      <div style="font-size:.75rem;color:var(--color-text-muted)"><?= h($g['prog']) ?></div>
    </div>
    <span style="font-weight:700;color:<?= attendanceColor($g['pct']) ?>"><?= $g['pct'] ?>%</span>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-title" style="margin-bottom:12px">פעולות מהירות</div>
  <div style="display:flex;flex-direction:column;gap:8px">
    <a href="<?= APP_URL ?>/pages/activities.php?new=1" class="btn btn-primary btn-full">➕ פעילות חדשה</a>
    <a href="<?= APP_URL ?>/pages/students.php?new=1"   class="btn btn-secondary btn-full">🎒 חניך חדש</a>
    <a href="<?= APP_URL ?>/pages/reports.php"           class="btn btn-secondary btn-full">📈 הפקת דוח</a>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
