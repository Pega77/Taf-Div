<?php
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

startSession();
if (!empty($_SESSION['user_id'])) {
    redirect(ROLE_DEFAULT_PAGE[$_SESSION['user_role']] ?? APP_URL . '/dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $db   = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE username=? AND is_active=1 AND deleted_at IS NULL LIMIT 1");
        $stmt->execute([$username]);
        $u = $stmt->fetch();

        if ($u && password_verify($password, $u['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user_id']       = $u['id'];
            $_SESSION['user_name']     = $u['full_name'];
            $_SESSION['user_role']     = $u['role'];
            $_SESSION['last_activity'] = time();

            if ($u['role'] === ROLE_INSTRUCTOR) {
                $g = $db->prepare("SELECT id, program_id FROM `groups` WHERE instructor_user_id=? AND status='active' LIMIT 1");
                $g->execute([$u['id']]);
                $g = $g->fetch();
                $_SESSION['group_id']   = $g['id']         ?? null;
                $_SESSION['program_id'] = $g['program_id'] ?? null;
            }

            auditLog($db, $u['id'], 'login', 'user', $u['id']);
            $redirect = $_GET['redirect'] ?? (ROLE_DEFAULT_PAGE[$u['role']] ?? APP_URL . '/dashboard.php');
            redirect($redirect);
        } else {
            $error = 'שם משתמש או סיסמה שגויים';
        }
    } else {
        $error = 'יש למלא שם משתמש וסיסמה';
    }
}
?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="theme-color" content="#2E7D32">
<title>כניסה – <?= h(APP_NAME) ?></title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Secular+One&display=swap">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/variables.css">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/base.css">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/layout.css">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/components.css">
</head>
<body>
<div class="login-page">
  <div class="login-box">
    <div class="login-logo">
      <img src="<?= h(APP_LOGO) ?>" alt="לוגו תפנית"
           onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
      <div style="display:none;font-family:var(--font-title);font-size:1.6rem;color:var(--brand);text-align:center">תפנית</div>
    </div>
    <h1 class="login-title">ברוכים הבאים</h1>
    <p class="login-sub">מערכת ניהול תוכניות – <?= h(APP_NAME) ?></p>

    <?php if (!empty($_GET['expired'])): ?>
    <div class="alert alert-warning">פג תוקף הסשן, אנא התחבר מחדש</div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-danger" role="alert"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
      <div class="form-group">
        <label class="form-label" for="username">שם משתמש</label>
        <input type="text" id="username" name="username" class="form-control"
               value="<?= h($_POST['username'] ?? '') ?>"
               autocomplete="username" autofocus required>
      </div>
      <div class="form-group">
        <label class="form-label" for="password">סיסמה</label>
        <input type="password" id="password" name="password" class="form-control"
               autocomplete="current-password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-full" style="margin-top:4px;min-height:46px;font-size:1rem">
        כניסה למערכת
      </button>
    </form>

    <p style="text-align:center;margin-top:16px;font-size:.78rem;color:var(--color-text-light)">
      <?= h(APP_NAME) ?> · גרסה <?= h(APP_VERSION) ?>
    </p>
  </div>
</div>
</body>
</html>
