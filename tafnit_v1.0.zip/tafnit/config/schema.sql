-- =============================================================
-- netafnit – schema.sql
-- DB:   netafnit
-- User: nettafnitadmin
-- Run:  mysql -u nettafnitadmin -p netafnit < config/schema.sql
-- =============================================================

CREATE DATABASE IF NOT EXISTS netafnit
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE netafnit;

-- ─── users ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name       VARCHAR(150) NOT NULL,
    username        VARCHAR(100) NOT NULL UNIQUE,
    phone           VARCHAR(30)  NULL,
    password_hash   VARCHAR(255) NOT NULL,
    role            ENUM('admin','coordinator','instructor') NOT NULL,
    is_active       TINYINT(1)   NOT NULL DEFAULT 1,
    deleted_at      TIMESTAMP    NULL DEFAULT NULL,
    created_at      TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── programs ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS programs (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(150) NOT NULL,
    status     ENUM('active','inactive') NOT NULL DEFAULT 'active',
    deleted_at TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── groups ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `groups` (
    id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    program_id         BIGINT UNSIGNED NOT NULL,
    name               VARCHAR(150) NOT NULL,
    instructor_user_id BIGINT UNSIGNED NOT NULL,
    location           VARCHAR(200) NULL,
    status             ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at         TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_groups_program    (program_id),
    INDEX idx_groups_instructor (instructor_user_id),
    CONSTRAINT fk_groups_program    FOREIGN KEY (program_id)         REFERENCES programs(id),
    CONSTRAINT fk_groups_instructor FOREIGN KEY (instructor_user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── students ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS students (
    id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    national_id    VARCHAR(20)  NOT NULL UNIQUE,
    full_name      VARCHAR(150) NOT NULL,
    gender         ENUM('male','female','other') NULL,
    birth_date     DATE         NULL,
    phone          VARCHAR(30)  NULL,
    school         VARCHAR(150) NULL,
    grade          VARCHAR(20)  NULL,
    status         ENUM('active','frozen') NOT NULL DEFAULT 'active',
    freeze_reason  VARCHAR(255) NULL,
    frozen_at      DATETIME     NULL,
    deleted_at     TIMESTAMP    NULL DEFAULT NULL,
    created_at     TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP    NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_students_status (status),
    INDEX idx_students_name   (full_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── group_student ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS group_student (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    group_id   BIGINT UNSIGNED NOT NULL,
    student_id BIGINT UNSIGNED NOT NULL,
    is_active  TINYINT(1)      NOT NULL DEFAULT 1,
    joined_at  DATE            NULL,
    left_at    DATE            NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_gs_group   (group_id),
    INDEX idx_gs_student (student_id),
    CONSTRAINT fk_gs_group   FOREIGN KEY (group_id)   REFERENCES `groups`(id),
    CONSTRAINT fk_gs_student FOREIGN KEY (student_id) REFERENCES students(id),
    UNIQUE KEY uq_gs_active (student_id, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── metadata_fields ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS metadata_fields (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    program_id   BIGINT UNSIGNED NOT NULL,
    field_key    VARCHAR(100) NOT NULL,
    field_label  VARCHAR(150) NOT NULL,
    field_type   ENUM('text','number','date','boolean','select') NOT NULL,
    is_required  TINYINT(1) NOT NULL DEFAULT 0,
    options_json JSON       NULL,
    sort_order   INT        NOT NULL DEFAULT 0,
    is_active    TINYINT(1) NOT NULL DEFAULT 1,
    created_at   TIMESTAMP  NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP  NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_mf_program FOREIGN KEY (program_id) REFERENCES programs(id),
    UNIQUE KEY uq_program_field_key (program_id, field_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── metadata_values ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS metadata_values (
    id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id        BIGINT UNSIGNED NOT NULL,
    metadata_field_id BIGINT UNSIGNED NOT NULL,
    value_text        TEXT           NULL,
    value_number      DECIMAL(12,2)  NULL,
    value_date        DATE           NULL,
    value_boolean     TINYINT(1)     NULL,
    value_json        JSON           NULL,
    created_at        TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_mv_student FOREIGN KEY (student_id)        REFERENCES students(id),
    CONSTRAINT fk_mv_field   FOREIGN KEY (metadata_field_id) REFERENCES metadata_fields(id),
    UNIQUE KEY uq_student_field (student_id, metadata_field_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── activity_types ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS activity_types (
    id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name              VARCHAR(100) NOT NULL,
    icon              VARCHAR(60)  NULL DEFAULT 'calendar',
    color             VARCHAR(20)  NULL DEFAULT '#2E7D32',
    requires_notes    TINYINT(1)   NOT NULL DEFAULT 0,
    requires_attendance TINYINT(1) NOT NULL DEFAULT 1,
    is_active         TINYINT(1)   NOT NULL DEFAULT 1,
    sort_order        INT          NOT NULL DEFAULT 0,
    created_at        TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── activity_type_fields (metadata per activity type) ──────
CREATE TABLE IF NOT EXISTS activity_type_fields (
    id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    activity_type_id BIGINT UNSIGNED NOT NULL,
    field_key        VARCHAR(100) NOT NULL,
    field_label      VARCHAR(150) NOT NULL,
    field_type       ENUM('text','number','date','boolean','select') NOT NULL,
    is_required      TINYINT(1) NOT NULL DEFAULT 0,
    options_json     JSON       NULL,
    sort_order       INT        NOT NULL DEFAULT 0,
    is_active        TINYINT(1) NOT NULL DEFAULT 1,
    created_at       TIMESTAMP  NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_atf_type FOREIGN KEY (activity_type_id) REFERENCES activity_types(id),
    UNIQUE KEY uq_type_field_key (activity_type_id, field_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── activities ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS activities (
    id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    program_id         BIGINT UNSIGNED NOT NULL,
    group_id           BIGINT UNSIGNED NOT NULL,
    activity_type_id   BIGINT UNSIGNED NOT NULL,
    activity_date      DATE            NOT NULL,
    activity_time      TIME            NULL,
    location           VARCHAR(200)    NULL,
    notes              TEXT            NULL,
    deleted_at         TIMESTAMP       NULL DEFAULT NULL,
    created_by_user_id BIGINT UNSIGNED NOT NULL,
    created_at         TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_act_group_date (group_id, activity_date),
    INDEX idx_act_creator    (created_by_user_id),
    CONSTRAINT fk_act_program FOREIGN KEY (program_id)         REFERENCES programs(id),
    CONSTRAINT fk_act_group   FOREIGN KEY (group_id)           REFERENCES `groups`(id),
    CONSTRAINT fk_act_type    FOREIGN KEY (activity_type_id)   REFERENCES activity_types(id),
    CONSTRAINT fk_act_user    FOREIGN KEY (created_by_user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── activity_students (attendance) ─────────────────────────
CREATE TABLE IF NOT EXISTS activity_students (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    activity_id          BIGINT UNSIGNED NOT NULL,
    student_id           BIGINT UNSIGNED NOT NULL,
    participation_status ENUM('present','absent') NOT NULL DEFAULT 'absent',
    notes                TEXT NULL,
    created_at           TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_as_activity (activity_id),
    INDEX idx_as_student  (student_id),
    CONSTRAINT fk_as_activity FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE,
    CONSTRAINT fk_as_student  FOREIGN KEY (student_id)  REFERENCES students(id),
    UNIQUE KEY uq_activity_student (activity_id, student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── activity_field_values (metadata values per activity+student) ──
CREATE TABLE IF NOT EXISTS activity_field_values (
    id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    activity_id      BIGINT UNSIGNED NOT NULL,
    student_id       BIGINT UNSIGNED NOT NULL,
    activity_type_field_id BIGINT UNSIGNED NOT NULL,
    value_text       TEXT          NULL,
    value_number     DECIMAL(12,2) NULL,
    value_date       DATE          NULL,
    value_boolean    TINYINT(1)    NULL,
    created_at       TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_afv_activity FOREIGN KEY (activity_id)      REFERENCES activities(id) ON DELETE CASCADE,
    CONSTRAINT fk_afv_student  FOREIGN KEY (student_id)       REFERENCES students(id),
    CONSTRAINT fk_afv_field    FOREIGN KEY (activity_type_field_id) REFERENCES activity_type_fields(id),
    UNIQUE KEY uq_afv (activity_id, student_id, activity_type_field_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── audit_logs ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_logs (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT UNSIGNED NOT NULL,
    action      VARCHAR(150)    NOT NULL,
    entity_type VARCHAR(100)    NOT NULL,
    entity_id   BIGINT UNSIGNED NOT NULL DEFAULT 0,
    details_json JSON           NULL,
    ip_address  VARCHAR(45)     NULL,
    created_at  TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_user   (user_id, created_at),
    INDEX idx_audit_entity (entity_type, entity_id),
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
