<?php
// config/database.php

define('DB_HOST',    'localhost');
define('DB_NAME',    'netafnit');
define('DB_USER',    'nettafnitadmin');
define('DB_PASS',    '');          // הגדר בקובץ .env או כאן ישירות
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        $pdo->exec("SET time_zone = '+02:00'");
    } catch (PDOException $e) {
        http_response_code(500);
        // אל תחשוף שגיאות DB בפרודקשן
        error_log('DB connection failed: ' . $e->getMessage());
        die('<div dir="rtl" style="font-family:sans-serif;text-align:center;padding:80px 20px">
             <h2>שגיאת חיבור למסד הנתונים</h2>
             <p>פנה למנהל המערכת</p></div>');
    }
    return $pdo;
}
