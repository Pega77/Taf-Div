-- =============================================================
-- netafnit – seed.sql
-- Run after schema.sql:
--   mysql -u nettafnitadmin -p netafnit < config/seed.sql
--
-- Default credentials:
--   admin      / Admin1234!
--   coordinator/ Admin1234!
--   instructor1/ Admin1234!
--   instructor2/ Admin1234!
-- =============================================================

USE netafnit;

-- password_hash = bcrypt of 'Admin1234!'
INSERT INTO users (full_name, username, phone, password_hash, role) VALUES
('מנהל מערכת',   'admin',       '0500000000', '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiMoMEqdYpQxHkDIOqxFqKbcJL7C', 'admin'),
('רכזת תוכנית',  'coordinator', '0500000001', '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiMoMEqdYpQxHkDIOqxFqKbcJL7C', 'coordinator'),
('מדריך ראשון',  'instructor1', '0500000002', '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiMoMEqdYpQxHkDIOqxFqKbcJL7C', 'instructor'),
('מדריכה שנייה', 'instructor2', '0500000003', '$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiMoMEqdYpQxHkDIOqxFqKbcJL7C', 'instructor');

INSERT INTO programs (name, status) VALUES
('תוכנית מנהיגות', 'active'),
('תוכנית קהילה',  'active');

INSERT INTO `groups` (program_id, name, instructor_user_id, location, status) VALUES
(1, 'קבוצת בוגרים',  3, 'מתנ"ס צפון',   'active'),
(1, 'קבוצת צעירים',  4, 'מתנ"ס דרום',   'active'),
(2, 'קבוצת קהילה א', 3, 'בית ספר מקיף', 'active');

INSERT INTO students (national_id, full_name, gender, birth_date, phone, school, grade, status) VALUES
('123456789', 'נועה לוי',      'female', '2010-02-14', '0521111111', 'מקיף א',  'י',  'active'),
('223456789', 'יונתן כהן',    'male',   '2009-11-20', '0522222222', 'מקיף א',  'יא', 'active'),
('323456789', 'דניאל ישראלי', 'male',   '2011-05-03', '0523333333', 'מקיף ב',  'ט',  'active'),
('423456789', 'רוני מזרחי',   'female', '2010-09-08', '0524444444', 'מקיף ב',  'י',  'frozen'),
('523456789', 'מאיה רוזן',    'female', '2010-03-15', '0525555555', 'מקיף א',  'י',  'active'),
('623456789', 'עמית גולן',    'male',   '2009-07-22', '0526666666', 'מקיף ג',  'יא', 'active');

INSERT INTO group_student (group_id, student_id, is_active, joined_at) VALUES
(1, 1, 1, '2025-09-01'),
(1, 2, 1, '2025-09-01'),
(2, 3, 1, '2025-09-01'),
(2, 4, 1, '2025-09-01'),
(3, 5, 1, '2025-09-01'),
(3, 6, 1, '2025-09-01');

INSERT INTO metadata_fields (program_id, field_key, field_label, field_type, is_required, options_json, sort_order) VALUES
(1, 'school_name',  'בית ספר',           'text',   0, NULL,                                      1),
(1, 'grade_level',  'שכבה',              'select', 0, '["ז","ח","ט","י","יא","יב"]',              2),
(1, 'socio_status', 'מצב סוציו-אקונומי', 'select', 0, '["נמוך","בינוני","גבוה"]',               3),
(2, 'city',         'יישוב',             'text',   0, NULL,                                      1);

INSERT INTO activity_types (name, icon, color, requires_notes, requires_attendance, is_active, sort_order) VALUES
('מפגש קבוצתי', 'users',           '#2E7D32', 0, 1, 1, 1),
('מפגש פרטני',  'user',            '#1565C0', 1, 1, 1, 2),
('סדנה',        'school',          '#6A1B9A', 0, 1, 1, 3),
('אירוע',       'star',            '#E65100', 0, 1, 1, 4),
('ביקור בית',   'home',            '#00695C', 1, 0, 1, 5),
('שיחה אישית',  'message-circle',  '#37474F', 1, 0, 1, 6);

INSERT INTO activities (program_id, group_id, activity_type_id, activity_date, activity_time, location, notes, created_by_user_id) VALUES
(1, 1, 1, CURDATE(),                        '16:00:00', 'מתנ"ס צפון', 'מפגש פתיחה',    3),
(1, 2, 3, DATE_SUB(CURDATE(), INTERVAL 1 DAY), '18:30:00', 'מתנ"ס דרום', 'סדנת היכרות', 4);

INSERT INTO activity_students (activity_id, student_id, participation_status) VALUES
(1, 1, 'present'),
(1, 2, 'present'),
(2, 3, 'present'),
(2, 4, 'absent');
