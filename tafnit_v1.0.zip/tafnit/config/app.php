<?php
// config/app.php

define('APP_NAME',    'תפנית');
define('APP_TAGLINE', 'מערכת ניהול תוכניות');
define('APP_VERSION', '1.0.0');
define('APP_URL',     'https://net.tafnit-il.org.il');
define('APP_LOGO',    'https://static.wixstatic.com/media/8449dd_04250e647fd94f83a109aa38df23ed73~mv2.png/v1/fill/w_176,h_123,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/logo_nb.png');

// תפקידים
define('ROLE_ADMIN',       'admin');
define('ROLE_COORDINATOR', 'coordinator');
define('ROLE_INSTRUCTOR',  'instructor');

define('ROLE_LABELS', [
    'admin'       => 'מנהל מערכת',
    'coordinator' => 'רכז',
    'instructor'  => 'מדריך',
]);

// דף ברירת מחדל לפי תפקיד
define('ROLE_DEFAULT_PAGE', [
    'admin'       => APP_URL . '/dashboard.php',
    'coordinator' => APP_URL . '/dashboard.php',
    'instructor'  => APP_URL . '/pages/my_group.php',
]);

// Session timeout – 8 שעות
define('SESSION_TIMEOUT', 3600 * 8);

// צבעי מותג
define('BRAND_GREEN',       '#2E7D32');
define('BRAND_GREEN_LIGHT', '#E8F5E9');
define('BRAND_GREEN_DARK',  '#1B5E20');
