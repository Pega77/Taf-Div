<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin(); requireRole([ROLE_ADMIN]); $db=getDB();

if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!verify_csrf()){flashMessage('בקשה לא תקינה','danger');redirect(APP_URL.'/pages/programs.php');}
    $a=$_POST['action']??'';
    if($a==='add'){$db->prepare("INSERT INTO programs (name,status) VALUES (?,'active')")->execute([sanitize($_POST['name'])]);flashMessage('נוצרה','success');}
    if($a==='edit'){$db->prepare("UPDATE programs SET name=?,status=? WHERE id=?")->execute([sanitize($_POST['name']),sanitize($_POST['status']),(int)$_POST['pid']]);flashMessage('עודכנה','success');}
    redirect(APP_URL.'/pages/programs.php');
}

$programs=$db->query("SELECT p.*,COUNT(DISTINCT g.id) AS gc,COUNT(DISTINCT gs.student_id) AS sc,COUNT(DISTINCT a.id) AS ac FROM programs p LEFT JOIN `groups` g ON g.program_id=p.id AND g.status='active' LEFT JOIN group_student gs ON gs.group_id=g.id AND gs.is_active=1 LEFT JOIN activities a ON a.program_id=p.id AND a.deleted_at IS NULL GROUP BY p.id ORDER BY p.name")->fetchAll();
$pageTitle='תוכניות'; $activePage='programs';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><h2>תוכניות</h2><button class="btn btn-primary btn-sm" data-modal-open="modal-add">➕ תוכנית</button></div>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px">
  <?php foreach($programs as $p): ?>
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
      <div><div style="font-size:1rem;font-weight:600"><?= h($p['name']) ?></div><?= $p['status']==='active'?'<span class="badge badge-success">פעיל</span>':'<span class="badge badge-muted">לא פעיל</span>' ?></div>
      <button class="btn btn-ghost btn-sm" onclick="openEditProg(<?= htmlspecialchars(json_encode($p),ENT_QUOTES) ?>)">✏️</button>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;text-align:center">
      <?php foreach([['קבוצות',$p['gc']],['חניכים',$p['sc']],['פעילויות',$p['ac']]] as [$l,$v]): ?>
      <div style="background:var(--brand-lighter);border-radius:var(--r-md);padding:9px 4px"><div style="font-weight:700;font-size:1.1rem;color:var(--brand)"><?= $v ?></div><div style="font-size:.72rem;color:var(--color-text-muted)"><?= $l ?></div></div>
      <?php endforeach; ?>
    </div>
    <div style="margin-top:10px;display:flex;gap:6px">
      <a href="<?= APP_URL ?>/pages/groups.php" class="btn btn-secondary btn-sm" style="flex:1;justify-content:center">קבוצות</a>
      <a href="<?= APP_URL ?>/pages/metadata.php?pid=<?= $p['id'] ?>" class="btn btn-ghost btn-sm" style="flex:1;justify-content:center">שדות</a>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<div class="modal-overlay" id="modal-add" style="display:none"><div class="modal"><div class="modal-handle"></div><div class="modal-header"><span class="modal-title">תוכנית חדשה</span><button class="modal-close" data-modal-close>✕</button></div><form method="POST"><div class="modal-body"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="add"><div class="form-group"><label class="form-label">שם <span class="req">*</span></label><input type="text" name="name" class="form-control" required></div></div><div class="modal-footer"><button type="button" class="btn btn-ghost" data-modal-close>ביטול</button><button type="submit" class="btn btn-primary">שמור</button></div></form></div></div>
<div class="modal-overlay" id="modal-edit" style="display:none"><div class="modal"><div class="modal-handle"></div><div class="modal-header"><span class="modal-title">עריכת תוכנית</span><button class="modal-close" data-modal-close>✕</button></div><form method="POST"><div class="modal-body"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="edit"><input type="hidden" name="pid" id="ep_id"><div class="form-group"><label class="form-label">שם <span class="req">*</span></label><input type="text" name="name" id="ep_name" class="form-control" required></div><div class="form-group"><label class="form-label">סטטוס</label><select name="status" id="ep_status" class="form-control"><option value="active">פעיל</option><option value="inactive">לא פעיל</option></select></div></div><div class="modal-footer"><button type="button" class="btn btn-ghost" data-modal-close>ביטול</button><button type="submit" class="btn btn-primary">עדכן</button></div></form></div></div>
<script>function openEditProg(p){document.getElementById('ep_id').value=p.id;document.getElementById('ep_name').value=p.name;document.getElementById('ep_status').value=p.status;document.getElementById('modal-edit').style.display='flex';}</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
