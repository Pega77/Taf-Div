<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin(); $user=currentUser(); $db=getDB();

if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!verify_csrf()){flashMessage('בקשה לא תקינה','danger');redirect(APP_URL.'/pages/activities.php');}
    $gid=(int)$_POST['group_id'];
    $prog=$db->prepare("SELECT program_id FROM `groups` WHERE id=?"); $prog->execute([$gid]); $pid=(int)$prog->fetchColumn();
    $db->prepare("INSERT INTO activities (program_id,group_id,activity_type_id,activity_date,activity_time,location,notes,created_by_user_id) VALUES (?,?,?,?,?,?,?,?)")
       ->execute([$pid,$gid,(int)$_POST['activity_type_id'],sanitize($_POST['activity_date']),sanitize($_POST['activity_time']??'')?:null,sanitize($_POST['location']??''),sanitize($_POST['notes']??''),$user['id']]);
    $aid=$db->lastInsertId();
    $members=$db->prepare("SELECT student_id FROM group_student WHERE group_id=? AND is_active=1"); $members->execute([$gid]);
    $ins=$db->prepare("INSERT IGNORE INTO activity_students (activity_id,student_id,participation_status) VALUES (?,?,'absent')");
    foreach($members->fetchAll() as $m) $ins->execute([$aid,$m['student_id']]);
    flashMessage('הפעילות נוצרה – סמן נוכחות','success');
    redirect(APP_URL.'/pages/activity_detail.php?id='.$aid);
}

$gF=(int)($_GET['group_id']??($user['group_id']??0)); $tF=(int)($_GET['type_id']??0);
$dF=sanitize($_GET['date_from']??''); $dT=sanitize($_GET['date_to']??'');
$where=['a.deleted_at IS NULL']; $params=[];
if($gF){$where[]='a.group_id=?';$params[]=$gF;}
if($tF){$where[]='a.activity_type_id=?';$params[]=$tF;}
if($dF){$where[]='a.activity_date>=?';$params[]=$dF;}
if($dT){$where[]='a.activity_date<=?';$params[]=$dT;}
if(isInstructor()&&$user['group_id']){$where[]='a.group_id=?';$params[]=$user['group_id'];}

$acts=$db->prepare("SELECT a.*,g.name AS grp,at.name AS type_name,at.color,COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS pc,COUNT(acs.id) AS tc FROM activities a JOIN `groups` g ON g.id=a.group_id JOIN activity_types at ON at.id=a.activity_type_id LEFT JOIN activity_students acs ON acs.activity_id=a.id WHERE ".implode(' AND ',$where)." GROUP BY a.id ORDER BY a.activity_date DESC,a.created_at DESC");
$acts->execute($params); $acts=$acts->fetchAll();

$types=$db->query("SELECT * FROM activity_types WHERE is_active=1 ORDER BY sort_order")->fetchAll();
if(isInstructor()&&$user['group_id']){$gQ=$db->prepare("SELECT g.*,p.name AS prog FROM `groups` g JOIN programs p ON p.id=g.program_id WHERE g.id=?");$gQ->execute([$user['group_id']]);}
else{$gQ=$db->query("SELECT g.*,p.name AS prog FROM `groups` g JOIN programs p ON p.id=g.program_id WHERE g.status='active' ORDER BY p.name,g.name");}
$groups=$gQ->fetchAll();
$openNew=!empty($_GET['new']);

$pageTitle='פעילויות'; $activePage='activities';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <h2>פעילויות <span style="font-size:.8rem;color:var(--color-text-muted);font-weight:400">(<?= count($acts) ?>)</span></h2>
  <button class="btn btn-primary btn-sm" data-modal-open="modal-add">➕ חדש</button>
</div>

<form method="GET" class="filter-bar">
  <?php if(!isInstructor()): ?>
  <select name="group_id" class="form-control" style="max-width:160px">
    <option value="">כל הקבוצות</option>
    <?php foreach($groups as $g): ?><option value="<?= $g['id'] ?>" <?= $gF==$g['id']?'selected':'' ?>><?= h($g['name']) ?></option><?php endforeach; ?>
  </select>
  <?php endif; ?>
  <select name="type_id" class="form-control" style="max-width:140px">
    <option value="">כל הסוגים</option>
    <?php foreach($types as $t): ?><option value="<?= $t['id'] ?>" <?= $tF==$t['id']?'selected':'' ?>><?= h($t['name']) ?></option><?php endforeach; ?>
  </select>
  <input type="date" name="date_from" class="form-control" style="max-width:140px" value="<?= h($dF) ?>">
  <input type="date" name="date_to"   class="form-control" style="max-width:140px" value="<?= h($dT) ?>">
  <button type="submit" class="btn btn-secondary">סנן</button>
</form>

<div class="card" style="padding:0">
  <div class="table-wrapper mobile-cards">
    <?php if($acts): ?>
    <table class="data-table">
      <thead><tr><th>תאריך</th><th>קבוצה</th><th>סוג</th><th>נוכחות</th><th></th></tr></thead>
      <tbody>
        <?php foreach($acts as $a): ?>
        <?php $pct=$a['tc']?round($a['pc']/$a['tc']*100):0; ?>
        <tr>
          <td data-label="תאריך" style="white-space:nowrap"><?= formatDate($a['activity_date']) ?><?= $a['activity_time']?' '.formatTime($a['activity_time']):'' ?></td>
          <td data-label="קבוצה"><a href="<?= APP_URL ?>/pages/activity_detail.php?id=<?= $a['id'] ?>" style="font-weight:500"><?= h($a['grp']) ?></a></td>
          <td data-label="סוג"><span class="badge badge-primary"><?= h($a['type_name']) ?></span></td>
          <td data-label="נוכחות">
            <?php if($a['tc']): ?>
            <div style="display:flex;align-items:center;gap:6px">
              <div class="progress-bar" style="width:60px"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
              <span style="font-size:.8rem;font-weight:600;color:<?= attendanceColor($pct) ?>"><?= $a['pc'] ?>/<?= $a['tc'] ?></span>
            </div>
            <?php else: ?><span style="color:var(--color-text-light);font-size:.82rem">לא נרשמו</span><?php endif; ?>
          </td>
          <td><a href="<?= APP_URL ?>/pages/activity_detail.php?id=<?= $a['id'] ?>" class="btn btn-secondary btn-sm">פתח</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?><div class="empty-state"><div class="empty-icon">📅</div><h3>אין פעילויות</h3></div><?php endif; ?>
  </div>
</div>

<!-- מודל הוספת פעילות -->
<div class="modal-overlay" id="modal-add" style="display:<?= $openNew?'flex':'none' ?>">
  <div class="modal">
    <div class="modal-handle"></div>
    <div class="modal-header"><span class="modal-title">פעילות חדשה</span><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <div class="form-group"><label class="form-label">סוג פעילות <span class="req">*</span></label>
          <select name="activity_type_id" class="form-control" required>
            <option value="">בחר...</option>
            <?php foreach($types as $t): ?><option value="<?= $t['id'] ?>"><?= h($t['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="form-group"><label class="form-label">קבוצה <span class="req">*</span></label>
          <select name="group_id" class="form-control" required>
            <option value="">בחר קבוצה...</option>
            <?php foreach($groups as $g): ?><option value="<?= $g['id'] ?>" <?= isInstructor()&&$user['group_id']==$g['id']?'selected':'' ?>><?= h($g['name']) ?> – <?= h($g['prog']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">תאריך <span class="req">*</span></label><input type="date" name="activity_date" class="form-control" required value="<?= date('Y-m-d') ?>"></div>
          <div class="form-group"><label class="form-label">שעה</label><input type="time" name="activity_time" class="form-control"></div>
        </div>
        <div class="form-group"><label class="form-label">מיקום</label><input type="text" name="location" class="form-control" placeholder="מתנ&quot;ס / כתובת..."></div>
        <div class="form-group"><label class="form-label">הערות</label><textarea name="notes" class="form-control" rows="2"></textarea></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">צור פעילות</button>
      </div>
    </form>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
