<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin(); requireRole([ROLE_ADMIN]); $db=getDB();
$pid=(int)($_GET['pid']??0);

if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!verify_csrf()){flashMessage('בקשה לא תקינה','danger');redirect(APP_URL.'/pages/metadata.php'.($pid?"?pid=$pid":''));}
    $a=$_POST['action']??'';
    if($a==='add_field'){
        $key=preg_replace('/[^a-z0-9_]/','_',strtolower(sanitize($_POST['field_key'])));
        $opts=null;if($_POST['field_type']==='select'&&!empty($_POST['options'])){$o=array_filter(array_map('trim',explode("\n",$_POST['options'])));$opts=json_encode(array_values($o));}
        try{$db->prepare("INSERT INTO metadata_fields (program_id,field_key,field_label,field_type,is_required,options_json,sort_order) VALUES (?,?,?,?,?,?,?)")->execute([(int)$_POST['prog_id'],$key,sanitize($_POST['field_label']),sanitize($_POST['field_type']),(int)isset($_POST['is_required']),$opts,(int)($_POST['sort']??99)]);flashMessage('שדה נוסף','success');}catch(PDOException){flashMessage('מפתח שדה קיים','danger');}
        redirect(APP_URL.'/pages/metadata.php?pid='.(int)$_POST['prog_id']);
    }
    if($a==='toggle_field'){$c=$db->prepare("SELECT is_active FROM metadata_fields WHERE id=?");$c->execute([(int)$_POST['fid']]);$c=(int)$c->fetchColumn();$db->prepare("UPDATE metadata_fields SET is_active=? WHERE id=?")->execute([1-$c,(int)$_POST['fid']]);flashMessage('עודכן','success');redirect(APP_URL.'/pages/metadata.php'.($pid?"?pid=$pid":''));}
}

$programs=$db->query("SELECT * FROM programs WHERE status='active' ORDER BY name")->fetchAll();
$fields=$pid?$db->prepare("SELECT * FROM metadata_fields WHERE program_id=? ORDER BY sort_order")->execute([$pid])?$db->prepare("SELECT * FROM metadata_fields WHERE program_id=? ORDER BY sort_order"):null:null;
if($pid){$fq=$db->prepare("SELECT * FROM metadata_fields WHERE program_id=? ORDER BY sort_order");$fq->execute([$pid]);$fields=$fq->fetchAll();}else{$fields=[];}
$ftypes=['text'=>'טקסט','number'=>'מספר','date'=>'תאריך','boolean'=>'כן/לא','select'=>'רשימה'];

$pageTitle='שדות מותאמים'; $activePage='metadata';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><h2>שדות מותאמים</h2><?php if($pid): ?><button class="btn btn-primary btn-sm" data-modal-open="modal-add-field">➕ שדה</button><?php endif; ?></div>
<div class="card">
  <form method="GET" style="display:flex;gap:10px;align-items:center">
    <label class="form-label" style="margin:0;white-space:nowrap">תוכנית:</label>
    <select name="pid" class="form-control" style="max-width:200px" onchange="this.form.submit()">
      <option value="">בחר תוכנית...</option>
      <?php foreach($programs as $p): ?><option value="<?= $p['id'] ?>" <?= $pid==$p['id']?'selected':'' ?>><?= h($p['name']) ?></option><?php endforeach; ?>
    </select>
  </form>
</div>
<?php if($pid&&$fields): ?>
<div class="card" style="padding:0">
  <div class="table-wrapper mobile-cards">
    <table class="data-table">
      <thead><tr><th>תווית</th><th>מפתח</th><th>סוג</th><th>חובה</th><th>סטטוס</th><th></th></tr></thead>
      <tbody>
        <?php foreach($fields as $f): ?>
        <tr style="<?= !$f['is_active']?'opacity:.55':'' ?>">
          <td data-label="תווית" style="font-weight:500"><?= h($f['field_label']) ?></td>
          <td data-label="מפתח" style="font-family:monospace;font-size:.82rem"><?= h($f['field_key']) ?></td>
          <td data-label="סוג"><span class="badge badge-info"><?= h($ftypes[$f['field_type']]??$f['field_type']) ?></span></td>
          <td data-label="חובה"><?= $f['is_required']?'<span class="badge badge-danger">חובה</span>':'—' ?></td>
          <td data-label="סטטוס"><?= $f['is_active']?'<span class="badge badge-success">פעיל</span>':'<span class="badge badge-muted">מנוטרל</span>' ?></td>
          <td><form method="POST" style="display:inline"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="toggle_field"><input type="hidden" name="fid" value="<?= $f['id'] ?>"><button type="submit" class="btn btn-ghost btn-sm"><?= $f['is_active']?'⏸️':'▶️' ?></button></form></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php elseif($pid): ?>
<div class="card"><div class="empty-state"><div class="empty-icon">🔖</div><h3>אין שדות</h3></div></div>
<?php elseif(!$pid): ?>
<div class="card"><div class="empty-state"><div class="empty-icon">🗂️</div><h3>בחר תוכנית</h3></div></div>
<?php endif; ?>

<?php if($pid): ?>
<div class="modal-overlay" id="modal-add-field" style="display:none"><div class="modal"><div class="modal-handle"></div><div class="modal-header"><span class="modal-title">שדה חדש</span><button class="modal-close" data-modal-close>✕</button></div><form method="POST"><div class="modal-body"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="add_field"><input type="hidden" name="prog_id" value="<?= $pid ?>"><div class="form-row"><div class="form-group"><label class="form-label">תווית <span class="req">*</span></label><input type="text" name="field_label" class="form-control" required></div><div class="form-group"><label class="form-label">מפתח <span class="req">*</span></label><input type="text" name="field_key" class="form-control" required pattern="[a-z0-9_]+"></div></div><div class="form-row"><div class="form-group"><label class="form-label">סוג</label><select name="field_type" class="form-control" onchange="document.getElementById('m_opts').style.display=this.value==='select'?'':'none'"><?php foreach($ftypes as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?></select></div><div class="form-group"><label class="form-label">סדר</label><input type="number" name="sort" class="form-control" value="99"></div></div><div id="m_opts" style="display:none" class="form-group"><label class="form-label">אפשרויות</label><textarea name="options" class="form-control" rows="4"></textarea></div><label style="display:flex;align-items:center;gap:6px;font-size:.88rem;margin-top:4px"><input type="checkbox" name="is_required"> שדה חובה</label></div><div class="modal-footer"><button type="button" class="btn btn-ghost" data-modal-close>ביטול</button><button type="submit" class="btn btn-primary">הוסף</button></div></form></div></div>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
