<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin(); requireRole([ROLE_ADMIN]); $db=getDB();
$df=sanitize($_GET['date_from']??date('Y-m-d',strtotime('-7 days')));
$dt=sanitize($_GET['date_to']??date('Y-m-d'));
$uid=(int)($_GET['uid']??0);
$where=["al.created_at>=? AND al.created_at<DATE_ADD(?,INTERVAL 1 DAY)"]; $p=[$df,$dt];
if($uid){$where[]='al.user_id=?';$p[]=$uid;}
$logs=$db->prepare("SELECT al.*,u.full_name,u.role FROM audit_logs al JOIN users u ON u.id=al.user_id WHERE ".implode(' AND ',$where)." ORDER BY al.created_at DESC LIMIT 200");
$logs->execute($p); $logs=$logs->fetchAll();
$users=$db->query("SELECT id,full_name FROM users WHERE deleted_at IS NULL ORDER BY full_name")->fetchAll();
$pageTitle='יומן פעולות'; $activePage='audit';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><h2>יומן פעולות</h2></div>
<form method="GET" class="filter-bar">
  <select name="uid" class="form-control" style="max-width:170px"><option value="">כל המשתמשים</option><?php foreach($users as $u): ?><option value="<?= $u['id'] ?>" <?= $uid==$u['id']?'selected':'' ?>><?= h($u['full_name']) ?></option><?php endforeach; ?></select>
  <input type="date" name="date_from" class="form-control" style="max-width:140px" value="<?= h($df) ?>">
  <input type="date" name="date_to"   class="form-control" style="max-width:140px" value="<?= h($dt) ?>">
  <button type="submit" class="btn btn-secondary">סנן</button>
</form>
<div class="card" style="padding:0">
  <div class="table-wrapper mobile-cards">
    <?php if($logs): ?>
    <table class="data-table">
      <thead><tr><th>זמן</th><th>משתמש</th><th>פעולה</th><th>ישות</th></tr></thead>
      <tbody>
        <?php foreach($logs as $l): ?>
        <tr>
          <td data-label="זמן" style="white-space:nowrap;font-size:.8rem"><?= formatDate($l['created_at'],'d/m H:i') ?></td>
          <td data-label="משתמש"><div style="font-weight:500;font-size:.88rem"><?= h($l['full_name']) ?></div><div style="font-size:.74rem;color:var(--color-text-muted)"><?= h(roleLabel($l['role'])) ?></div></td>
          <td data-label="פעולה"><span class="badge badge-info"><?= h($l['action']) ?></span></td>
          <td data-label="ישות" style="font-size:.82rem"><?= h($l['entity_type']) ?><?= $l['entity_id']?' #'.$l['entity_id']:'' ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?><div class="empty-state"><div class="empty-icon">📋</div><h3>אין רשומות</h3></div><?php endif; ?>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
