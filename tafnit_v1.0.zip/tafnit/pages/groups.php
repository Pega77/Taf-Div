<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
requireRole([ROLE_ADMIN, ROLE_COORDINATOR]);
$user = currentUser(); $db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { flashMessage('בקשה לא תקינה','danger'); redirect(APP_URL.'/pages/groups.php'); }
    $action = $_POST['action'] ?? '';

    if ($action === 'add_group') {
        $db->prepare("INSERT INTO `groups` (program_id,name,instructor_user_id,location,status) VALUES (?,?,?,?,'active')")
           ->execute([(int)$_POST['program_id'],sanitize($_POST['name']),(int)$_POST['instructor_user_id'],sanitize($_POST['location']??'')]);
        flashMessage('הקבוצה נוצרה','success'); redirect(APP_URL.'/pages/groups.php');
    }
    if ($action === 'edit_group') {
        $db->prepare("UPDATE `groups` SET program_id=?,name=?,instructor_user_id=?,location=? WHERE id=?")
           ->execute([(int)$_POST['program_id'],sanitize($_POST['name']),(int)$_POST['instructor_user_id'],sanitize($_POST['location']??''),(int)$_POST['group_id']]);
        flashMessage('הקבוצה עודכנה','success'); redirect(APP_URL.'/pages/groups.php');
    }
    if ($action === 'toggle_group') {
        $cur=$db->prepare("SELECT status FROM `groups` WHERE id=?"); $cur->execute([(int)$_POST['group_id']]); $cur=$cur->fetchColumn();
        $db->prepare("UPDATE `groups` SET status=? WHERE id=?")->execute([$cur==='active'?'inactive':'active',(int)$_POST['group_id']]);
        flashMessage('סטטוס עודכן','success'); redirect(APP_URL.'/pages/groups.php');
    }
    if ($action === 'assign_student') {
        $chk=$db->prepare("SELECT id FROM group_student WHERE student_id=? AND is_active=1"); $chk->execute([(int)$_POST['student_id']]);
        if ($chk->fetch()) { flashMessage('חניך זה כבר משויך','warning'); }
        else {
            $db->prepare("INSERT INTO group_student (group_id,student_id,is_active,joined_at) VALUES (?,?,1,CURDATE())")->execute([(int)$_POST['group_id'],(int)$_POST['student_id']]);
            flashMessage('החניך שויך','success');
        }
        redirect(APP_URL.'/pages/groups.php?open='.(int)$_POST['group_id']);
    }
    if ($action === 'remove_student') {
        $db->prepare("UPDATE group_student SET is_active=0,left_at=CURDATE() WHERE student_id=? AND group_id=? AND is_active=1")->execute([(int)$_POST['student_id'],(int)$_POST['group_id']]);
        flashMessage('החניך הוסר','success'); redirect(APP_URL.'/pages/groups.php?open='.(int)$_POST['group_id']);
    }
}

$groups = $db->query("
    SELECT g.*,p.name AS prog,u.full_name AS instructor_name,
           COUNT(DISTINCT gs.student_id) AS sc,COUNT(DISTINCT a.id) AS ac
    FROM `groups` g
    JOIN programs p ON p.id=g.program_id
    LEFT JOIN users u ON u.id=g.instructor_user_id
    LEFT JOIN group_student gs ON gs.group_id=g.id AND gs.is_active=1
    LEFT JOIN activities a ON a.group_id=g.id AND a.deleted_at IS NULL
    GROUP BY g.id ORDER BY p.name,g.name
")->fetchAll();

$programs    = $db->query("SELECT * FROM programs WHERE status='active' ORDER BY name")->fetchAll();
$instructors = $db->query("SELECT id,full_name FROM users WHERE role='instructor' AND is_active=1 ORDER BY full_name")->fetchAll();
$unassigned  = $db->query("SELECT id,full_name,national_id FROM students WHERE status='active' AND deleted_at IS NULL AND id NOT IN (SELECT student_id FROM group_student WHERE is_active=1) ORDER BY full_name")->fetchAll();

$byProg = []; foreach ($groups as $g) $byProg[$g['prog']][] = $g;
$openId = (int)($_GET['open'] ?? 0);

$pageTitle = 'קבוצות'; $activePage = 'groups';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <h2>קבוצות</h2>
  <?php if (isAdmin()): ?><button class="btn btn-primary btn-sm" data-modal-open="modal-add-group">➕ קבוצה חדשה</button><?php endif; ?>
</div>

<?php foreach ($byProg as $progName => $pg): ?>
<div style="margin-bottom:20px">
  <div style="font-size:.8rem;font-weight:600;color:var(--brand);margin-bottom:10px;display:flex;align-items:center;gap:6px">
    🗂️ <?= h($progName) ?> <span class="badge badge-primary"><?= count($pg) ?></span>
  </div>
  <?php foreach ($pg as $g): ?>
  <div class="card" style="padding:0;margin-bottom:10px;overflow:hidden">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:13px 14px;cursor:pointer"
         data-toggle-target="grp-body-<?= $g['id'] ?>" aria-expanded="<?= $openId==$g['id']?'true':'false' ?>">
      <div style="display:flex;align-items:center;gap:10px">
        <div class="avatar" style="background:var(--brand-light);color:var(--brand-dark)">👥</div>
        <div>
          <div style="font-weight:500;font-size:.9rem"><?= h($g['name']) ?> <?= $g['status']!=='active'?'<span class="badge badge-muted" style="font-size:.7rem">לא פעיל</span>':'' ?></div>
          <div style="font-size:.77rem;color:var(--color-text-muted)">👤 <?= h($g['instructor_name']??'ללא מדריך') ?></div>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:12px">
        <div style="text-align:center"><div style="font-weight:700;color:var(--brand)"><?= $g['sc'] ?></div><div style="font-size:.7rem;color:var(--color-text-muted)">חניכים</div></div>
        <?php if (isAdmin()): ?>
        <button class="btn btn-ghost btn-sm" onclick="event.stopPropagation();openEditGrp(<?= htmlspecialchars(json_encode($g),ENT_QUOTES) ?>)" style="padding:4px 8px">✏️</button>
        <?php endif; ?>
        <span class="toggle-icon"><?= $openId==$g['id']?'▲':'▼' ?></span>
      </div>
    </div>
    <div id="grp-body-<?= $g['id'] ?>" style="<?= $openId==$g['id']?'':'display:none' ?>;border-top:1px solid var(--color-border)">
      <?php
      $gstu=$db->prepare("SELECT s.id,s.full_name,s.national_id,s.status AS ss,COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS pc,COUNT(acs.id) AS tc FROM group_student gs JOIN students s ON s.id=gs.student_id LEFT JOIN activity_students acs ON acs.student_id=s.id LEFT JOIN activities act ON act.id=acs.activity_id AND act.group_id=? AND act.deleted_at IS NULL WHERE gs.group_id=? AND gs.is_active=1 GROUP BY s.id ORDER BY s.full_name");
      $gstu->execute([$g['id'],$g['id']]); $gstu=$gstu->fetchAll();
      ?>
      <div style="padding:12px 14px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
          <span style="font-size:.84rem;font-weight:500">חניכים (<?= count($gstu) ?>)</span>
          <div style="display:flex;gap:6px">
            <a href="<?= APP_URL ?>/pages/activities.php?group_id=<?= $g['id'] ?>" class="btn btn-ghost btn-sm">📅</a>
            <button class="btn btn-secondary btn-sm" onclick="openAssign(<?= $g['id'] ?>,'<?= h(addslashes($g['name'])) ?>')">➕ שייך</button>
          </div>
        </div>
        <?php foreach ($gstu as $s): ?>
        <?php $pct=$s['tc']?round($s['pc']/$s['tc']*100):0; ?>
        <div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--color-border)">
          <div class="avatar" style="width:30px;height:30px;font-size:.7rem"><?= h(initials($s['full_name'])) ?></div>
          <div style="flex:1;min-width:0">
            <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $s['id'] ?>" style="font-size:.88rem;font-weight:500"><?= h($s['full_name']) ?></a>
            <div style="display:flex;align-items:center;gap:6px;margin-top:2px">
              <div class="progress-bar" style="width:50px"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
              <span style="font-size:.75rem;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
            </div>
          </div>
          <form method="POST" style="display:inline" onsubmit="return confirm('להסיר?')">
            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
            <input type="hidden" name="action" value="remove_student">
            <input type="hidden" name="student_id" value="<?= $s['id'] ?>">
            <input type="hidden" name="group_id" value="<?= $g['id'] ?>">
            <button type="submit" class="btn btn-ghost btn-sm" style="color:var(--color-danger);padding:4px 6px">הסר</button>
          </form>
        </div>
        <?php endforeach; ?>
        <?php if (!$gstu): ?><div style="text-align:center;padding:16px;color:var(--color-text-muted);font-size:.88rem">אין חניכים עדיין</div><?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endforeach; ?>
<?php if (!$groups): ?><div class="card"><div class="empty-state"><div class="empty-icon">👥</div><h3>אין קבוצות</h3></div></div><?php endif; ?>

<!-- מודל הוספת קבוצה -->
<?php if (isAdmin()): ?>
<div class="modal-overlay" id="modal-add-group" style="display:none">
  <div class="modal">
    <div class="modal-handle"></div>
    <div class="modal-header"><span class="modal-title">קבוצה חדשה</span><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST"><div class="modal-body">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
      <input type="hidden" name="action" value="add_group">
      <div class="form-group"><label class="form-label">שם <span class="req">*</span></label><input type="text" name="name" class="form-control" required></div>
      <div class="form-group"><label class="form-label">תוכנית <span class="req">*</span></label>
        <select name="program_id" class="form-control" required><option value="">בחר...</option>
          <?php foreach($programs as $p): ?><option value="<?= $p['id'] ?>"><?= h($p['name']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group"><label class="form-label">מדריך <span class="req">*</span></label>
        <select name="instructor_user_id" class="form-control" required><option value="">בחר מדריך...</option>
          <?php foreach($instructors as $i): ?><option value="<?= $i['id'] ?>"><?= h($i['full_name']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group"><label class="form-label">מיקום</label><input type="text" name="location" class="form-control" placeholder='מתנ"ס / כתובת...'></div>
    </div><div class="modal-footer">
      <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
      <button type="submit" class="btn btn-primary">צור קבוצה</button>
    </div></form>
  </div>
</div>
<div class="modal-overlay" id="modal-edit-group" style="display:none">
  <div class="modal">
    <div class="modal-handle"></div>
    <div class="modal-header"><span class="modal-title">עריכת קבוצה</span><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST"><div class="modal-body">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
      <input type="hidden" name="action" value="edit_group">
      <input type="hidden" name="group_id" id="eg_id">
      <div class="form-group"><label class="form-label">שם <span class="req">*</span></label><input type="text" name="name" id="eg_name" class="form-control" required></div>
      <div class="form-group"><label class="form-label">תוכנית</label>
        <select name="program_id" id="eg_prog" class="form-control">
          <?php foreach($programs as $p): ?><option value="<?= $p['id'] ?>"><?= h($p['name']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group"><label class="form-label">מדריך</label>
        <select name="instructor_user_id" id="eg_ins" class="form-control">
          <?php foreach($instructors as $i): ?><option value="<?= $i['id'] ?>"><?= h($i['full_name']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group"><label class="form-label">מיקום</label><input type="text" name="location" id="eg_loc" class="form-control"></div>
    </div><div class="modal-footer">
      <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
      <button type="submit" class="btn btn-primary">עדכן</button>
    </div></form>
  </div>
</div>
<?php endif; ?>

<!-- מודל שיוך חניך -->
<div class="modal-overlay" id="modal-assign" style="display:none">
  <div class="modal">
    <div class="modal-handle"></div>
    <div class="modal-header"><span class="modal-title" id="assign-title">שיוך חניך</span><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST"><div class="modal-body">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
      <input type="hidden" name="action" value="assign_student">
      <input type="hidden" name="group_id" id="assign_gid">
      <div class="form-group"><label class="form-label">חניך <span class="req">*</span></label>
        <select name="student_id" class="form-control" required>
          <option value="">בחר...</option>
          <?php foreach($unassigned as $s): ?><option value="<?= $s['id'] ?>"><?= h($s['full_name']) ?> · <?= h($s['national_id']) ?></option><?php endforeach; ?>
        </select>
        <?php if(!$unassigned): ?><div class="form-hint">כל החניכים משויכים. <a href="<?= APP_URL ?>/pages/students.php?new=1">הוסף חניך חדש</a></div><?php endif; ?>
      </div>
    </div><div class="modal-footer">
      <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
      <button type="submit" class="btn btn-primary" <?= !$unassigned?'disabled':'' ?>>שייך</button>
    </div></form>
  </div>
</div>

<script>
function openEditGrp(g){
  document.getElementById('eg_id').value=g.id;
  document.getElementById('eg_name').value=g.name;
  document.getElementById('eg_prog').value=g.program_id;
  document.getElementById('eg_ins').value=g.instructor_user_id;
  document.getElementById('eg_loc').value=g.location||'';
  document.getElementById('modal-edit-group').style.display='flex';
}
function openAssign(gid,gname){
  document.getElementById('assign_gid').value=gid;
  document.getElementById('assign-title').textContent='שיוך חניך – '+gname;
  document.getElementById('modal-assign').style.display='flex';
}
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
