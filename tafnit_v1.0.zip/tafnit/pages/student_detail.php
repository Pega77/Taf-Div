<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin(); $user=currentUser(); $db=getDB();
$id=(int)($_GET['id']??0); if(!$id) redirect(APP_URL.'/pages/students.php');
$s=$db->prepare("SELECT * FROM students WHERE id=? AND deleted_at IS NULL"); $s->execute([$id]); $s=$s->fetch();
if(!$s){flashMessage('חניך לא נמצא','danger');redirect(APP_URL.'/pages/students.php');}

$grp=$db->prepare("SELECT gs.*,g.name AS grp,g.id AS gid,p.name AS prog,u.full_name AS ins FROM group_student gs JOIN `groups` g ON g.id=gs.group_id JOIN programs p ON p.id=g.program_id LEFT JOIN users u ON u.id=g.instructor_user_id WHERE gs.student_id=? ORDER BY gs.is_active DESC,gs.joined_at DESC"); $grp->execute([$id]); $grp=$grp->fetchAll();
$activeGrp=null; foreach($grp as $g){if($g['is_active']){$activeGrp=$g;break;}}

$att=$db->prepare("SELECT a.activity_date,at.name AS type_name,g.name AS grp,acs.participation_status FROM activity_students acs JOIN activities a ON a.id=acs.activity_id AND a.deleted_at IS NULL JOIN activity_types at ON at.id=a.activity_type_id JOIN `groups` g ON g.id=a.group_id WHERE acs.student_id=? ORDER BY a.activity_date DESC LIMIT 50"); $att->execute([$id]); $att=$att->fetchAll();
$pc=count(array_filter($att,fn($r)=>$r['participation_status']==='present')); $tc=count($att); $pct=$tc?round($pc/$tc*100):0;

$metaFields=[]; $metaVals=[];
if($activeGrp){$mf=$db->prepare("SELECT * FROM metadata_fields WHERE program_id=? AND is_active=1 ORDER BY sort_order");$mf->execute([$db->prepare("SELECT program_id FROM `groups` WHERE id=?")->execute([$activeGrp['gid']])&&($qq=$db->prepare("SELECT program_id FROM `groups` WHERE id=?"))&&$qq->execute([$activeGrp['gid']])&&$qq->fetchColumn()]);$metaFields=[];$qq2=$db->prepare("SELECT program_id FROM `groups` WHERE id=?");$qq2->execute([$activeGrp['gid']]);$ppid=$qq2->fetchColumn();if($ppid){$mf2=$db->prepare("SELECT * FROM metadata_fields WHERE program_id=? AND is_active=1 ORDER BY sort_order");$mf2->execute([$ppid]);$metaFields=$mf2->fetchAll();}$mv=$db->prepare("SELECT * FROM metadata_values WHERE student_id=?");$mv->execute([$id]);foreach($mv->fetchAll() as $v)$metaVals[$v['metadata_field_id']]=$v;}

$pageTitle=$s['full_name']; $activePage='students';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <div>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
      <div class="avatar" style="width:44px;height:44px;font-size:.9rem"><?= h(initials($s['full_name'])) ?></div>
      <div>
        <h2 style="font-size:1.1rem"><?= h($s['full_name']) ?></h2>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <?= statusBadge($s['status']) ?>
          <?php if($activeGrp): ?><span class="badge badge-primary"><?= h($activeGrp['grp']) ?></span><?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <?php if(!isInstructor()): ?><a href="<?= APP_URL ?>/pages/student_edit.php?id=<?= $id ?>" class="btn btn-secondary btn-sm">✏️ עריכה</a><?php endif; ?>
</div>

<div class="card">
  <div style="font-size:.82rem;font-weight:500;color:var(--color-text-muted);margin-bottom:10px;text-transform:uppercase;letter-spacing:.05em">פרטים אישיים</div>
  <table style="width:100%;font-size:.88rem">
    <tr><td style="color:var(--color-text-muted);padding:5px 0;width:40%">ת.ז.</td><td style="font-weight:500"><?= h($s['national_id']) ?></td></tr>
    <tr><td style="color:var(--color-text-muted);padding:5px 0">מין</td><td><?= genderLabel($s['gender']) ?></td></tr>
    <tr><td style="color:var(--color-text-muted);padding:5px 0">לידה</td><td><?= formatDate($s['birth_date']) ?></td></tr>
    <tr><td style="color:var(--color-text-muted);padding:5px 0">טלפון</td><td><?= h($s['phone']??'—') ?></td></tr>
    <tr><td style="color:var(--color-text-muted);padding:5px 0">בי"ס</td><td><?= h($s['school']??'—') ?></td></tr>
    <tr><td style="color:var(--color-text-muted);padding:5px 0">כיתה</td><td><?= h($s['grade']??'—') ?></td></tr>
    <?php if($s['status']==='frozen'&&$s['freeze_reason']): ?><tr><td style="color:var(--color-text-muted);padding:5px 0">סיבת הקפאה</td><td><?= h($s['freeze_reason']) ?></td></tr><?php endif; ?>
  </table>
</div>

<div class="card">
  <div style="font-size:.82rem;font-weight:500;color:var(--color-text-muted);margin-bottom:10px;text-transform:uppercase;letter-spacing:.05em">נוכחות</div>
  <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:12px">
    <div style="text-align:center"><div style="font-size:1.8rem;font-weight:700;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</div><div style="font-size:.74rem;color:var(--color-text-muted)">כולל</div></div>
    <div style="flex:1;min-width:100px"><div class="progress-bar" style="height:8px"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div><div style="font-size:.78rem;color:var(--color-text-muted);margin-top:4px"><?= $pc ?> נוכח · <?= $tc-$pc ?> נעדר · <?= $tc ?> סה"כ</div></div>
  </div>
  <?php if($att): ?>
  <div style="max-height:240px;overflow-y:auto">
    <?php foreach(array_slice($att,0,20) as $row): ?>
    <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid var(--color-border);font-size:.85rem">
      <span><?= formatDate($row['activity_date']) ?> · <?= h($row['type_name']) ?></span>
      <?= $row['participation_status']==='present'?'<span class="badge badge-success">נוכח</span>':'<span class="badge badge-danger">נעדר</span>' ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?><div class="empty-state" style="padding:20px"><div class="empty-icon">📅</div><p>אין נוכחות</p></div><?php endif; ?>
</div>

<?php if($metaFields): ?>
<div class="card">
  <div style="font-size:.82rem;font-weight:500;color:var(--color-text-muted);margin-bottom:10px;text-transform:uppercase;letter-spacing:.05em">מידע נוסף</div>
  <table style="width:100%;font-size:.88rem">
    <?php foreach($metaFields as $f): ?>
    <?php $v=$metaVals[$f['id']]??null; $display='—';
      if($v){switch($f['field_type']){case'text':$display=$v['value_text']??'—';break;case'number':$display=$v['value_number']??'—';break;case'date':$display=formatDate($v['value_date']);break;case'boolean':$display=$v['value_boolean']?'כן':'לא';break;case'select':$j=json_decode($v['value_json']??'null');$display=is_string($j)?$j:($v['value_text']??'—');break;}} ?>
    <tr><td style="color:var(--color-text-muted);padding:5px 0;width:40%"><?= h($f['field_label']) ?></td><td style="font-weight:500"><?= h($display) ?></td></tr>
    <?php endforeach; ?>
  </table>
</div>
<?php endif; ?>

<?php if($grp): ?>
<div class="card">
  <div style="font-size:.82rem;font-weight:500;color:var(--color-text-muted);margin-bottom:10px;text-transform:uppercase;letter-spacing:.05em">קבוצות</div>
  <?php foreach($grp as $g): ?>
  <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid var(--color-border)">
    <div><div style="font-weight:500;font-size:.88rem"><?= h($g['grp']) ?></div><div style="font-size:.75rem;color:var(--color-text-muted)"><?= h($g['prog']) ?><?= $g['ins']?' · '.h($g['ins']):'' ?></div></div>
    <?= $g['is_active']?'<span class="badge badge-success">נוכחי</span>':'<span class="badge badge-muted">לשעבר</span>' ?>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
