<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin(); requireRole([ROLE_ADMIN]); $db=getDB();

if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!verify_csrf()){flashMessage('בקשה לא תקינה','danger');redirect(APP_URL.'/pages/activity_types.php');}
    $a=$_POST['action']??'';
    if($a==='add'){$db->prepare("INSERT INTO activity_types (name,requires_attendance,requires_notes,sort_order) VALUES (?,?,?,?)")->execute([sanitize($_POST['name']),(int)isset($_POST['req_att']),(int)isset($_POST['req_notes']),(int)($_POST['sort']??99)]);flashMessage('נוסף','success');}
    if($a==='edit'){$db->prepare("UPDATE activity_types SET name=?,requires_attendance=?,requires_notes=?,sort_order=? WHERE id=?")->execute([sanitize($_POST['name']),(int)isset($_POST['req_att']),(int)isset($_POST['req_notes']),(int)$_POST['sort'],(int)$_POST['tid']]);flashMessage('עודכן','success');}
    if($a==='toggle'){$c=$db->prepare("SELECT is_active FROM activity_types WHERE id=?");$c->execute([(int)$_POST['tid']]);$c=(int)$c->fetchColumn();$db->prepare("UPDATE activity_types SET is_active=? WHERE id=?")->execute([1-$c,(int)$_POST['tid']]);flashMessage('עודכן','success');}
    if($a==='add_field'&&!empty($_POST['tid'])){
        $key=preg_replace('/[^a-z0-9_]/','_',strtolower(sanitize($_POST['field_key'])));
        $opts=null;if($_POST['field_type']==='select'&&!empty($_POST['options'])){$o=array_filter(array_map('trim',explode("\n",$_POST['options'])));$opts=json_encode(array_values($o));}
        try{$db->prepare("INSERT INTO activity_type_fields (activity_type_id,field_key,field_label,field_type,is_required,options_json,sort_order) VALUES (?,?,?,?,?,?,?)")->execute([(int)$_POST['tid'],$key,sanitize($_POST['field_label']),sanitize($_POST['field_type']),(int)isset($_POST['is_required']),$opts,(int)($_POST['sort']??99)]);flashMessage('שדה נוסף','success');}catch(PDOException){flashMessage('מפתח שדה קיים','danger');}
    }
    redirect(APP_URL.'/pages/activity_types.php');
}

$types=$db->query("SELECT at.*,COUNT(a.id) AS usage_count FROM activity_types at LEFT JOIN activities a ON a.activity_type_id=at.id AND a.deleted_at IS NULL GROUP BY at.id ORDER BY at.sort_order")->fetchAll();
$ftypes=['text'=>'טקסט','number'=>'מספר','date'=>'תאריך','boolean'=>'כן/לא','select'=>'רשימה'];
$pageTitle='סוגי פעילות'; $activePage='activity_types';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><h2>סוגי פעילות</h2><button class="btn btn-primary btn-sm" data-modal-open="modal-add-type">➕ סוג</button></div>
<?php foreach($types as $t): ?>
<div class="card" style="margin-bottom:12px">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
    <div style="display:flex;align-items:center;gap:10px">
      <span style="font-weight:600;font-size:.95rem"><?= h($t['name']) ?></span>
      <?= $t['is_active']?'<span class="badge badge-success">פעיל</span>':'<span class="badge badge-muted">לא פעיל</span>' ?>
      <?php if($t['requires_attendance']): ?><span class="badge badge-info" style="font-size:.7rem">נוכחות</span><?php endif; ?>
      <?php if($t['requires_notes']): ?><span class="badge badge-primary" style="font-size:.7rem">הערות</span><?php endif; ?>
    </div>
    <div style="display:flex;gap:6px">
      <button class="btn btn-ghost btn-sm" onclick="openEditType(<?= htmlspecialchars(json_encode($t),ENT_QUOTES) ?>)">✏️</button>
      <form method="POST" style="display:inline"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="tid" value="<?= $t['id'] ?>"><button type="submit" class="btn btn-ghost btn-sm"><?= $t['is_active']?'⏸️':'▶️' ?></button></form>
    </div>
  </div>
  <?php
  $fields=$db->prepare("SELECT * FROM activity_type_fields WHERE activity_type_id=? AND is_active=1 ORDER BY sort_order"); $fields->execute([$t['id']]); $fields=$fields->fetchAll();
  ?>
  <?php if($fields): ?>
  <div style="margin-bottom:8px">
    <?php foreach($fields as $f): ?>
    <span class="badge badge-muted" style="margin:2px;font-size:.74rem"><?= h($f['field_label']) ?> (<?= h($ftypes[$f['field_type']]??$f['field_type']) ?>)</span>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <button class="btn btn-ghost btn-sm" onclick="openAddField(<?= $t['id'] ?>,'<?= h(addslashes($t['name'])) ?>')">+ שדה metadata</button>
</div>
<?php endforeach; ?>

<!-- מודל הוספת סוג -->
<div class="modal-overlay" id="modal-add-type" style="display:none"><div class="modal"><div class="modal-handle"></div><div class="modal-header"><span class="modal-title">סוג פעילות חדש</span><button class="modal-close" data-modal-close>✕</button></div><form method="POST"><div class="modal-body"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="add"><div class="form-group"><label class="form-label">שם <span class="req">*</span></label><input type="text" name="name" class="form-control" required></div><div class="form-group"><label class="form-label">סדר תצוגה</label><input type="number" name="sort" class="form-control" value="99"></div><div style="display:flex;gap:16px;margin-top:8px"><label style="display:flex;align-items:center;gap:6px;font-size:.88rem"><input type="checkbox" name="req_att" checked> דורש נוכחות</label><label style="display:flex;align-items:center;gap:6px;font-size:.88rem"><input type="checkbox" name="req_notes"> דורש הערות</label></div></div><div class="modal-footer"><button type="button" class="btn btn-ghost" data-modal-close>ביטול</button><button type="submit" class="btn btn-primary">הוסף</button></div></form></div></div>

<!-- מודל עריכת סוג -->
<div class="modal-overlay" id="modal-edit-type" style="display:none"><div class="modal"><div class="modal-handle"></div><div class="modal-header"><span class="modal-title">עריכת סוג</span><button class="modal-close" data-modal-close>✕</button></div><form method="POST"><div class="modal-body"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="edit"><input type="hidden" name="tid" id="et_id"><div class="form-group"><label class="form-label">שם</label><input type="text" name="name" id="et_name" class="form-control" required></div><div class="form-group"><label class="form-label">סדר</label><input type="number" name="sort" id="et_sort" class="form-control"></div><div style="display:flex;gap:16px;margin-top:8px"><label style="display:flex;align-items:center;gap:6px;font-size:.88rem"><input type="checkbox" name="req_att" id="et_att"> דורש נוכחות</label><label style="display:flex;align-items:center;gap:6px;font-size:.88rem"><input type="checkbox" name="req_notes" id="et_notes"> דורש הערות</label></div></div><div class="modal-footer"><button type="button" class="btn btn-ghost" data-modal-close>ביטול</button><button type="submit" class="btn btn-primary">עדכן</button></div></form></div></div>

<!-- מודל הוספת שדה metadata -->
<div class="modal-overlay" id="modal-add-field" style="display:none"><div class="modal"><div class="modal-handle"></div><div class="modal-header"><span class="modal-title" id="af_title">שדה metadata</span><button class="modal-close" data-modal-close>✕</button></div><form method="POST"><div class="modal-body"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="add_field"><input type="hidden" name="tid" id="af_tid"><div class="form-row"><div class="form-group"><label class="form-label">תווית <span class="req">*</span></label><input type="text" name="field_label" class="form-control" required placeholder="שם השדה"></div><div class="form-group"><label class="form-label">מפתח <span class="req">*</span></label><input type="text" name="field_key" class="form-control" required placeholder="field_key" pattern="[a-z0-9_]+"></div></div><div class="form-row"><div class="form-group"><label class="form-label">סוג</label><select name="field_type" class="form-control" onchange="document.getElementById('opts_row').style.display=this.value==='select'?'':'none'"><?php foreach($ftypes as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?></select></div><div class="form-group"><label class="form-label">סדר</label><input type="number" name="sort" class="form-control" value="99"></div></div><div id="opts_row" style="display:none" class="form-group"><label class="form-label">אפשרויות (שורה לאפשרות)</label><textarea name="options" class="form-control" rows="4"></textarea></div><div style="margin-top:4px"><label style="display:flex;align-items:center;gap:6px;font-size:.88rem"><input type="checkbox" name="is_required"> שדה חובה</label></div></div><div class="modal-footer"><button type="button" class="btn btn-ghost" data-modal-close>ביטול</button><button type="submit" class="btn btn-primary">הוסף שדה</button></div></form></div></div>

<script>
function openEditType(t){document.getElementById('et_id').value=t.id;document.getElementById('et_name').value=t.name;document.getElementById('et_sort').value=t.sort_order;document.getElementById('et_att').checked=!!t.requires_attendance;document.getElementById('et_notes').checked=!!t.requires_notes;document.getElementById('modal-edit-type').style.display='flex';}
function openAddField(tid,name){document.getElementById('af_tid').value=tid;document.getElementById('af_title').textContent='שדה metadata – '+name;document.getElementById('modal-add-field').style.display='flex';}
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
