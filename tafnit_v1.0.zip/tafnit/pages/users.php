<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin(); requireRole([ROLE_ADMIN]); $user=currentUser(); $db=getDB();

if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!verify_csrf()){flashMessage('בקשה לא תקינה','danger');redirect(APP_URL.'/pages/users.php');}
    $a=$_POST['action']??'';
    if($a==='add_user'){
        $dup=$db->prepare("SELECT id FROM users WHERE username=?"); $dup->execute([sanitize($_POST['username'])]);
        if($dup->fetch()){flashMessage('שם משתמש תפוס','danger');}
        else{$db->prepare("INSERT INTO users (full_name,username,phone,password_hash,role) VALUES (?,?,?,?,?)")->execute([sanitize($_POST['full_name']),sanitize($_POST['username']),sanitize($_POST['phone']??''),password_hash($_POST['password'],PASSWORD_BCRYPT),sanitize($_POST['role'])]);flashMessage('המשתמש נוצר','success');}
        redirect(APP_URL.'/pages/users.php');
    }
    if($a==='edit_user'){
        $upd="UPDATE users SET full_name=?,username=?,phone=?,role=?"; $p=[sanitize($_POST['full_name']),sanitize($_POST['username']),sanitize($_POST['phone']??''),sanitize($_POST['role'])];
        if(!empty($_POST['password'])){$upd.=",password_hash=?";$p[]=password_hash($_POST['password'],PASSWORD_BCRYPT);}
        $upd.=" WHERE id=?"; $p[]=(int)$_POST['user_id'];
        $db->prepare($upd)->execute($p); flashMessage('עודכן','success'); redirect(APP_URL.'/pages/users.php');
    }
    if($a==='toggle_user'){
        $cu=$db->prepare("SELECT is_active FROM users WHERE id=?"); $cu->execute([(int)$_POST['user_id']]); $cu=(int)$cu->fetchColumn();
        $db->prepare("UPDATE users SET is_active=? WHERE id=?")->execute([1-$cu,(int)$_POST['user_id']]); flashMessage('סטטוס עודכן','success'); redirect(APP_URL.'/pages/users.php');
    }
}

$users=$db->query("SELECT u.*,g.name AS grp FROM users u LEFT JOIN `groups` g ON g.instructor_user_id=u.id AND g.status='active' WHERE u.deleted_at IS NULL ORDER BY u.role,u.full_name")->fetchAll();
$pageTitle='משתמשים'; $activePage='users';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <h2>משתמשים</h2>
  <button class="btn btn-primary btn-sm" data-modal-open="modal-add-user">➕ משתמש</button>
</div>
<div class="card" style="padding:0">
  <div class="table-wrapper mobile-cards">
    <table class="data-table">
      <thead><tr><th>שם</th><th>שם משתמש</th><th>תפקיד</th><th>סטטוס</th><th></th></tr></thead>
      <tbody>
        <?php foreach($users as $u): ?>
        <tr style="<?= !$u['is_active']?'opacity:.55':'' ?>">
          <td data-label="שם"><div style="display:flex;align-items:center;gap:8px"><div class="avatar"><?= h(initials($u['full_name'])) ?></div><span style="font-weight:500"><?= h($u['full_name']) ?></span></div></td>
          <td data-label="שם משתמש" style="font-family:monospace;font-size:.85rem"><?= h($u['username']) ?></td>
          <td data-label="תפקיד"><span class="badge badge-info"><?= h(roleLabel($u['role'])) ?></span></td>
          <td data-label="סטטוס"><?= $u['is_active']?'<span class="badge badge-success">פעיל</span>':'<span class="badge badge-muted">מנוטרל</span>' ?></td>
          <td><div style="display:flex;gap:6px">
            <button class="btn btn-ghost btn-sm" onclick="openEditUsr(<?= htmlspecialchars(json_encode($u),ENT_QUOTES) ?>)">✏️</button>
            <?php if($u['id']!=$user['id']): ?>
            <form method="POST" style="display:inline"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="toggle_user"><input type="hidden" name="user_id" value="<?= $u['id'] ?>"><button type="submit" class="btn btn-ghost btn-sm"><?= $u['is_active']?'⏸️':'▶️' ?></button></form>
            <?php endif; ?>
          </div></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal-overlay" id="modal-add-user" style="display:none">
  <div class="modal"><div class="modal-handle"></div>
    <div class="modal-header"><span class="modal-title">משתמש חדש</span><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST"><div class="modal-body">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="add_user">
      <div class="form-row">
        <div class="form-group"><label class="form-label">שם מלא <span class="req">*</span></label><input type="text" name="full_name" class="form-control" required></div>
        <div class="form-group"><label class="form-label">שם משתמש <span class="req">*</span></label><input type="text" name="username" class="form-control" required></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">טלפון</label><input type="tel" name="phone" class="form-control" inputmode="tel"></div>
        <div class="form-group"><label class="form-label">תפקיד <span class="req">*</span></label>
          <select name="role" class="form-control" required><option value="instructor">מדריך</option><option value="coordinator">רכז</option><option value="admin">מנהל</option></select>
        </div>
      </div>
      <div class="form-group"><label class="form-label">סיסמה <span class="req">*</span></label><input type="password" name="password" class="form-control" required minlength="6"></div>
    </div><div class="modal-footer"><button type="button" class="btn btn-ghost" data-modal-close>ביטול</button><button type="submit" class="btn btn-primary">צור</button></div></form>
  </div>
</div>

<div class="modal-overlay" id="modal-edit-user" style="display:none">
  <div class="modal"><div class="modal-handle"></div>
    <div class="modal-header"><span class="modal-title">עריכת משתמש</span><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST"><div class="modal-body">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="edit_user"><input type="hidden" name="user_id" id="eu_id">
      <div class="form-row">
        <div class="form-group"><label class="form-label">שם מלא</label><input type="text" name="full_name" id="eu_name" class="form-control" required></div>
        <div class="form-group"><label class="form-label">שם משתמש</label><input type="text" name="username" id="eu_un" class="form-control" required></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">טלפון</label><input type="tel" name="phone" id="eu_ph" class="form-control"></div>
        <div class="form-group"><label class="form-label">תפקיד</label>
          <select name="role" id="eu_role" class="form-control"><option value="instructor">מדריך</option><option value="coordinator">רכז</option><option value="admin">מנהל</option></select>
        </div>
      </div>
      <div class="form-group"><label class="form-label">סיסמה חדשה <span class="form-hint">(השאר ריק)</span></label><input type="password" name="password" class="form-control" minlength="6"></div>
    </div><div class="modal-footer"><button type="button" class="btn btn-ghost" data-modal-close>ביטול</button><button type="submit" class="btn btn-primary">עדכן</button></div></form>
  </div>
</div>
<script>
function openEditUsr(u){
  document.getElementById('eu_id').value=u.id; document.getElementById('eu_name').value=u.full_name;
  document.getElementById('eu_un').value=u.username; document.getElementById('eu_ph').value=u.phone||'';
  document.getElementById('eu_role').value=u.role; document.getElementById('modal-edit-user').style.display='flex';
}
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
