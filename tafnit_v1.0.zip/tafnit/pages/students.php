<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
$user = currentUser(); $db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { flashMessage('בקשה לא תקינה','danger'); redirect(APP_URL.'/pages/students.php'); }
    $action = $_POST['action'] ?? '';

    if ($action === 'add_student') {
        $dup = $db->prepare("SELECT id FROM students WHERE national_id=?");
        $dup->execute([sanitize($_POST['national_id'])]);
        if ($dup->fetch()) { flashMessage('מספר זהות קיים במערכת','danger'); }
        else {
            $db->prepare("INSERT INTO students (national_id,full_name,gender,birth_date,phone,school,grade) VALUES (?,?,?,?,?,?,?)")
               ->execute([sanitize($_POST['national_id']),sanitize($_POST['full_name']),
                 sanitize($_POST['gender']??'')?:null,sanitize($_POST['birth_date']??'')?:null,
                 sanitize($_POST['phone']??''),sanitize($_POST['school']??''),sanitize($_POST['grade']??'')]);
            $sid = $db->lastInsertId();
            if (!empty($_POST['group_id'])) {
                $db->prepare("INSERT IGNORE INTO group_student (group_id,student_id,joined_at) VALUES (?,?,CURDATE())")
                   ->execute([(int)$_POST['group_id'], $sid]);
            }
            flashMessage('החניך נוסף בהצלחה','success');
        }
        redirect(APP_URL.'/pages/students.php');
    }
    if ($action === 'freeze') {
        $db->prepare("UPDATE students SET status='frozen',freeze_reason=?,frozen_at=NOW() WHERE id=?")
           ->execute([sanitize($_POST['reason']??''),(int)$_POST['student_id']]);
        flashMessage('החניך הוקפא','warning'); redirect(APP_URL.'/pages/students.php');
    }
    if ($action === 'unfreeze') {
        $db->prepare("UPDATE students SET status='active',freeze_reason=NULL,frozen_at=NULL WHERE id=?")
           ->execute([(int)$_POST['student_id']]);
        flashMessage('הקפאה בוטלה','success'); redirect(APP_URL.'/pages/students.php');
    }
}

$search  = sanitize($_GET['search']   ?? '');
$groupF  = (int)($_GET['group_id']    ?? 0);
$statusF = sanitize($_GET['status']   ?? '');
$where   = ['s.deleted_at IS NULL']; $params = [];
if ($search)  { $where[] = '(s.full_name LIKE ? OR s.national_id LIKE ?)'; $params[]="%$search%"; $params[]="%$search%"; }
if ($groupF)  { $where[] = 'gs.group_id=?'; $params[]=$groupF; }
if ($statusF) { $where[] = 's.status=?';    $params[]=$statusF; }
if (isInstructor() && $user['group_id']) { $where[]='gs.group_id=?'; $params[]=$user['group_id']; }

$sql = "SELECT DISTINCT s.*,g.name AS grp,g.id AS gid,
        (SELECT COUNT(*) FROM activity_students a2 JOIN activities ac ON ac.id=a2.activity_id WHERE a2.student_id=s.id AND a2.participation_status='present' AND ac.deleted_at IS NULL) pc,
        (SELECT COUNT(*) FROM activity_students a3 JOIN activities ac2 ON ac2.id=a3.activity_id WHERE a3.student_id=s.id AND ac2.deleted_at IS NULL) tc
        FROM students s
        LEFT JOIN group_student gs ON gs.student_id=s.id AND gs.is_active=1
        LEFT JOIN `groups` g ON g.id=gs.group_id
        WHERE ".implode(' AND ',$where)."
        ORDER BY s.full_name";
$stmt = $db->prepare($sql); $stmt->execute($params);
$students = $stmt->fetchAll();

$groups = $db->query("SELECT g.*,p.name AS prog FROM `groups` g JOIN programs p ON p.id=g.program_id WHERE g.status='active' ORDER BY p.name,g.name")->fetchAll();

$openNew = !empty($_GET['new']);
$pageTitle = 'חניכים'; $activePage = 'students';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <h2>חניכים <span style="font-size:.8rem;color:var(--color-text-muted);font-weight:400">(<?= count($students) ?>)</span></h2>
  <button class="btn btn-primary btn-sm" data-modal-open="modal-add">➕ חניך חדש</button>
</div>

<form method="GET" class="filter-bar">
  <input type="text" name="search" class="form-control" placeholder="🔍 חיפוש שם / ת.ז." value="<?= h($search) ?>" style="flex:1;min-width:140px">
  <?php if (!isInstructor()): ?>
  <select name="group_id" class="form-control" style="max-width:160px">
    <option value="">כל הקבוצות</option>
    <?php foreach ($groups as $g): ?>
    <option value="<?= $g['id'] ?>" <?= $groupF==$g['id']?'selected':'' ?>><?= h($g['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <?php endif; ?>
  <select name="status" class="form-control" style="max-width:120px">
    <option value="">כל הסטטוסים</option>
    <option value="active"  <?= $statusF==='active' ?'selected':'' ?>>פעיל</option>
    <option value="frozen"  <?= $statusF==='frozen' ?'selected':'' ?>>מוקפא</option>
  </select>
  <button type="submit" class="btn btn-secondary">סנן</button>
</form>

<div class="card" style="padding:0">
  <div class="table-wrapper mobile-cards">
    <?php if ($students): ?>
    <table class="data-table" id="studentsTable">
      <thead><tr><th>שם</th><th>ת.ז.</th><th>קבוצה</th><th>נוכחות</th><th>סטטוס</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($students as $s): ?>
        <?php $pct = $s['tc'] ? round($s['pc']/$s['tc']*100) : 0; ?>
        <tr>
          <td data-label="שם">
            <div style="display:flex;align-items:center;gap:8px">
              <div class="avatar"><?= h(initials($s['full_name'])) ?></div>
              <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $s['id'] ?>" style="font-weight:500"><?= h($s['full_name']) ?></a>
            </div>
          </td>
          <td data-label="ת.ז."><?= h($s['national_id']) ?></td>
          <td data-label="קבוצה"><?= $s['grp'] ? '<span class="badge badge-primary">'.h($s['grp']).'</span>' : '<span class="badge badge-muted">לא משויך</span>' ?></td>
          <td data-label="נוכחות">
            <div style="display:flex;align-items:center;gap:6px">
              <div class="progress-bar" style="width:60px"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
              <span style="font-size:.8rem;font-weight:600;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
            </div>
          </td>
          <td data-label="סטטוס"><?= statusBadge($s['status']) ?></td>
          <td>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $s['id'] ?>" class="btn btn-ghost btn-sm">תיק</a>
              <?php if (!isInstructor()): ?>
              <a href="<?= APP_URL ?>/pages/student_edit.php?id=<?= $s['id'] ?>" class="btn btn-ghost btn-sm">✏️</a>
              <?php if ($s['status']==='active'): ?>
              <button class="btn btn-ghost btn-sm" style="color:var(--color-warning)" onclick="openFreeze(<?= $s['id'] ?>,'<?= h(addslashes($s['full_name'])) ?>')">❄️</button>
              <?php else: ?>
              <form method="POST" style="display:inline">
                <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                <input type="hidden" name="action" value="unfreeze">
                <input type="hidden" name="student_id" value="<?= $s['id'] ?>">
                <button type="submit" class="btn btn-ghost btn-sm" style="color:var(--color-success)">▶️</button>
              </form>
              <?php endif; ?>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><div class="empty-icon">🎒</div><h3>לא נמצאו חניכים</h3></div>
    <?php endif; ?>
  </div>
</div>

<!-- מודל הוספת חניך -->
<div class="modal-overlay" id="modal-add" style="display:<?= $openNew?'flex':'none' ?>">
  <div class="modal">
    <div class="modal-handle"></div>
    <div class="modal-header"><span class="modal-title">חניך חדש</span><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="add_student">
        <div class="form-row">
          <div class="form-group"><label class="form-label">שם מלא <span class="req">*</span></label><input type="text" name="full_name" class="form-control" required></div>
          <div class="form-group"><label class="form-label">מספר זהות <span class="req">*</span></label><input type="text" name="national_id" class="form-control" required maxlength="9" pattern="[0-9]{9}" inputmode="numeric"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">מין</label>
            <select name="gender" class="form-control"><option value="">—</option><option value="male">זכר</option><option value="female">נקבה</option><option value="other">אחר</option></select>
          </div>
          <div class="form-group"><label class="form-label">תאריך לידה</label><input type="date" name="birth_date" class="form-control"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">טלפון</label><input type="tel" name="phone" class="form-control" inputmode="tel"></div>
          <div class="form-group"><label class="form-label">בית ספר</label><input type="text" name="school" class="form-control"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">כיתה</label><input type="text" name="grade" class="form-control"></div>
          <div class="form-group"><label class="form-label">קבוצה</label>
            <select name="group_id" class="form-control">
              <option value="">ללא קבוצה</option>
              <?php foreach ($groups as $g): ?>
              <option value="<?= $g['id'] ?>" <?= isInstructor()&&$user['group_id']==$g['id']?'selected':'' ?>><?= h($g['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">הוסף חניך</button>
      </div>
    </form>
  </div>
</div>

<!-- מודל הקפאה -->
<div class="modal-overlay" id="modal-freeze" style="display:none">
  <div class="modal">
    <div class="modal-handle"></div>
    <div class="modal-header"><span class="modal-title">הקפאת חניך</span><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="freeze">
        <input type="hidden" name="student_id" id="freeze_id">
        <p id="freeze_name" style="font-weight:600;margin-bottom:12px"></p>
        <div class="form-group"><label class="form-label">סיבה</label><textarea name="reason" class="form-control" rows="3"></textarea></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-danger">הקפא</button>
      </div>
    </form>
  </div>
</div>

<script>
function openFreeze(id,name){
  document.getElementById('freeze_id').value=id;
  document.getElementById('freeze_name').textContent='הקפאת: '+name;
  document.getElementById('modal-freeze').style.display='flex';
}
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
