<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin(); $user=currentUser(); $db=getDB();

$gid = isInstructor() ? ($user['group_id'] ?? 0) : (int)($_GET['group_id']??0);
if(!$gid) redirect(isInstructor() ? APP_URL.'/dashboard.php' : APP_URL.'/pages/groups.php');

$group=$db->prepare("SELECT g.*,p.name AS prog,u.full_name AS ins FROM `groups` g JOIN programs p ON p.id=g.program_id LEFT JOIN users u ON u.id=g.instructor_user_id WHERE g.id=? AND g.status='active'");
$group->execute([$gid]); $group=$group->fetch();
if(!$group){flashMessage('קבוצה לא נמצאה','danger');redirect(APP_URL.'/pages/groups.php');}

$students=$db->prepare("SELECT s.*,COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS pc,COUNT(acs.id) AS tc FROM group_student gs JOIN students s ON s.id=gs.student_id LEFT JOIN activity_students acs ON acs.student_id=s.id LEFT JOIN activities act ON act.id=acs.activity_id AND act.group_id=? AND act.deleted_at IS NULL WHERE gs.group_id=? AND gs.is_active=1 GROUP BY s.id ORDER BY s.full_name");
$students->execute([$gid,$gid]); $students=$students->fetchAll();

$recentActs=$db->prepare("SELECT a.*,at.name AS type_name,COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS pc,COUNT(acs.id) AS tc FROM activities a JOIN activity_types at ON at.id=a.activity_type_id LEFT JOIN activity_students acs ON acs.activity_id=a.id WHERE a.group_id=? AND a.deleted_at IS NULL GROUP BY a.id ORDER BY a.activity_date DESC LIMIT 5");
$recentActs->execute([$gid]); $recentActs=$recentActs->fetchAll();

$totalActs=(int)$db->prepare("SELECT COUNT(*) FROM activities WHERE group_id=? AND deleted_at IS NULL")->execute([$gid])?? 0;
$q=$db->prepare("SELECT COUNT(*) FROM activities WHERE group_id=? AND deleted_at IS NULL"); $q->execute([$gid]); $totalActs=(int)$q->fetchColumn();
$withAtt=array_filter($students,fn($s)=>$s['tc']>0);
$avg=$withAtt?round(array_sum(array_map(fn($s)=>$s['pc']/$s['tc']*100,$withAtt))/count($withAtt)):0;
$lowCount=count(array_filter($students,fn($s)=>$s['tc']>0&&$s['pc']/$s['tc']*100<70));

$pageTitle='הקבוצה שלי – '.$group['name']; $activePage='my_group';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <div>
    <h2><?= h($group['name']) ?></h2>
    <span class="badge badge-primary" style="font-size:.78rem"><?= h($group['prog']) ?></span>
  </div>
  <a href="<?= APP_URL ?>/pages/activities.php?new=1&group_id=<?= $gid ?>" class="btn btn-primary btn-sm">➕ פעילות</a>
</div>

<div class="stats-grid">
  <div class="stat-card"><div class="stat-icon">🎒</div><div class="stat-value"><?= count($students) ?></div><div class="stat-label">חניכים</div></div>
  <div class="stat-card"><div class="stat-icon">📅</div><div class="stat-value"><?= $totalActs ?></div><div class="stat-label">פעילויות</div></div>
  <div class="stat-card"><div class="stat-icon">✅</div><div class="stat-value" style="color:<?= attendanceColor($avg) ?>"><?= $avg ?>%</div><div class="stat-label">נוכחות ממוצעת</div></div>
  <div class="stat-card"><div class="stat-icon">⚠️</div><div class="stat-value" style="color:var(--color-warning)"><?= $lowCount ?></div><div class="stat-label">נוכחות נמוכה</div></div>
</div>

<div class="card">
  <div class="card-header"><span class="card-title">חניכי הקבוצה</span>
    <input type="text" placeholder="🔍" class="form-control" style="max-width:130px;min-height:34px" data-search-table="stuTable">
  </div>
  <?php if($students): ?>
  <div class="table-wrapper mobile-cards">
    <table class="data-table" id="stuTable">
      <thead><tr><th>שם</th><th>נוכחות</th><th>סטטוס</th><th></th></tr></thead>
      <tbody>
        <?php foreach($students as $s): ?>
        <?php $pct=$s['tc']?round($s['pc']/$s['tc']*100):0; ?>
        <tr style="<?= $s['tc']>0&&$pct<70?'background:var(--color-warning-bg)':'' ?>">
          <td data-label="שם">
            <div style="display:flex;align-items:center;gap:8px">
              <div class="avatar"><?= h(initials($s['full_name'])) ?></div>
              <span style="font-weight:500;font-size:.9rem"><?= h($s['full_name']) ?></span>
            </div>
          </td>
          <td data-label="נוכחות">
            <?php if($s['tc']): ?>
            <div style="display:flex;align-items:center;gap:6px">
              <div class="progress-bar" style="width:55px"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
              <span style="font-size:.8rem;font-weight:600;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
            </div>
            <?php else: ?>—<?php endif; ?>
          </td>
          <td data-label="סטטוס"><?= statusBadge($s['status']) ?></td>
          <td><a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $s['id'] ?>" class="btn btn-ghost btn-sm">תיק →</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php else: ?><div class="empty-state"><div class="empty-icon">🎒</div><p>אין חניכים</p></div><?php endif; ?>
</div>

<div class="card">
  <div class="card-header"><span class="card-title">פעילויות אחרונות</span>
    <a href="<?= APP_URL ?>/pages/activities.php?group_id=<?= $gid ?>" class="btn btn-ghost btn-sm">הכל ←</a>
  </div>
  <?php foreach($recentActs as $a): ?>
  <?php $pct=$a['tc']?round($a['pc']/$a['tc']*100):0; ?>
  <a href="<?= APP_URL ?>/pages/activity_detail.php?id=<?= $a['id'] ?>" style="display:block;padding:10px 0;border-bottom:1px solid var(--color-border);text-decoration:none">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
      <span style="font-size:.88rem;font-weight:500;color:var(--color-text)"><?= formatDate($a['activity_date']) ?><?= $a['activity_time']?' · '.formatTime($a['activity_time']):'' ?></span>
      <span class="badge badge-primary" style="font-size:.72rem"><?= h($a['type_name']) ?></span>
    </div>
    <?php if($a['tc']): ?>
    <div style="display:flex;align-items:center;gap:6px">
      <div class="progress-bar" style="flex:1"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
      <span style="font-size:.78rem;font-weight:600;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
    </div>
    <?php endif; ?>
  </a>
  <?php endforeach; ?>
  <?php if(!$recentActs): ?><div class="empty-state" style="padding:20px"><div class="empty-icon">📅</div><p>אין פעילויות</p></div><?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
