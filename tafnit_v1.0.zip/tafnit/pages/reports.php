<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin(); requireRole([ROLE_ADMIN,ROLE_COORDINATOR]); $db=getDB();

$pid=(int)($_GET['program_id']??0); $gid=(int)($_GET['group_id']??0);
$df=sanitize($_GET['date_from']??date('Y-01-01')); $dt=sanitize($_GET['date_to']??date('Y-12-31'));

$where=["a.deleted_at IS NULL AND a.activity_date BETWEEN ? AND ?"]; $params=[$df,$dt];
if($pid){$where[]='a.program_id=?';$params[]=$pid;}
if($gid){$where[]='a.group_id=?';$params[]=$gid;}
$ws='WHERE '.implode(' AND ',$where);

$q="SELECT s.id,s.full_name,s.national_id,g.name AS grp,p.name AS prog,
    COUNT(DISTINCT a.id) AS tc,
    COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS pc
    FROM students s
    JOIN group_student gs ON gs.student_id=s.id AND gs.is_active=1
    JOIN `groups` g ON g.id=gs.group_id
    JOIN programs p ON p.id=g.program_id
    LEFT JOIN activities a ON a.group_id=g.id $ws
    LEFT JOIN activity_students acs ON acs.activity_id=a.id AND acs.student_id=s.id
    WHERE s.deleted_at IS NULL
    GROUP BY s.id,g.id ORDER BY p.name,g.name,s.full_name";
$stmt=$db->prepare($q); $stmt->execute($params); $rows=$stmt->fetchAll();

if(isset($_GET['export'])&&$_GET['export']==='csv'){
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="attendance_'.date('Ymd').'.csv"');
    echo "\xEF\xBB\xBF";
    $out=fopen('php://output','w');
    fputcsv($out,['שם','ת.ז.','תוכנית','קבוצה','מפגשים','נוכח','נעדר','אחוז','קריטריון']);
    foreach($rows as $r){
        $pct=$r['tc']?round($r['pc']/$r['tc']*100):0;
        $crit=$pct>=70?'עומד':($pct>=50?'גבולי':'לא עומד');
        fputcsv($out,[$r['full_name'],$r['national_id'],$r['prog'],$r['grp'],$r['tc'],$r['pc'],$r['tc']-$r['pc'],$pct.'%',$crit]);
    }
    fclose($out); exit;
}

$programs=$db->query("SELECT * FROM programs WHERE status='active' ORDER BY name")->fetchAll();
$groups=$db->query("SELECT g.*,p.name AS prog FROM `groups` g JOIN programs p ON p.id=g.program_id WHERE g.status='active' ORDER BY p.name,g.name")->fetchAll();

$meet=count(array_filter($rows,fn($r)=>$r['tc']&&($r['pc']/$r['tc']*100)>=70));
$border=count(array_filter($rows,fn($r)=>$r['tc']&&($p=$r['pc']/$r['tc']*100)>=50&&$p<70));
$fail=count(array_filter($rows,fn($r)=>$r['tc']&&($r['pc']/$r['tc']*100)<50));

$pageTitle='דוחות'; $activePage='reports';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <h2>דוח נוכחות</h2>
  <div style="display:flex;gap:6px">
    <a href="?<?= http_build_query(array_merge($_GET,['export'=>'csv'])) ?>" class="btn btn-secondary btn-sm">📥 CSV</a>
    <button onclick="window.print()" class="btn btn-ghost btn-sm">🖨️</button>
  </div>
</div>

<form method="GET" class="filter-bar">
  <select name="program_id" class="form-control" style="max-width:150px">
    <option value="">כל התוכניות</option>
    <?php foreach($programs as $p): ?><option value="<?= $p['id'] ?>" <?= $pid==$p['id']?'selected':'' ?>><?= h($p['name']) ?></option><?php endforeach; ?>
  </select>
  <select name="group_id" class="form-control" style="max-width:150px">
    <option value="">כל הקבוצות</option>
    <?php foreach($groups as $g): ?><option value="<?= $g['id'] ?>" <?= $gid==$g['id']?'selected':'' ?>><?= h($g['name']) ?></option><?php endforeach; ?>
  </select>
  <input type="date" name="date_from" class="form-control" style="max-width:140px" value="<?= h($df) ?>">
  <input type="date" name="date_to"   class="form-control" style="max-width:140px" value="<?= h($dt) ?>">
  <button type="submit" class="btn btn-primary">הצג</button>
</form>

<div class="stats-grid">
  <div class="stat-card"><div class="stat-icon">🎒</div><div class="stat-value"><?= count($rows) ?></div><div class="stat-label">חניכים</div></div>
  <div class="stat-card"><div class="stat-icon">✅</div><div class="stat-value" style="color:var(--color-success)"><?= $meet ?></div><div class="stat-label">עומדים ≥70%</div></div>
  <div class="stat-card"><div class="stat-icon">⚠️</div><div class="stat-value" style="color:var(--color-warning)"><?= $border ?></div><div class="stat-label">גבולי 50–69%</div></div>
  <div class="stat-card"><div class="stat-icon">❌</div><div class="stat-value" style="color:var(--color-danger)"><?= $fail ?></div><div class="stat-label">לא עומדים</div></div>
</div>

<div class="card" style="padding:0">
  <div class="table-wrapper mobile-cards">
    <?php if($rows): ?>
    <table class="data-table">
      <thead><tr><th>שם</th><th>קבוצה</th><th>מפגשים</th><th>נוכחות</th><th>קריטריון</th></tr></thead>
      <tbody>
        <?php foreach($rows as $r): ?>
        <?php $pct=$r['tc']?round($r['pc']/$r['tc']*100):0; $crit=$pct>=70?['עומד','badge-success']:($pct>=50?['גבולי','badge-warning']:['לא עומד','badge-danger']); ?>
        <tr>
          <td data-label="שם"><a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $r['id'] ?>"><?= h($r['full_name']) ?></a></td>
          <td data-label="קבוצה"><?= h($r['grp']) ?><div style="font-size:.74rem;color:var(--color-text-muted)"><?= h($r['prog']) ?></div></td>
          <td data-label="מפגשים" style="text-align:center"><?= $r['tc']?:'—' ?></td>
          <td data-label="נוכחות">
            <?php if($r['tc']): ?>
            <div style="display:flex;align-items:center;gap:6px">
              <div class="progress-bar" style="width:55px"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
              <span style="font-size:.8rem;font-weight:600;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
            </div>
            <?php else: ?>—<?php endif; ?>
          </td>
          <td data-label="קריטריון">
            <?php if($r['tc']): ?><span class="badge <?= $crit[1] ?>"><?= $crit[0] ?></span><?php else: ?>—<?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?><div class="empty-state"><div class="empty-icon">📊</div><h3>לא נמצאו נתונים</h3></div><?php endif; ?>
  </div>
</div>
<style>@media print{.topbar,.sidebar,.sidebar-overlay,.filter-bar,.page-header .btn{display:none!important}.main-area{margin:0!important}}</style>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
