<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
requireRole([ROLE_ADMIN, ROLE_COORDINATOR]);
$user = currentUser();
$db   = getDB();

$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect(APP_URL . '/pages/students.php');

$s = $db->prepare("SELECT * FROM students WHERE id=? AND deleted_at IS NULL");
$s->execute([$id]);
$s = $s->fetch();
if (!$s) { flashMessage('חניך לא נמצא', 'danger'); redirect(APP_URL . '/pages/students.php'); }

/* קבוצה נוכחית */
$grpQ = $db->prepare("SELECT gs.group_id,g.program_id FROM group_student gs JOIN `groups` g ON g.id=gs.group_id WHERE gs.student_id=? AND gs.is_active=1 LIMIT 1");
$grpQ->execute([$id]);
$grpRow = $grpQ->fetch();
$curGid = $grpRow['group_id']   ?? 0;
$curPid = $grpRow['program_id'] ?? 0;

/* שמירה */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { flashMessage('בקשה לא תקינה', 'danger'); redirect(APP_URL . '/pages/student_edit.php?id=' . $id); }

    /* פרטים בסיסיים */
    $dup = $db->prepare("SELECT id FROM students WHERE national_id=? AND id!=?");
    $dup->execute([sanitize($_POST['national_id']), $id]);
    if ($dup->fetch()) {
        flashMessage('מספר זהות קיים', 'danger');
        redirect(APP_URL . '/pages/student_edit.php?id=' . $id);
    }

    $db->prepare("UPDATE students SET national_id=?,full_name=?,gender=?,birth_date=?,phone=?,school=?,grade=? WHERE id=?")
       ->execute([
           sanitize($_POST['national_id']),
           sanitize($_POST['full_name']),
           sanitize($_POST['gender'] ?? '') ?: null,
           sanitize($_POST['birth_date'] ?? '') ?: null,
           sanitize($_POST['phone'] ?? ''),
           sanitize($_POST['school'] ?? ''),
           sanitize($_POST['grade'] ?? ''),
           $id
       ]);

    /* שינוי קבוצה */
    $newGid = (int)($_POST['group_id'] ?? 0);
    if ($newGid !== $curGid) {
        if ($curGid) {
            $db->prepare("UPDATE group_student SET is_active=0,left_at=CURDATE() WHERE student_id=? AND group_id=? AND is_active=1")
               ->execute([$id, $curGid]);
        }
        if ($newGid) {
            $db->prepare("INSERT INTO group_student (group_id,student_id,is_active,joined_at) VALUES (?,?,1,CURDATE())")
               ->execute([$newGid, $id]);
        }
    }

    /* metadata */
    if (!empty($_POST['meta'])) {
        foreach ($_POST['meta'] as $fid => $val) {
            $fid = (int)$fid;
            $fdef = $db->prepare("SELECT * FROM metadata_fields WHERE id=? AND is_active=1");
            $fdef->execute([$fid]);
            $fdef = $fdef->fetch();
            if (!$fdef) continue;

            $vText = null; $vNum = null; $vDate = null; $vBool = null; $vJson = null;
            switch ($fdef['field_type']) {
                case 'text':   $vText = sanitize((string)$val); break;
                case 'number': $vNum  = is_numeric($val) ? (float)$val : null; break;
                case 'date':   $vDate = sanitize((string)$val) ?: null; break;
                case 'boolean':$vBool = $val ? 1 : 0; break;
                case 'select': $vJson = json_encode($val, JSON_UNESCAPED_UNICODE); break;
            }
            $db->prepare("INSERT INTO metadata_values (student_id,metadata_field_id,value_text,value_number,value_date,value_boolean,value_json)
                          VALUES (?,?,?,?,?,?,?)
                          ON DUPLICATE KEY UPDATE value_text=?,value_number=?,value_date=?,value_boolean=?,value_json=?")
               ->execute([$id,$fid,$vText,$vNum,$vDate,$vBool,$vJson,
                          $vText,$vNum,$vDate,$vBool,$vJson]);
        }
    }

    auditLog($db, $user['id'], 'edit_student', 'student', $id);
    flashMessage('פרטי החניך עודכנו', 'success');
    redirect(APP_URL . '/pages/student_detail.php?id=' . $id);
}

/* קבוצות לבחירה */
$groups = $db->query("SELECT g.*,p.name AS prog FROM `groups` g JOIN programs p ON p.id=g.program_id WHERE g.status='active' ORDER BY p.name,g.name")->fetchAll();

/* שדות metadata לפי תוכנית */
$metaFields = [];
if ($curPid) {
    $mf = $db->prepare("SELECT * FROM metadata_fields WHERE program_id=? AND is_active=1 ORDER BY sort_order");
    $mf->execute([$curPid]);
    $metaFields = $mf->fetchAll();
}
$metaVals = [];
$mv = $db->prepare("SELECT * FROM metadata_values WHERE student_id=?");
$mv->execute([$id]);
foreach ($mv->fetchAll() as $v) $metaVals[$v['metadata_field_id']] = $v;

$pageTitle = 'עריכת חניך – ' . $s['full_name'];
$activePage = 'students';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <h2>✏️ עריכת חניך</h2>
    <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $id ?>" class="btn btn-ghost btn-sm">← תיק חניך</a>
</div>

<form method="POST" novalidate>
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">

    <!-- פרטים אישיים -->
    <div class="card">
        <div class="card-title" style="margin-bottom:14px">👤 פרטים אישיים</div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">שם מלא <span class="req">*</span></label>
                <input type="text" name="full_name" class="form-control" value="<?= h($s['full_name']) ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">מספר זהות <span class="req">*</span></label>
                <input type="text" name="national_id" class="form-control" value="<?= h($s['national_id']) ?>"
                       required maxlength="9" pattern="[0-9]{9}" inputmode="numeric">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">מין</label>
                <select name="gender" class="form-control">
                    <option value="">—</option>
                    <option value="male"   <?= $s['gender']==='male'   ?'selected':'' ?>>זכר</option>
                    <option value="female" <?= $s['gender']==='female' ?'selected':'' ?>>נקבה</option>
                    <option value="other"  <?= $s['gender']==='other'  ?'selected':'' ?>>אחר</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">תאריך לידה</label>
                <input type="date" name="birth_date" class="form-control" value="<?= h($s['birth_date'] ?? '') ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">טלפון</label>
                <input type="tel" name="phone" class="form-control" value="<?= h($s['phone'] ?? '') ?>" inputmode="tel">
            </div>
            <div class="form-group">
                <label class="form-label">בית ספר</label>
                <input type="text" name="school" class="form-control" value="<?= h($s['school'] ?? '') ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="form-label">כיתה</label>
            <input type="text" name="grade" class="form-control" value="<?= h($s['grade'] ?? '') ?>" style="max-width:140px">
        </div>
    </div>

    <!-- שיוך קבוצה -->
    <div class="card">
        <div class="card-title" style="margin-bottom:14px">👥 קבוצה</div>
        <div class="form-group">
            <label class="form-label">קבוצה נוכחית</label>
            <select name="group_id" class="form-control">
                <option value="0">ללא קבוצה</option>
                <?php foreach ($groups as $g): ?>
                <option value="<?= $g['id'] ?>" <?= $curGid == $g['id'] ? 'selected' : '' ?>>
                    <?= h($g['name']) ?> – <?= h($g['prog']) ?>
                </option>
                <?php endforeach; ?>
            </select>
            <div class="form-hint">שינוי קבוצה יסיר את החניך מהקבוצה הקודמת</div>
        </div>
    </div>

    <!-- שדות metadata -->
    <?php if ($metaFields): ?>
    <div class="card">
        <div class="card-title" style="margin-bottom:14px">🔖 מידע נוסף</div>
        <?php foreach ($metaFields as $f): ?>
        <?php
            $v = $metaVals[$f['id']] ?? null;
            $curVal = '';
            if ($v) {
                switch ($f['field_type']) {
                    case 'text':   $curVal = $v['value_text']  ?? ''; break;
                    case 'number': $curVal = $v['value_number'] ?? ''; break;
                    case 'date':   $curVal = $v['value_date']  ?? ''; break;
                    case 'boolean':$curVal = $v['value_boolean']; break;
                    case 'select':
                        $j = json_decode($v['value_json'] ?? 'null');
                        $curVal = is_string($j) ? $j : ($v['value_text'] ?? '');
                        break;
                }
            }
            $opts = $f['field_type'] === 'select' ? json_decode($f['options_json'] ?? '[]', true) : [];
        ?>
        <div class="form-group">
            <label class="form-label">
                <?= h($f['field_label']) ?>
                <?php if ($f['is_required']): ?><span class="req">*</span><?php endif; ?>
            </label>
            <?php if ($f['field_type'] === 'text'): ?>
                <input type="text" name="meta[<?= $f['id'] ?>]" class="form-control" value="<?= h($curVal) ?>" <?= $f['is_required'] ? 'required' : '' ?>>
            <?php elseif ($f['field_type'] === 'number'): ?>
                <input type="number" name="meta[<?= $f['id'] ?>]" class="form-control" value="<?= h($curVal) ?>" step="any" <?= $f['is_required'] ? 'required' : '' ?>>
            <?php elseif ($f['field_type'] === 'date'): ?>
                <input type="date" name="meta[<?= $f['id'] ?>]" class="form-control" value="<?= h($curVal) ?>" <?= $f['is_required'] ? 'required' : '' ?>>
            <?php elseif ($f['field_type'] === 'boolean'): ?>
                <select name="meta[<?= $f['id'] ?>]" class="form-control">
                    <option value="0" <?= !$curVal ? 'selected' : '' ?>>לא</option>
                    <option value="1" <?= $curVal  ? 'selected' : '' ?>>כן</option>
                </select>
            <?php elseif ($f['field_type'] === 'select' && $opts): ?>
                <select name="meta[<?= $f['id'] ?>]" class="form-control" <?= $f['is_required'] ? 'required' : '' ?>>
                    <option value="">בחר...</option>
                    <?php foreach ($opts as $o): ?>
                    <option value="<?= h($o) ?>" <?= $curVal === $o ? 'selected' : '' ?>><?= h($o) ?></option>
                    <?php endforeach; ?>
                </select>
            <?php else: ?>
                <input type="text" name="meta[<?= $f['id'] ?>]" class="form-control" value="<?= h($curVal) ?>">
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div style="display:flex;gap:10px;margin-top:4px">
        <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $id ?>" class="btn btn-ghost" style="flex:1;justify-content:center">ביטול</a>
        <button type="submit" class="btn btn-primary" style="flex:2;min-height:48px;font-size:1rem">💾 שמור שינויים</button>
    </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
