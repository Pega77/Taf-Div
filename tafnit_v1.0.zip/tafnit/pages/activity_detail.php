<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin(); $user=currentUser(); $db=getDB();

$id=(int)($_GET['id']??0);
if(!$id) redirect(APP_URL.'/pages/activities.php');

$act=$db->prepare("SELECT a.*,p.name AS prog,g.name AS grp,at.name AS type_name,at.color,u.full_name AS creator FROM activities a JOIN programs p ON p.id=a.program_id JOIN `groups` g ON g.id=a.group_id JOIN activity_types at ON at.id=a.activity_type_id JOIN users u ON u.id=a.created_by_user_id WHERE a.id=? AND a.deleted_at IS NULL");
$act->execute([$id]); $act=$act->fetch();
if(!$act){flashMessage('פעילות לא נמצאה','danger');redirect(APP_URL.'/pages/activities.php');}

if(isInstructor()&&$user['group_id']&&$act['group_id']!=$user['group_id']){
    flashMessage('אין הרשאה','danger');redirect(APP_URL.'/pages/activities.php');
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!verify_csrf()){flashMessage('בקשה לא תקינה','danger');redirect(APP_URL.'/pages/activity_detail.php?id='.$id);}
    $action=$_POST['action']??'';

    if($action==='save_attendance'){
        $att=$_POST['attendance']??[];
        $stmt=$db->prepare("INSERT INTO activity_students (activity_id,student_id,participation_status) VALUES (?,?,?) ON DUPLICATE KEY UPDATE participation_status=?");
        foreach($att as $sid=>$status){
            $status=in_array($status,['present','absent'])?$status:'absent';
            $stmt->execute([$id,(int)$sid,$status,$status]);
        }
        if(!empty($_POST['activity_notes'])){
            $db->prepare("UPDATE activities SET notes=? WHERE id=?")->execute([sanitize($_POST['activity_notes']),$id]);
        }
        auditLog($db,$user['id'],'save_attendance','activity',$id);
        flashMessage('הנוכחות נשמרה','success');
        redirect(APP_URL.'/pages/activity_detail.php?id='.$id);
    }
    if($action==='delete_act'&&isCoordinator()){
        $db->prepare("UPDATE activities SET deleted_at=NOW() WHERE id=?")->execute([$id]);
        flashMessage('הפעילות נמחקה','success');redirect(APP_URL.'/pages/activities.php');
    }
}

$students=$db->prepare("SELECT s.id,s.full_name,s.national_id,s.status AS stu_status,acs.participation_status FROM activity_students acs JOIN students s ON s.id=acs.student_id WHERE acs.activity_id=? ORDER BY s.full_name");
$students->execute([$id]); $students=$students->fetchAll();
$pc=count(array_filter($students,fn($s)=>$s['participation_status']==='present'));
$tc=count($students);
$pct=$tc?round($pc/$tc*100):0;

$pageTitle='פעילות – '.formatDate($act['activity_date']); $activePage='activities';
require_once __DIR__ . '/../includes/header.php';
?>
<div style="margin-bottom:14px">
  <a href="<?= APP_URL ?>/pages/activities.php" class="btn btn-ghost btn-sm">← חזרה</a>
  <?php if(isCoordinator()): ?>
  <form method="POST" style="display:inline" onsubmit="return confirm('למחוק פעילות זו?')">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <input type="hidden" name="action" value="delete_act">
    <button type="submit" class="btn btn-danger btn-sm" style="float:left">🗑️ מחיקה</button>
  </form>
  <?php endif; ?>
</div>

<div class="card">
  <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
    <span class="badge badge-primary"><?= h($act['type_name']) ?></span>
    <span style="font-size:.82rem;color:var(--color-text-muted)"><?= h($act['prog']) ?></span>
  </div>
  <h2 style="font-size:1.1rem;margin-bottom:4px"><?= h($act['grp']) ?> · <?= formatDate($act['activity_date']) ?><?= $act['activity_time']?' '.formatTime($act['activity_time']):'' ?></h2>
  <?php if($act['location']): ?><p style="font-size:.84rem;color:var(--color-text-muted)">📍 <?= h($act['location']) ?></p><?php endif; ?>
</div>

<!-- סיכום נוכחות -->
<div class="card">
  <div style="display:grid;grid-template-columns:auto 1fr auto auto;gap:16px;align-items:center">
    <div style="text-align:center">
      <div style="font-size:1.8rem;font-weight:700;color:<?= attendanceColor($pct) ?>" id="att-pct"><?= $pct ?>%</div>
      <div style="font-size:.75rem;color:var(--color-text-muted)">נוכחות</div>
    </div>
    <div>
      <div class="progress-bar"><div class="progress-fill" id="att-bar" style="width:<?= $pct ?>%"></div></div>
      <div style="font-size:.8rem;color:var(--color-text-muted);margin-top:4px" id="att-counter"><?= $pc ?> / <?= $tc ?></div>
    </div>
    <div style="text-align:center"><div style="font-weight:700;color:var(--color-success)"><?= $pc ?></div><div style="font-size:.72rem;color:var(--color-text-muted)">נוכחים</div></div>
    <div style="text-align:center"><div style="font-weight:700;color:var(--color-danger)"><?= $tc-$pc ?></div><div style="font-size:.72rem;color:var(--color-text-muted)">נעדרים</div></div>
  </div>
  <div style="display:flex;gap:8px;margin-top:12px">
    <button id="markAllPresent" class="btn btn-secondary btn-sm" style="flex:1">✅ כולם נוכחים</button>
    <button id="markAllAbsent"  class="btn btn-ghost btn-sm"     style="flex:1">❌ כולם נעדרים</button>
  </div>
</div>

<form method="POST" id="att-form">
  <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
  <input type="hidden" name="action" value="save_attendance">

  <div class="card" style="padding:0">
    <?php foreach($students as $i=>$s): ?>
    <?php $ip=$s['participation_status']==='present'; $ia=$s['participation_status']==='absent'; ?>
    <div class="stu-row" id="srow-<?= $s['id'] ?>" style="display:flex;align-items:center;padding:11px 14px;border-bottom:1px solid var(--color-border);gap:10px;<?= $ip?'background:var(--color-success-bg)':($ia?'background:var(--color-danger-bg)':'') ?>">
      <div class="avatar"><?= h(initials($s['full_name'])) ?></div>
      <div style="flex:1;min-width:0">
        <div style="font-size:.9rem;font-weight:500"><a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $s['id'] ?>"><?= h($s['full_name']) ?></a></div>
        <div style="font-size:.78rem;color:var(--color-text-muted)">ת.ז. <?= h($s['national_id']) ?></div>
      </div>
      <input type="hidden" name="attendance[<?= $s['id'] ?>]" value="<?= $ip?'present':'absent' ?>">
      <div class="att-toggle">
        <button type="button" class="att-btn <?= $ip?'present':'' ?>" data-row="<?= $s['id'] ?>" data-status="present" aria-label="נוכח">✓</button>
        <button type="button" class="att-btn <?= $ia?'absent':'' ?>"  data-row="<?= $s['id'] ?>" data-status="absent"  aria-label="נעדר">✗</button>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if(!$students): ?>
    <div class="empty-state"><div class="empty-icon">🎒</div><p>אין חניכים בקבוצה</p></div>
    <?php endif; ?>
  </div>

  <!-- הערות -->
  <div class="card">
    <div class="form-group" style="margin-bottom:0">
      <label class="form-label">📝 הערות לפעילות</label>
      <textarea name="activity_notes" class="form-control" rows="3" placeholder="הוסף הערות, אירועים חריגים, תובנות..."><?= h($act['notes']??'') ?></textarea>
      <div class="form-hint">ההערות נשמרות בתיק הפעילות</div>
    </div>
  </div>

  <button type="submit" class="btn btn-primary btn-full" style="min-height:48px;font-size:1rem">💾 שמור נוכחות והערות</button>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
