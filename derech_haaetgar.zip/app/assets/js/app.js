// assets/js/app.js

document.addEventListener('DOMContentLoaded', () => {

  // ===== Sidebar Toggle =====
  const sidebar   = document.getElementById('sidebar');
  const mainArea  = document.getElementById('mainArea');
  const toggleBtn = document.getElementById('sidebarToggle');
  const SIDEBAR_KEY = 'sidebar_collapsed';

  function setSidebar(collapsed) {
    sidebar?.classList.toggle('collapsed', collapsed);
    mainArea?.classList.toggle('sidebar-collapsed', collapsed);
    localStorage.setItem(SIDEBAR_KEY, collapsed ? '1' : '0');
  }

  if (sidebar) {
    const initCollapsed = localStorage.getItem(SIDEBAR_KEY) === '1';
    setSidebar(initCollapsed);
    toggleBtn?.addEventListener('click', () => setSidebar(!sidebar.classList.contains('collapsed')));
  }

  // ===== Modals =====
  document.querySelectorAll('[data-modal-open]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.modalOpen;
      const modal = document.getElementById(id);
      if (modal) modal.style.display = 'flex';
    });
  });

  document.querySelectorAll('[data-modal-close]').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.closest('.modal-overlay').style.display = 'none';
    });
  });

  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) overlay.style.display = 'none';
    });
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay').forEach(o => o.style.display = 'none');
    }
  });

  // ===== Tabs =====
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.dataset.tabGroup;
      const target = btn.dataset.tab;
      document.querySelectorAll(`.tab-btn[data-tab-group="${group}"]`).forEach(b => b.classList.remove('active'));
      document.querySelectorAll(`.tab-panel[data-tab-group="${group}"]`).forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(target)?.classList.add('active');
    });
  });

  // ===== Attendance buttons =====
  document.querySelectorAll('.att-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.dataset.attGroup;
      const status = btn.dataset.status;
      document.querySelectorAll(`.att-btn[data-att-group="${group}"]`).forEach(b => {
        b.classList.remove('present', 'absent');
      });
      btn.classList.add(status);
      const hiddenInput = document.querySelector(`input[name="attendance[${group}]"]`);
      if (hiddenInput) hiddenInput.value = status;
      updateAttendanceCounter();
    });
  });

  function updateAttendanceCounter() {
    const total   = document.querySelectorAll('.att-btn[data-status="present"]').length;
    const present = document.querySelectorAll('.att-btn.present').length;
    const ctr = document.getElementById('att-counter');
    if (ctr) ctr.textContent = `${present} / ${total}`;
    const pct = document.getElementById('att-pct');
    if (pct && total) pct.textContent = Math.round(present / total * 100) + '%';
  }

  // ===== Mark all present/absent =====
  document.getElementById('markAllPresent')?.addEventListener('click', () => {
    document.querySelectorAll('.att-btn[data-status="present"]').forEach(btn => btn.click());
  });
  document.getElementById('markAllAbsent')?.addEventListener('click', () => {
    document.querySelectorAll('.att-btn[data-status="absent"]').forEach(btn => btn.click());
  });

  // ===== Auto-dismiss flash messages =====
  setTimeout(() => {
    document.querySelectorAll('.alert').forEach(el => {
      el.style.transition = 'opacity .4s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 400);
    });
  }, 3500);

  // ===== Table search =====
  document.querySelectorAll('[data-table-search]').forEach(input => {
    const tableId = input.dataset.tableSearch;
    input.addEventListener('input', () => {
      const q = input.value.toLowerCase();
      document.querySelectorAll(`#${tableId} tbody tr`).forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  });

});
