<?php
// dashboard.php

require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

requireLogin();
requireRole([ROLE_ADMIN, ROLE_COORDINATOR]);
$user = currentUser();
$db   = getDB();

// ===== סטטיסטיקות =====
$totalStudents   = (int)$db->query("SELECT COUNT(*) FROM students WHERE status='active' AND deleted_at IS NULL")->fetchColumn();
$frozenStudents  = (int)$db->query("SELECT COUNT(*) FROM students WHERE status='frozen' AND deleted_at IS NULL")->fetchColumn();
$totalGroups     = (int)$db->query("SELECT COUNT(*) FROM groups WHERE status='active'")->fetchColumn();
$totalActivities = (int)$db->query("SELECT COUNT(*) FROM activities WHERE deleted_at IS NULL")->fetchColumn();
$totalPrograms   = (int)$db->query("SELECT COUNT(*) FROM programs WHERE status='active'")->fetchColumn();

// פעילויות החודש
$monthActivities = (int)$db->query("
    SELECT COUNT(*) FROM activities
    WHERE deleted_at IS NULL AND MONTH(activity_date)=MONTH(CURDATE()) AND YEAR(activity_date)=YEAR(CURDATE())
")->fetchColumn();

// נוכחות ממוצעת
$avgAtt = $db->query("
    SELECT
        ROUND(100 * SUM(CASE WHEN participation_status='present' THEN 1 ELSE 0 END) / NULLIF(COUNT(*),0)) AS avg_pct
    FROM activity_students
")->fetchColumn();
$avgAtt = $avgAtt ?? 0;

// פעילויות אחרונות
$recentActivities = $db->query("
    SELECT a.*, p.name AS program_name, g.name AS group_name,
           at.name AS type_name, u.full_name AS created_by_name,
           COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS present_count,
           COUNT(acs.id) AS total_count
    FROM activities a
    JOIN programs p ON p.id = a.program_id
    JOIN groups g ON g.id = a.group_id
    JOIN activity_types at ON at.id = a.activity_type_id
    JOIN users u ON u.id = a.created_by_user_id
    LEFT JOIN activity_students acs ON acs.activity_id = a.id
    WHERE a.deleted_at IS NULL
    GROUP BY a.id
    ORDER BY a.activity_date DESC, a.created_at DESC
    LIMIT 8
")->fetchAll();

// קבוצות עם נוכחות נמוכה
$lowAttGroups = $db->query("
    SELECT g.id, g.name, p.name AS program_name,
           ROUND(100 * SUM(CASE WHEN acs.participation_status='present' THEN 1 ELSE 0 END) / NULLIF(COUNT(acs.id),0)) AS att_pct
    FROM groups g
    JOIN programs p ON p.id = g.program_id
    LEFT JOIN activities a ON a.group_id = g.id AND a.deleted_at IS NULL
    LEFT JOIN activity_students acs ON acs.activity_id = a.id
    WHERE g.status = 'active'
    GROUP BY g.id
    HAVING att_pct IS NOT NULL AND att_pct < 70
    ORDER BY att_pct ASC
    LIMIT 5
")->fetchAll();

$pageTitle  = 'דשבורד';
$activePage = 'dashboard';
require_once __DIR__ . '/includes/header.php';
?>

<!-- כרטיסי סטטיסטיקה -->
<div class="stats-grid" style="margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-icon">🎒</div>
    <div class="stat-value"><?= $totalStudents ?></div>
    <div class="stat-label">חניכים פעילים</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">👥</div>
    <div class="stat-value"><?= $totalGroups ?></div>
    <div class="stat-label">קבוצות פעילות</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">📅</div>
    <div class="stat-value"><?= $monthActivities ?></div>
    <div class="stat-label">פעילויות החודש</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">✅</div>
    <div class="stat-value"><?= $avgAtt ?>%</div>
    <div class="stat-label">נוכחות ממוצעת</div>
  </div>
  <?php if ($frozenStudents): ?>
  <div class="stat-card">
    <div class="stat-icon">❄️</div>
    <div class="stat-value" style="color:var(--color-warning)"><?= $frozenStudents ?></div>
    <div class="stat-label">חניכים מוקפאים</div>
  </div>
  <?php endif; ?>
</div>

<div style="display:grid;grid-template-columns:1fr 360px;gap:20px;align-items:start">

  <!-- פעילויות אחרונות -->
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <h3 style="font-size:1rem">פעילויות אחרונות</h3>
      <a href="<?= APP_URL ?>/pages/activities.php" class="btn btn-ghost btn-sm">הכל →</a>
    </div>
    <?php if ($recentActivities): ?>
    <div class="table-wrapper">
      <table class="data-table">
        <thead>
          <tr>
            <th>תאריך</th>
            <th>קבוצה</th>
            <th>סוג</th>
            <th>נוכחות</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($recentActivities as $a): ?>
          <?php $pct = $a['total_count'] ? round($a['present_count'] / $a['total_count'] * 100) : 0; ?>
          <tr>
            <td style="white-space:nowrap"><?= formatDate($a['activity_date']) ?></td>
            <td>
              <a href="<?= APP_URL ?>/pages/activity_detail.php?id=<?= $a['id'] ?>">
                <?= h($a['group_name']) ?>
              </a>
              <div style="font-size:.75rem;color:var(--color-text-muted)"><?= h($a['program_name']) ?></div>
            </td>
            <td><span class="badge badge-primary"><?= h($a['type_name']) ?></span></td>
            <td>
              <div style="display:flex;align-items:center;gap:8px">
                <div class="progress-bar" style="width:60px">
                  <div class="progress-fill" style="width:<?= $pct ?>%"></div>
                </div>
                <span style="font-size:.8rem;font-weight:600;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <div class="empty-state" style="padding:32px">
      <div class="empty-icon">📅</div><p>אין פעילויות עדיין</p>
    </div>
    <?php endif; ?>
  </div>

  <!-- צד ימין -->
  <div style="display:flex;flex-direction:column;gap:16px">

    <!-- קבוצות עם נוכחות נמוכה -->
    <?php if ($lowAttGroups): ?>
    <div class="card">
      <h3 style="font-size:1rem;margin-bottom:14px;color:var(--color-danger)">⚠️ נוכחות נמוכה</h3>
      <?php foreach ($lowAttGroups as $g): ?>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <div>
          <a href="<?= APP_URL ?>/pages/groups.php?open=<?= $g['id'] ?>" style="font-weight:500;font-size:.9rem">
            <?= h($g['name']) ?>
          </a>
          <div style="font-size:.75rem;color:var(--color-text-muted)"><?= h($g['program_name']) ?></div>
        </div>
        <span style="font-weight:700;color:<?= attendanceColor($g['att_pct']) ?>"><?= $g['att_pct'] ?>%</span>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- קישורים מהירים -->
    <div class="card">
      <h3 style="font-size:1rem;margin-bottom:14px">פעולות מהירות</h3>
      <div style="display:flex;flex-direction:column;gap:8px">
        <a href="<?= APP_URL ?>/pages/activities.php?action=new" class="btn btn-primary" style="justify-content:center">
          ➕ פעילות חדשה
        </a>
        <a href="<?= APP_URL ?>/pages/students.php?action=new" class="btn btn-secondary" style="justify-content:center">
          🎒 חניך חדש
        </a>
        <a href="<?= APP_URL ?>/pages/reports.php" class="btn btn-secondary" style="justify-content:center">
          📈 הפקת דוח
        </a>
      </div>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
