<?php
// includes/helpers.php

function h(mixed $v): string {
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function sanitize(string $v): string {
    return trim(strip_tags($v));
}

function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

function formatDate(?string $d, string $format = 'd/m/Y'): string {
    if (!$d) return '—';
    try { return (new DateTime($d))->format($format); }
    catch (Exception) { return $d; }
}

function roleLabel(string $role): string {
    return ROLE_LABELS[$role] ?? $role;
}

function initials(string $name): string {
    $parts = explode(' ', trim($name));
    if (count($parts) >= 2) return mb_substr($parts[0], 0, 1) . mb_substr($parts[1], 0, 1);
    return mb_substr($name, 0, 2);
}

function attendanceColor(int $pct): string {
    if ($pct >= 70) return 'var(--color-success)';
    if ($pct >= 50) return 'var(--color-warning)';
    return 'var(--color-danger)';
}

function statusBadge(string $status): string {
    return match($status) {
        'active'   => '<span class="badge badge-success">פעיל</span>',
        'frozen'   => '<span class="badge badge-warning">מוקפא</span>',
        'inactive' => '<span class="badge badge-muted">לא פעיל</span>',
        default    => '<span class="badge">' . h($status) . '</span>',
    };
}
