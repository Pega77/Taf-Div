    </div><!-- /page-content -->
  </div><!-- /main-area -->
</div><!-- /app-shell -->

<script src="<?= APP_URL ?>/assets/js/app.js"></script>
</body>
</html>
