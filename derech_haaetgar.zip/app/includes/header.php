<?php
// includes/header.php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
requireLogin();
$user  = currentUser();
$flash = getFlash();
$activePage = $activePage ?? '';
$pageTitle  = $pageTitle  ?? APP_NAME;
?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= h($pageTitle) ?> – <?= h(APP_NAME) ?></title>
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/variables.css">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/base.css">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/layout.css">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/components.css">
</head>
<body>
<div class="app-shell">

  <!-- ===== Sidebar ===== -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
      <div class="sidebar-logo">🏔️</div>
      <span class="sidebar-title"><?= h(APP_NAME) ?></span>
    </div>

    <nav class="sidebar-nav">

      <?php if (!isInstructor()): ?>
      <div class="nav-section-title">ניהול</div>
      <a href="<?= APP_URL ?>/dashboard.php"
         class="nav-item <?= $activePage === 'dashboard' ? 'active' : '' ?>">
        <span class="nav-icon">📊</span>
        <span class="nav-label">דשבורד</span>
      </a>
      <?php endif; ?>

      <?php if (isAdmin()): ?>
      <a href="<?= APP_URL ?>/pages/programs.php"
         class="nav-item <?= $activePage === 'programs' ? 'active' : '' ?>">
        <span class="nav-icon">🗂️</span>
        <span class="nav-label">תוכניות</span>
      </a>
      <?php endif; ?>

      <?php if (!isInstructor()): ?>
      <a href="<?= APP_URL ?>/pages/groups.php"
         class="nav-item <?= $activePage === 'groups' ? 'active' : '' ?>">
        <span class="nav-icon">👥</span>
        <span class="nav-label">קבוצות</span>
      </a>
      <a href="<?= APP_URL ?>/pages/students.php"
         class="nav-item <?= $activePage === 'students' ? 'active' : '' ?>">
        <span class="nav-icon">🎒</span>
        <span class="nav-label">חניכים</span>
      </a>
      <a href="<?= APP_URL ?>/pages/activities.php"
         class="nav-item <?= $activePage === 'activities' ? 'active' : '' ?>">
        <span class="nav-icon">📅</span>
        <span class="nav-label">פעילויות</span>
      </a>
      <a href="<?= APP_URL ?>/pages/reports.php"
         class="nav-item <?= $activePage === 'reports' ? 'active' : '' ?>">
        <span class="nav-icon">📈</span>
        <span class="nav-label">דוחות</span>
      </a>
      <?php endif; ?>

      <?php if (isInstructor()): ?>
      <div class="nav-section-title">הקבוצה שלי</div>
      <a href="<?= APP_URL ?>/pages/my_group.php"
         class="nav-item <?= $activePage === 'my_group' ? 'active' : '' ?>">
        <span class="nav-icon">👥</span>
        <span class="nav-label">הקבוצה שלי</span>
      </a>
      <a href="<?= APP_URL ?>/pages/activities.php"
         class="nav-item <?= $activePage === 'activities' ? 'active' : '' ?>">
        <span class="nav-icon">📅</span>
        <span class="nav-label">פעילויות</span>
      </a>
      <?php endif; ?>

      <?php if (isAdmin()): ?>
      <div class="nav-section-title">הגדרות</div>
      <a href="<?= APP_URL ?>/pages/users.php"
         class="nav-item <?= $activePage === 'users' ? 'active' : '' ?>">
        <span class="nav-icon">👤</span>
        <span class="nav-label">משתמשים</span>
      </a>
      <a href="<?= APP_URL ?>/pages/activity_types.php"
         class="nav-item <?= $activePage === 'activity_types' ? 'active' : '' ?>">
        <span class="nav-icon">🏷️</span>
        <span class="nav-label">סוגי פעילות</span>
      </a>
      <a href="<?= APP_URL ?>/pages/metadata.php"
         class="nav-item <?= $activePage === 'metadata' ? 'active' : '' ?>">
        <span class="nav-icon">🔧</span>
        <span class="nav-label">שדות מותאמים</span>
      </a>
      <a href="<?= APP_URL ?>/pages/audit.php"
         class="nav-item <?= $activePage === 'audit' ? 'active' : '' ?>">
        <span class="nav-icon">📋</span>
        <span class="nav-label">יומן פעולות</span>
      </a>
      <?php endif; ?>

    </nav>

    <div class="sidebar-footer">
      <div class="user-info">
        <div class="user-avatar"><?= h(initials($user['name'])) ?></div>
        <div class="user-details">
          <div class="user-name"><?= h($user['name']) ?></div>
          <div class="user-role"><?= h(roleLabel($user['role'])) ?></div>
        </div>
      </div>
    </div>
  </aside>

  <!-- ===== Main Area ===== -->
  <div class="main-area" id="mainArea">
    <!-- Topbar -->
    <header class="topbar">
      <div class="topbar-left">
        <button class="btn btn-ghost btn-icon" id="sidebarToggle" aria-label="תפריט">☰</button>
        <h1 class="topbar-title"><?= h($pageTitle) ?></h1>
      </div>
      <div style="display:flex;align-items:center;gap:10px">
        <span style="font-size:.82rem;color:var(--color-text-muted)"><?= h($user['name']) ?></span>
        <a href="<?= APP_URL ?>/logout.php" class="btn btn-ghost btn-sm" title="יציאה">🚪</a>
      </div>
    </header>

    <!-- Flash -->
    <?php if ($flash): ?>
    <div style="padding:16px 24px 0">
      <div class="alert alert-<?= h($flash['type']) ?>"><?= h($flash['message']) ?></div>
    </div>
    <?php endif; ?>

    <!-- Page Content -->
    <div class="page-content">
