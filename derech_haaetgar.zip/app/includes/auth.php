<?php
// includes/auth.php

require_once __DIR__ . '/../config/app.php';

function startSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => SESSION_TIMEOUT,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_start();
    }
}

function requireLogin(): void {
    startSession();
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . APP_URL . '/index.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
    if (!empty($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_TIMEOUT) {
        session_destroy();
        header('Location: ' . APP_URL . '/index.php?expired=1');
        exit;
    }
    $_SESSION['last_activity'] = time();
}

function requireRole(string|array $roles): void {
    requireLogin();
    $roles = (array)$roles;
    if (!in_array($_SESSION['user_role'] ?? '', $roles)) {
        http_response_code(403);
        die('<div style="font-family:sans-serif;text-align:center;padding:60px;direction:rtl">
            <h2>אין הרשאה</h2><p>אין לך גישה לדף זה.</p>
            <a href="' . APP_URL . '/dashboard.php">חזרה לדשבורד</a></div>');
    }
}

function currentUser(): array {
    startSession();
    return [
        'id'         => $_SESSION['user_id']   ?? 0,
        'name'       => $_SESSION['user_name'] ?? '',
        'role'       => $_SESSION['user_role'] ?? '',
        'group_id'   => $_SESSION['group_id']  ?? null,
        'program_id' => $_SESSION['program_id'] ?? null,
    ];
}

function isAdmin(): bool {
    return (currentUser()['role'] === ROLE_ADMIN);
}

function isCoordinator(): bool {
    return in_array(currentUser()['role'], [ROLE_ADMIN, ROLE_COORDINATOR]);
}

function isInstructor(): bool {
    return (currentUser()['role'] === ROLE_INSTRUCTOR);
}

// CSRF
function csrf_token(): string {
    startSession();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(): bool {
    return isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token']);
}

// Flash messages
function flashMessage(string $message, string $type = 'info'): void {
    startSession();
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}

function getFlash(): ?array {
    startSession();
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}
