<?php
// pages/activity_detail.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
$user = currentUser();
$db   = getDB();

$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect(APP_URL . '/pages/activities.php');

$activity = $db->prepare("
    SELECT a.*, p.name AS program_name, g.name AS group_name,
           at.name AS type_name, u.full_name AS created_by_name
    FROM activities a
    JOIN programs p ON p.id = a.program_id
    JOIN groups g ON g.id = a.group_id
    JOIN activity_types at ON at.id = a.activity_type_id
    JOIN users u ON u.id = a.created_by_user_id
    WHERE a.id = ? AND a.deleted_at IS NULL
");
$activity->execute([$id]);
$activity = $activity->fetch();
if (!$activity) { flashMessage('פעילות לא נמצאה', 'danger'); redirect(APP_URL . '/pages/activities.php'); }

// מדריך: רק קבוצה שלו
if (isInstructor() && $user['group_id'] && $activity['group_id'] != $user['group_id']) {
    flashMessage('אין הרשאה', 'danger');
    redirect(APP_URL . '/pages/activities.php');
}

// ===== POST: שמירת נוכחות =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { flashMessage('בקשה לא תקינה', 'danger'); redirect(APP_URL . '/pages/activity_detail.php?id=' . $id); }

    $action = $_POST['action'] ?? '';

    if ($action === 'save_attendance') {
        $attendance = $_POST['attendance'] ?? [];
        $stmt = $db->prepare("
            INSERT INTO activity_students (activity_id, student_id, participation_status)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE participation_status = ?
        ");
        foreach ($attendance as $studentId => $status) {
            $status = in_array($status, ['present', 'absent']) ? $status : 'absent';
            $stmt->execute([$id, (int)$studentId, $status, $status]);
        }
        flashMessage('הנוכחות נשמרה בהצלחה', 'success');
        redirect(APP_URL . '/pages/activity_detail.php?id=' . $id);
    }

    if ($action === 'delete_activity' && !isInstructor()) {
        $db->prepare("UPDATE activities SET deleted_at = NOW() WHERE id = ?")->execute([$id]);
        flashMessage('הפעילות נמחקה', 'success');
        redirect(APP_URL . '/pages/activities.php');
    }
}

// חניכים ונוכחות
$students = $db->prepare("
    SELECT s.id, s.full_name, s.national_id, s.status AS student_status,
           acs.participation_status
    FROM activity_students acs
    JOIN students s ON s.id = acs.student_id
    WHERE acs.activity_id = ?
    ORDER BY s.full_name
");
$students->execute([$id]);
$students = $students->fetchAll();

$presentCount = count(array_filter($students, fn($s) => $s['participation_status'] === 'present'));
$totalCount   = count($students);
$pct          = $totalCount ? round($presentCount / $totalCount * 100) : 0;

$pageTitle  = 'פעילות – ' . formatDate($activity['activity_date']);
$activePage = 'activities';
require_once __DIR__ . '/../includes/header.php';
?>

<!-- כותרת -->
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px">
  <div>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
      <span class="badge badge-primary"><?= h($activity['type_name']) ?></span>
      <span style="color:var(--color-text-muted);font-size:.88rem"><?= h($activity['program_name']) ?></span>
    </div>
    <h2 style="font-size:1.4rem;margin-bottom:4px">
      <?= h($activity['group_name']) ?> · <?= formatDate($activity['activity_date']) ?>
    </h2>
    <p style="font-size:.82rem;color:var(--color-text-muted)">
      נוצר ע"י <?= h($activity['created_by_name']) ?>
      <?= $activity['notes'] ? ' · ' . h($activity['notes']) : '' ?>
    </p>
  </div>
  <div style="display:flex;gap:8px">
    <a href="<?= APP_URL ?>/pages/activities.php" class="btn btn-ghost btn-sm">← חזרה</a>
    <?php if (!isInstructor()): ?>
    <button class="btn btn-danger btn-sm"
            onclick="if(confirm('למחוק פעילות זו?')){document.getElementById('form-delete').submit()}">
      🗑️ מחיקה
    </button>
    <?php endif; ?>
  </div>
</div>

<!-- סיכום נוכחות -->
<div class="card" style="margin-bottom:20px">
  <div style="display:flex;align-items:center;gap:24px;flex-wrap:wrap">
    <div style="text-align:center;min-width:70px">
      <div style="font-size:2.2rem;font-weight:700;color:<?= attendanceColor($pct) ?>" id="att-pct"><?= $pct ?>%</div>
      <div style="font-size:.78rem;color:var(--color-text-muted)">נוכחות</div>
    </div>
    <div style="flex:1;min-width:120px">
      <div class="progress-bar" style="height:10px">
        <div class="progress-fill" style="width:<?= $pct ?>%"></div>
      </div>
      <div style="font-size:.82rem;color:var(--color-text-muted);margin-top:6px" id="att-counter">
        <?= $presentCount ?> / <?= $totalCount ?> נוכחים
      </div>
    </div>
    <div style="display:flex;gap:8px">
      <button class="btn btn-secondary btn-sm" id="markAllPresent">✅ כולם נוכחים</button>
      <button class="btn btn-ghost btn-sm" id="markAllAbsent">❌ כולם נעדרים</button>
    </div>
  </div>
</div>

<!-- טופס נוכחות -->
<div class="card">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
    <h3 style="font-size:1rem">סימון נוכחות (<?= $totalCount ?> חניכים)</h3>
  </div>

  <?php if ($students): ?>
  <form method="POST" id="attendance-form">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <input type="hidden" name="action" value="save_attendance">

    <div class="table-wrapper">
      <table class="data-table">
        <thead>
          <tr>
            <th>#</th>
            <th>שם חניך</th>
            <th>ת.ז.</th>
            <th style="text-align:center">נוכחות</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($students as $i => $s): ?>
          <?php $isPresent = $s['participation_status'] === 'present'; ?>
          <tr id="row-<?= $s['id'] ?>" style="<?= $isPresent ? 'background:var(--color-success-bg)' : '' ?>">
            <td style="color:var(--color-text-muted);font-size:.82rem"><?= $i + 1 ?></td>
            <td>
              <div style="display:flex;align-items:center;gap:10px">
                <div class="user-avatar" style="width:30px;height:30px;font-size:.7rem"><?= h(initials($s['full_name'])) ?></div>
                <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $s['id'] ?>" style="font-weight:500">
                  <?= h($s['full_name']) ?>
                </a>
                <?php if ($s['student_status'] === 'frozen'): ?>
                <span class="badge badge-warning" style="font-size:.7rem">מוקפא</span>
                <?php endif; ?>
              </div>
            </td>
            <td style="font-size:.82rem;color:var(--color-text-muted)"><?= h($s['national_id']) ?></td>
            <td style="text-align:center">
              <input type="hidden" name="attendance[<?= $s['id'] ?>]"
                     value="<?= $isPresent ? 'present' : 'absent' ?>"
                     id="att-input-<?= $s['id'] ?>">
              <div style="display:flex;gap:8px;justify-content:center">
                <button type="button"
                        class="att-btn <?= $isPresent ? 'present' : '' ?>"
                        data-att-group="<?= $s['id'] ?>"
                        data-status="present"
                        data-student-id="<?= $s['id'] ?>"
                        onclick="setAttendance(<?= $s['id'] ?>, 'present')">
                  ✓ נוכח
                </button>
                <button type="button"
                        class="att-btn <?= !$isPresent ? 'absent' : '' ?>"
                        data-att-group="<?= $s['id'] ?>"
                        data-status="absent"
                        data-student-id="<?= $s['id'] ?>"
                        onclick="setAttendance(<?= $s['id'] ?>, 'absent')">
                  ✗ נעדר
                </button>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div style="display:flex;justify-content:flex-end;margin-top:16px;gap:10px">
      <button type="submit" class="btn btn-primary">💾 שמור נוכחות</button>
    </div>
  </form>
  <?php else: ?>
  <div class="empty-state">
    <div class="empty-icon">🎒</div>
    <h3>אין חניכים בקבוצה</h3>
    <p>שייך חניכים לקבוצה תחילה</p>
  </div>
  <?php endif; ?>
</div>

<!-- מחיקה -->
<form id="form-delete" method="POST" style="display:none">
  <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
  <input type="hidden" name="action" value="delete_activity">
</form>

<script>
let presentCount = <?= $presentCount ?>;
let totalCount   = <?= $totalCount ?>;

function setAttendance(studentId, status) {
  const input = document.getElementById('att-input-' + studentId);
  const prev  = input.value;
  input.value = status;

  const row = document.getElementById('row-' + studentId);
  row.style.background = status === 'present' ? 'var(--color-success-bg)' : '';

  if (prev !== status) {
    if (status === 'present') presentCount++;
    else presentCount--;
  }

  const pct = totalCount ? Math.round(presentCount / totalCount * 100) : 0;
  document.getElementById('att-counter').textContent = presentCount + ' / ' + totalCount + ' נוכחים';
  document.getElementById('att-pct').textContent = pct + '%';
  document.getElementById('att-pct').style.color = pct >= 70 ? 'var(--color-success)' : pct >= 50 ? 'var(--color-warning)' : 'var(--color-danger)';
}

document.getElementById('markAllPresent')?.addEventListener('click', () => {
  document.querySelectorAll('[data-status="present"]').forEach(btn => {
    const sid = btn.dataset.studentId;
    const input = document.getElementById('att-input-' + sid);
    if (input && input.value !== 'present') {
      input.value = 'present';
      document.getElementById('row-' + sid).style.background = 'var(--color-success-bg)';
    }
    btn.classList.add('present');
    btn.closest('td').querySelector('[data-status="absent"]').classList.remove('absent');
  });
  presentCount = totalCount;
  const pct = 100;
  document.getElementById('att-counter').textContent = presentCount + ' / ' + totalCount + ' נוכחים';
  document.getElementById('att-pct').textContent = pct + '%';
  document.getElementById('att-pct').style.color = 'var(--color-success)';
});

document.getElementById('markAllAbsent')?.addEventListener('click', () => {
  document.querySelectorAll('[data-status="absent"]').forEach(btn => {
    const sid = btn.dataset.studentId;
    const input = document.getElementById('att-input-' + sid);
    if (input) input.value = 'absent';
    document.getElementById('row-' + sid).style.background = '';
    btn.classList.add('absent');
    btn.closest('td').querySelector('[data-status="present"]').classList.remove('present');
  });
  presentCount = 0;
  document.getElementById('att-counter').textContent = '0 / ' + totalCount + ' נוכחים';
  document.getElementById('att-pct').textContent = '0%';
  document.getElementById('att-pct').style.color = 'var(--color-danger)';
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
