<?php
// pages/groups.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
requireRole([ROLE_ADMIN, ROLE_COORDINATOR]);
$user = currentUser();
$db   = getDB();

// ===== POST =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { flashMessage('בקשה לא תקינה', 'danger'); redirect(APP_URL . '/pages/groups.php'); }

    $action = $_POST['action'] ?? '';

    if ($action === 'add_group') {
        $db->prepare("INSERT INTO groups (program_id, name, instructor_user_id, status) VALUES (?,?,?,?)")
           ->execute([
               (int)$_POST['program_id'],
               sanitize($_POST['name']),
               (int)$_POST['instructor_user_id'],
               'active',
           ]);
        flashMessage('הקבוצה נוצרה', 'success');
        redirect(APP_URL . '/pages/groups.php');
    }

    if ($action === 'edit_group') {
        $db->prepare("UPDATE groups SET program_id=?, name=?, instructor_user_id=? WHERE id=?")
           ->execute([
               (int)$_POST['program_id'],
               sanitize($_POST['name']),
               (int)$_POST['instructor_user_id'],
               (int)$_POST['group_id'],
           ]);
        flashMessage('הקבוצה עודכנה', 'success');
        redirect(APP_URL . '/pages/groups.php');
    }

    if ($action === 'toggle_group' && isAdmin()) {
        $g = $db->prepare("SELECT status FROM groups WHERE id=?");
        $g->execute([(int)$_POST['group_id']]);
        $cur = $g->fetchColumn();
        $db->prepare("UPDATE groups SET status=? WHERE id=?")
           ->execute([$cur === 'active' ? 'inactive' : 'active', (int)$_POST['group_id']]);
        flashMessage('סטטוס הקבוצה עודכן', 'success');
        redirect(APP_URL . '/pages/groups.php');
    }

    if ($action === 'assign_student') {
        $check = $db->prepare("SELECT id FROM group_student WHERE student_id=? AND is_active=1");
        $check->execute([(int)$_POST['student_id']]);
        if ($check->fetch()) {
            flashMessage('חניך זה כבר משויך לקבוצה', 'warning');
        } else {
            $db->prepare("INSERT INTO group_student (group_id, student_id, is_active, joined_at) VALUES (?,?,1,CURDATE())")
               ->execute([(int)$_POST['group_id'], (int)$_POST['student_id']]);
            flashMessage('החניך שויך', 'success');
        }
        redirect(APP_URL . '/pages/groups.php?open=' . (int)$_POST['group_id']);
    }

    if ($action === 'remove_student') {
        $db->prepare("UPDATE group_student SET is_active=0, left_at=CURDATE() WHERE student_id=? AND group_id=? AND is_active=1")
           ->execute([(int)$_POST['student_id'], (int)$_POST['group_id']]);
        flashMessage('החניך הוסר', 'success');
        redirect(APP_URL . '/pages/groups.php?open=' . (int)$_POST['group_id']);
    }
}

// ===== Data =====
$groups = $db->query("
    SELECT g.*, p.name AS program_name, u.full_name AS instructor_name,
           COUNT(DISTINCT gs.student_id) AS student_count,
           COUNT(DISTINCT a.id) AS activity_count
    FROM groups g
    JOIN programs p ON p.id = g.program_id
    LEFT JOIN users u ON u.id = g.instructor_user_id
    LEFT JOIN group_student gs ON gs.group_id = g.id AND gs.is_active = 1
    LEFT JOIN activities a ON a.group_id = g.id AND a.deleted_at IS NULL
    GROUP BY g.id
    ORDER BY p.name, g.name
")->fetchAll();

$programs    = $db->query("SELECT * FROM programs WHERE status='active' ORDER BY name")->fetchAll();
$instructors = $db->query("SELECT id, full_name FROM users WHERE role='instructor' AND is_active=1 ORDER BY full_name")->fetchAll();

$unassigned = $db->query("
    SELECT id, full_name, national_id FROM students
    WHERE status='active' AND deleted_at IS NULL
      AND id NOT IN (SELECT student_id FROM group_student WHERE is_active=1)
    ORDER BY full_name
")->fetchAll();

$openGroupId = (int)($_GET['open'] ?? 0);

// קבוצות לפי תוכנית
$byProgram = [];
foreach ($groups as $g) $byProgram[$g['program_name']][] = $g;

$pageTitle  = 'קבוצות';
$activePage = 'groups';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
  <div>
    <h2 style="font-size:1.5rem;margin-bottom:4px">קבוצות</h2>
    <p style="color:var(--color-text-muted);font-size:.9rem"><?= count($groups) ?> קבוצות</p>
  </div>
  <?php if (isAdmin()): ?>
  <button class="btn btn-primary" data-modal-open="modal-add-group">➕ קבוצה חדשה</button>
  <?php endif; ?>
</div>

<?php foreach ($byProgram as $progName => $progGroups): ?>
<div style="margin-bottom:28px">
  <div style="font-weight:700;color:var(--color-primary);font-size:1rem;margin-bottom:12px;display:flex;align-items:center;gap:8px">
    🗂️ <?= h($progName) ?>
    <span class="badge badge-primary"><?= count($progGroups) ?></span>
  </div>

  <div style="display:grid;gap:12px">
    <?php foreach ($progGroups as $g): ?>
    <?php $isOpen = $openGroupId == $g['id']; ?>
    <div class="card" style="padding:0;overflow:hidden">
      <!-- Header row -->
      <div style="display:flex;justify-content:space-between;align-items:center;padding:16px 20px;cursor:pointer"
           onclick="toggleGroup(<?= $g['id'] ?>)">
        <div style="display:flex;align-items:center;gap:14px">
          <div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,var(--color-primary),var(--color-accent));display:flex;align-items:center;justify-content:center;font-size:1.4rem">👥</div>
          <div>
            <div style="font-weight:600">
              <?= h($g['name']) ?>
              <?= $g['status'] !== 'active' ? '<span class="badge badge-muted" style="font-size:.7rem;margin-right:6px">לא פעיל</span>' : '' ?>
            </div>
            <div style="font-size:.8rem;color:var(--color-text-muted)">
              👤 <?= h($g['instructor_name'] ?? 'ללא מדריך') ?>
            </div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:20px">
          <div style="text-align:center">
            <div style="font-weight:700;font-size:1.2rem;color:var(--color-primary)"><?= $g['student_count'] ?></div>
            <div style="font-size:.7rem;color:var(--color-text-muted)">חניכים</div>
          </div>
          <div style="text-align:center">
            <div style="font-weight:700;font-size:1.2rem;color:var(--color-accent)"><?= $g['activity_count'] ?></div>
            <div style="font-size:.7rem;color:var(--color-text-muted)">פעילויות</div>
          </div>
          <div style="display:flex;gap:6px;align-items:center">
            <?php if (isAdmin()): ?>
            <button class="btn btn-ghost btn-sm btn-icon"
                    onclick="event.stopPropagation();openEditGroup(<?= htmlspecialchars(json_encode($g), ENT_QUOTES) ?>)"
                    title="עריכה">✏️</button>
            <form method="POST" style="display:inline" onclick="event.stopPropagation()">
              <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
              <input type="hidden" name="action" value="toggle_group">
              <input type="hidden" name="group_id" value="<?= $g['id'] ?>">
              <button type="submit" class="btn btn-ghost btn-sm btn-icon"
                      title="<?= $g['status']==='active'?'השבת':'הפעל' ?>">
                <?= $g['status']==='active' ? '⏸️' : '▶️' ?>
              </button>
            </form>
            <?php endif; ?>
            <span id="chevron-<?= $g['id'] ?>" style="color:var(--color-text-muted)"><?= $isOpen ? '▲' : '▼' ?></span>
          </div>
        </div>
      </div>

      <!-- Body: students -->
      <div id="group-body-<?= $g['id'] ?>" style="<?= $isOpen ? '' : 'display:none' ?>;border-top:1px solid var(--color-border)">
        <?php
        $gStudents = $db->prepare("
            SELECT s.id, s.full_name, s.national_id, s.status AS student_status,
                   COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS present_count,
                   COUNT(acs.id) AS total_count
            FROM group_student gs
            JOIN students s ON s.id = gs.student_id
            LEFT JOIN activity_students acs ON acs.student_id = s.id
            LEFT JOIN activities act ON act.id = acs.activity_id AND act.group_id = ? AND act.deleted_at IS NULL
            WHERE gs.group_id = ? AND gs.is_active = 1
            GROUP BY s.id ORDER BY s.full_name
        ");
        $gStudents->execute([$g['id'], $g['id']]);
        $gStudents = $gStudents->fetchAll();
        ?>
        <div style="padding:16px 20px">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
            <span style="font-weight:600;font-size:.9rem">חניכים (<?= count($gStudents) ?>)</span>
            <div style="display:flex;gap:8px">
              <a href="<?= APP_URL ?>/pages/activities.php?group_id=<?= $g['id'] ?>" class="btn btn-ghost btn-sm">📅 פעילויות</a>
              <button class="btn btn-secondary btn-sm"
                      onclick="openAssign(<?= $g['id'] ?>, '<?= h(addslashes($g['name'])) ?>')">
                ➕ שייך חניך
              </button>
            </div>
          </div>

          <?php if ($gStudents): ?>
          <div class="table-wrapper">
            <table class="data-table">
              <thead><tr><th>שם</th><th>ת.ז.</th><th>נוכחות</th><th>סטטוס</th><th></th></tr></thead>
              <tbody>
                <?php foreach ($gStudents as $s): ?>
                <?php $pct = $s['total_count'] ? round($s['present_count']/$s['total_count']*100) : 0; ?>
                <tr>
                  <td>
                    <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $s['id'] ?>" style="font-weight:500">
                      <?= h($s['full_name']) ?>
                    </a>
                  </td>
                  <td style="font-size:.82rem;color:var(--color-text-muted)"><?= h($s['national_id']) ?></td>
                  <td>
                    <div style="display:flex;align-items:center;gap:8px">
                      <div class="progress-bar" style="width:60px"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
                      <span style="font-size:.8rem;font-weight:600;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
                    </div>
                  </td>
                  <td><?= statusBadge($s['student_status']) ?></td>
                  <td>
                    <form method="POST" style="display:inline"
                          onsubmit="return confirm('להסיר <?= h(addslashes($s['full_name'])) ?> מהקבוצה?')">
                      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                      <input type="hidden" name="action" value="remove_student">
                      <input type="hidden" name="student_id" value="<?= $s['id'] ?>">
                      <input type="hidden" name="group_id" value="<?= $g['id'] ?>">
                      <button type="submit" class="btn btn-ghost btn-sm" style="color:var(--color-danger)">הסר</button>
                    </form>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
          <?php else: ?>
          <div style="text-align:center;padding:24px;color:var(--color-text-muted)">
            <div style="font-size:2rem;margin-bottom:6px">🎒</div><p>אין חניכים עדיין</p>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endforeach; ?>

<?php if (empty($groups)): ?>
<div class="card"><div class="empty-state"><div class="empty-icon">👥</div><h3>אין קבוצות</h3></div></div>
<?php endif; ?>


<!-- מודל הוספת קבוצה -->
<?php if (isAdmin()): ?>
<div class="modal-overlay" id="modal-add-group" style="display:none">
  <div class="modal">
    <div class="modal-header"><h3 class="modal-title">קבוצה חדשה</h3><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="add_group">
        <div class="form-group">
          <label class="form-label">שם הקבוצה <span class="required">*</span></label>
          <input type="text" name="name" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">תוכנית <span class="required">*</span></label>
          <select name="program_id" class="form-control" required>
            <option value="">בחר...</option>
            <?php foreach ($programs as $p): ?>
            <option value="<?= $p['id'] ?>"><?= h($p['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">מדריך <span class="required">*</span></label>
          <select name="instructor_user_id" class="form-control" required>
            <option value="">בחר מדריך...</option>
            <?php foreach ($instructors as $i): ?>
            <option value="<?= $i['id'] ?>"><?= h($i['full_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">שמור</button>
      </div>
    </form>
  </div>
</div>

<!-- מודל עריכת קבוצה -->
<div class="modal-overlay" id="modal-edit-group" style="display:none">
  <div class="modal">
    <div class="modal-header"><h3 class="modal-title">עריכת קבוצה</h3><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="edit_group">
        <input type="hidden" name="group_id" id="edit_group_id">
        <div class="form-group">
          <label class="form-label">שם <span class="required">*</span></label>
          <input type="text" name="name" id="edit_group_name" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">תוכנית <span class="required">*</span></label>
          <select name="program_id" id="edit_group_program" class="form-control" required>
            <?php foreach ($programs as $p): ?>
            <option value="<?= $p['id'] ?>"><?= h($p['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">מדריך <span class="required">*</span></label>
          <select name="instructor_user_id" id="edit_group_instructor" class="form-control" required>
            <?php foreach ($instructors as $i): ?>
            <option value="<?= $i['id'] ?>"><?= h($i['full_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">עדכן</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- מודל שיוך חניך -->
<div class="modal-overlay" id="modal-assign" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3 class="modal-title" id="assign-title">שיוך חניך לקבוצה</h3>
      <button class="modal-close" data-modal-close>✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="assign_student">
        <input type="hidden" name="group_id" id="assign_group_id">
        <div class="form-group">
          <label class="form-label">חניך <span class="required">*</span></label>
          <select name="student_id" class="form-control" required>
            <option value="">בחר חניך...</option>
            <?php foreach ($unassigned as $s): ?>
            <option value="<?= $s['id'] ?>"><?= h($s['full_name']) ?> · <?= h($s['national_id']) ?></option>
            <?php endforeach; ?>
          </select>
          <?php if (empty($unassigned)): ?>
          <p class="form-hint">כל החניכים הפעילים כבר משויכים לקבוצה.
            <a href="<?= APP_URL ?>/pages/students.php">הוסף חניך חדש</a></p>
          <?php endif; ?>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary" <?= empty($unassigned)?'disabled':'' ?>>שייך</button>
      </div>
    </form>
  </div>
</div>

<script>
function toggleGroup(id) {
  const body = document.getElementById('group-body-' + id);
  const chev = document.getElementById('chevron-' + id);
  const open = body.style.display !== 'none';
  body.style.display = open ? 'none' : '';
  chev.textContent = open ? '▼' : '▲';
}
function openEditGroup(g) {
  document.getElementById('edit_group_id').value = g.id;
  document.getElementById('edit_group_name').value = g.name;
  document.getElementById('edit_group_program').value = g.program_id;
  document.getElementById('edit_group_instructor').value = g.instructor_user_id;
  document.getElementById('modal-edit-group').style.display = 'flex';
}
function openAssign(groupId, groupName) {
  document.getElementById('assign_group_id').value = groupId;
  document.getElementById('assign-title').textContent = 'שיוך חניך – ' + groupName;
  document.getElementById('modal-assign').style.display = 'flex';
}
<?php if ($openGroupId): ?>
window.addEventListener('DOMContentLoaded', () => toggleGroup(<?= $openGroupId ?>));
<?php endif; ?>
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
