<?php
// pages/my_group.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
$user = currentUser();
$db   = getDB();

// מדריך: קבוצה לפי session. מנהל/רכז: ?group_id=
if (isInstructor()) {
    if (!$user['group_id']) {
        die('<div style="font-family:sans-serif;text-align:center;padding:60px;direction:rtl">
             <h2>לא שויכת לקבוצה</h2><p>פנה למנהל המערכת.</p>
             <a href="' . APP_URL . '/dashboard.php">דשבורד</a></div>');
    }
    $groupId = $user['group_id'];
} else {
    $groupId = (int)($_GET['group_id'] ?? 0);
    if (!$groupId) redirect(APP_URL . '/pages/groups.php');
}

$group = $db->prepare("
    SELECT g.*, p.name AS program_name, u.full_name AS instructor_name, g.program_id
    FROM groups g
    JOIN programs p ON p.id = g.program_id
    LEFT JOIN users u ON u.id = g.instructor_user_id
    WHERE g.id = ? AND g.status = 'active'
");
$group->execute([$groupId]);
$group = $group->fetch();
if (!$group) { flashMessage('קבוצה לא נמצאה', 'danger'); redirect(APP_URL . '/pages/groups.php'); }

// חניכים עם סטטיסטיקות
$students = $db->prepare("
    SELECT s.*,
           COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS present_count,
           COUNT(acs.id) AS total_count
    FROM group_student gs
    JOIN students s ON s.id = gs.student_id
    LEFT JOIN activity_students acs ON acs.student_id = s.id
    LEFT JOIN activities act ON act.id = acs.activity_id AND act.group_id = ? AND act.deleted_at IS NULL
    WHERE gs.group_id = ? AND gs.is_active = 1
    GROUP BY s.id
    ORDER BY s.full_name
");
$students->execute([$groupId, $groupId]);
$students = $students->fetchAll();

// פעילויות אחרונות
$recentActivities = $db->prepare("
    SELECT a.*, at.name AS type_name,
           COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS present_count,
           COUNT(acs.id) AS total_count
    FROM activities a
    JOIN activity_types at ON at.id = a.activity_type_id
    LEFT JOIN activity_students acs ON acs.activity_id = a.id
    WHERE a.group_id = ? AND a.deleted_at IS NULL
    GROUP BY a.id
    ORDER BY a.activity_date DESC
    LIMIT 6
");
$recentActivities->execute([$groupId]);
$recentActivities = $recentActivities->fetchAll();

// סטטיסטיקות
$totalStudents   = count($students);
$totalActivities = (int)$db->prepare("SELECT COUNT(*) FROM activities WHERE group_id=? AND deleted_at IS NULL")->execute([$groupId]) ? 0 : 0;
$q = $db->prepare("SELECT COUNT(*) FROM activities WHERE group_id=? AND deleted_at IS NULL");
$q->execute([$groupId]);
$totalActivities = (int)$q->fetchColumn();

$avgPct = 0;
$withAtt = array_filter($students, fn($s) => $s['total_count'] > 0);
if ($withAtt) {
    $avgPct = round(array_sum(array_map(
        fn($s) => $s['present_count'] / $s['total_count'] * 100,
        $withAtt
    )) / count($withAtt));
}

$pageTitle  = 'הקבוצה שלי – ' . $group['name'];
$activePage = 'my_group';
require_once __DIR__ . '/../includes/header.php';
?>

<!-- כותרת -->
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px">
  <div>
    <h2 style="font-size:1.5rem;margin-bottom:4px">
      <?= h($group['name']) ?>
      <span class="badge badge-primary" style="vertical-align:middle;font-size:.8rem"><?= h($group['program_name']) ?></span>
    </h2>
    <p style="color:var(--color-text-muted);font-size:.88rem">
      מדריך: <?= h($group['instructor_name'] ?? '—') ?>
    </p>
  </div>
  <a href="<?= APP_URL ?>/pages/activities.php?action=new&group_id=<?= $groupId ?>" class="btn btn-primary">
    ➕ פעילות חדשה
  </a>
</div>

<!-- סטטיסטיקות -->
<div class="stats-grid" style="margin-bottom:24px">
  <div class="stat-card">
    <div class="stat-icon">🎒</div>
    <div class="stat-value"><?= $totalStudents ?></div>
    <div class="stat-label">חניכים</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">📅</div>
    <div class="stat-value"><?= $totalActivities ?></div>
    <div class="stat-label">פעילויות</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">✅</div>
    <div class="stat-value" style="color:<?= attendanceColor($avgPct) ?>"><?= $avgPct ?>%</div>
    <div class="stat-label">נוכחות ממוצעת</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">⚠️</div>
    <div class="stat-value" style="color:var(--color-warning)">
      <?= count(array_filter($students, fn($s) => $s['total_count'] > 0 && ($s['present_count']/$s['total_count']*100) < 70)) ?>
    </div>
    <div class="stat-label">נוכחות נמוכה</div>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start">

  <!-- רשימת חניכים -->
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <h3 style="font-size:1rem">חניכי הקבוצה</h3>
      <input type="text" placeholder="🔍 חיפוש..." class="form-control" style="max-width:200px"
             data-table-search="studentsTable">
    </div>
    <?php if ($students): ?>
    <div class="table-wrapper">
      <table class="data-table" id="studentsTable">
        <thead>
          <tr><th>שם</th><th>ת.ז.</th><th>נוכחות</th><th>סטטוס</th><th></th></tr>
        </thead>
        <tbody>
          <?php foreach ($students as $s): ?>
          <?php $pct = $s['total_count'] ? round($s['present_count']/$s['total_count']*100) : 0; ?>
          <tr style="<?= ($s['total_count']>0 && $pct<70) ? 'background:var(--color-warning-bg)' : '' ?>">
            <td>
              <div style="display:flex;align-items:center;gap:10px">
                <div class="user-avatar" style="width:32px;height:32px;font-size:.7rem"><?= h(initials($s['full_name'])) ?></div>
                <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $s['id'] ?>" style="font-weight:500">
                  <?= h($s['full_name']) ?>
                </a>
              </div>
            </td>
            <td style="font-size:.82rem;color:var(--color-text-muted)"><?= h($s['national_id']) ?></td>
            <td>
              <?php if ($s['total_count']): ?>
              <div style="display:flex;align-items:center;gap:8px">
                <div class="progress-bar" style="width:60px"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
                <span style="font-size:.8rem;font-weight:600;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
              </div>
              <?php else: ?>
              <span style="color:var(--color-text-muted);font-size:.8rem">—</span>
              <?php endif; ?>
            </td>
            <td><?= statusBadge($s['status']) ?></td>
            <td><a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $s['id'] ?>" class="btn btn-ghost btn-sm">תיק →</a></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <div class="empty-state"><div class="empty-icon">🎒</div><h3>אין חניכים</h3></div>
    <?php endif; ?>
  </div>

  <!-- פעילויות אחרונות -->
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
      <h3 style="font-size:1rem">פעילויות אחרונות</h3>
      <a href="<?= APP_URL ?>/pages/activities.php?group_id=<?= $groupId ?>" class="btn btn-ghost btn-sm">הכל →</a>
    </div>
    <?php if ($recentActivities): ?>
    <div style="display:flex;flex-direction:column;gap:10px">
      <?php foreach ($recentActivities as $a): ?>
      <?php $pct = $a['total_count'] ? round($a['present_count']/$a['total_count']*100) : 0; ?>
      <a href="<?= APP_URL ?>/pages/activity_detail.php?id=<?= $a['id'] ?>"
         style="display:block;padding:12px;border-radius:var(--radius-md);border:1px solid var(--color-border);text-decoration:none;transition:background var(--transition)"
         onmouseover="this.style.background='var(--color-surface-2)'"
         onmouseout="this.style.background=''">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
          <span style="font-weight:600;font-size:.88rem;color:var(--color-text)"><?= formatDate($a['activity_date']) ?></span>
          <span class="badge badge-primary" style="font-size:.72rem"><?= h($a['type_name']) ?></span>
        </div>
        <?php if ($a['total_count']): ?>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="progress-bar" style="flex:1"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
          <span style="font-size:.78rem;font-weight:600;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
        </div>
        <?php endif; ?>
        <?php if ($a['notes']): ?>
        <div style="font-size:.78rem;color:var(--color-text-muted);margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= h($a['notes']) ?></div>
        <?php endif; ?>
      </a>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="empty-state" style="padding:24px"><div class="empty-icon">📅</div><p>אין פעילויות</p></div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
