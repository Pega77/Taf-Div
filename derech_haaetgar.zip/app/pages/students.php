<?php
// pages/students.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
$user = currentUser();
$db   = getDB();

// ===== POST =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { flashMessage('בקשה לא תקינה', 'danger'); redirect(APP_URL . '/pages/students.php'); }

    $action = $_POST['action'] ?? '';

    if ($action === 'add_student') {
        // בדוק כפילות ת.ז.
        $check = $db->prepare("SELECT id FROM students WHERE national_id = ?");
        $check->execute([sanitize($_POST['national_id'])]);
        if ($check->fetch()) {
            flashMessage('מספר זהות זה כבר קיים במערכת', 'danger');
        } else {
            $stmt = $db->prepare("
                INSERT INTO students (national_id, full_name, gender, birth_date, status)
                VALUES (?,?,?,?,?)
            ");
            $stmt->execute([
                sanitize($_POST['national_id']),
                sanitize($_POST['full_name']),
                sanitize($_POST['gender']     ?? '') ?: null,
                sanitize($_POST['birth_date'] ?? '') ?: null,
                'active',
            ]);
            $newId = $db->lastInsertId();
            if (!empty($_POST['group_id'])) {
                $db->prepare("INSERT IGNORE INTO group_student (group_id, student_id, joined_at) VALUES (?,?,CURDATE())")
                   ->execute([(int)$_POST['group_id'], $newId]);
            }
            flashMessage('החניך נוסף בהצלחה', 'success');
        }
        redirect(APP_URL . '/pages/students.php');
    }

    if ($action === 'freeze_student') {
        $stmt = $db->prepare("UPDATE students SET status='frozen', freeze_reason=?, frozen_at=NOW() WHERE id=?");
        $stmt->execute([sanitize($_POST['reason'] ?? ''), (int)$_POST['student_id']]);
        flashMessage('החניך הוקפא', 'warning');
        redirect(APP_URL . '/pages/students.php');
    }

    if ($action === 'unfreeze_student') {
        $stmt = $db->prepare("UPDATE students SET status='active', freeze_reason=NULL, frozen_at=NULL WHERE id=?");
        $stmt->execute([(int)$_POST['student_id']]);
        flashMessage('הקפאה בוטלה', 'success');
        redirect(APP_URL . '/pages/students.php');
    }
}

// ===== Filters =====
$search    = sanitize($_GET['search']   ?? '');
$groupId   = (int)($_GET['group_id']   ?? 0);
$statusF   = sanitize($_GET['status']  ?? '');

$where  = ['s.deleted_at IS NULL'];
$params = [];

if ($search) {
    $where[]  = '(s.full_name LIKE ? OR s.national_id LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($groupId) {
    $where[]  = 'gs.group_id = ?';
    $params[] = $groupId;
}
if ($statusF) {
    $where[]  = 's.status = ?';
    $params[] = $statusF;
}

// מדריך רואה רק קבוצה שלו
if (isInstructor() && $user['group_id']) {
    $where[]  = 'gs.group_id = ?';
    $params[] = $user['group_id'];
}

$whereSQL = 'WHERE ' . implode(' AND ', $where);

$students = $db->prepare("
    SELECT DISTINCT s.*,
           g.name AS group_name, g.id AS group_id_val,
           (SELECT COUNT(*) FROM activity_students acs
            JOIN activities a ON a.id = acs.activity_id
            WHERE acs.student_id = s.id AND acs.participation_status='present' AND a.deleted_at IS NULL) AS present_count,
           (SELECT COUNT(*) FROM activity_students acs2
            JOIN activities a2 ON a2.id = acs2.activity_id
            WHERE acs2.student_id = s.id AND a2.deleted_at IS NULL) AS total_count
    FROM students s
    LEFT JOIN group_student gs ON gs.student_id = s.id AND gs.is_active = 1
    LEFT JOIN groups g ON g.id = gs.group_id
    $whereSQL
    ORDER BY s.full_name
");
$students->execute($params);
$students = $students->fetchAll();

// קבוצות לפילטר
if (isInstructor() && $user['group_id']) {
    $groupsQ = $db->prepare("SELECT * FROM groups WHERE id=? AND status='active'");
    $groupsQ->execute([$user['group_id']]);
} else {
    $groupsQ = $db->query("SELECT g.*, p.name AS prog FROM groups g JOIN programs p ON p.id=g.program_id WHERE g.status='active' ORDER BY p.name, g.name");
}
$groups = $groupsQ->fetchAll();

$pageTitle  = 'חניכים';
$activePage = 'students';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
  <div>
    <h2 style="font-size:1.5rem;margin-bottom:4px">חניכים</h2>
    <p style="color:var(--color-text-muted);font-size:.9rem"><?= count($students) ?> חניכים</p>
  </div>
  <button class="btn btn-primary" data-modal-open="modal-add-student">➕ הוסף חניך</button>
</div>

<!-- פילטרים -->
<form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px">
  <div class="input-with-icon" style="flex:1;min-width:200px">
    <span class="icon">🔍</span>
    <input type="text" name="search" class="form-control" placeholder="חיפוש שם / ת.ז." value="<?= h($search) ?>">
  </div>
  <?php if (!isInstructor()): ?>
  <select name="group_id" class="form-control" style="max-width:200px">
    <option value="">כל הקבוצות</option>
    <?php foreach ($groups as $g): ?>
    <option value="<?= $g['id'] ?>" <?= $groupId == $g['id'] ? 'selected' : '' ?>>
      <?= h($g['name']) ?><?= isset($g['prog']) ? ' – ' . h($g['prog']) : '' ?>
    </option>
    <?php endforeach; ?>
  </select>
  <?php endif; ?>
  <select name="status" class="form-control" style="max-width:140px">
    <option value="">כל הסטטוסים</option>
    <option value="active"  <?= $statusF === 'active'  ? 'selected' : '' ?>>פעיל</option>
    <option value="frozen"  <?= $statusF === 'frozen'  ? 'selected' : '' ?>>מוקפא</option>
  </select>
  <button type="submit" class="btn btn-secondary">סנן</button>
</form>

<!-- טבלה -->
<div class="card">
  <div class="table-wrapper">
    <?php if ($students): ?>
    <table class="data-table" id="studentsTable">
      <thead>
        <tr>
          <th>שם</th>
          <th>ת.ז.</th>
          <th>מין</th>
          <th>ת. לידה</th>
          <th>קבוצה</th>
          <th>נוכחות</th>
          <th>סטטוס</th>
          <th>פעולות</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($students as $s): ?>
        <?php $pct = $s['total_count'] ? round($s['present_count'] / $s['total_count'] * 100) : 0; ?>
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:10px">
              <div class="user-avatar"><?= h(initials($s['full_name'])) ?></div>
              <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $s['id'] ?>" style="font-weight:600">
                <?= h($s['full_name']) ?>
              </a>
            </div>
          </td>
          <td><?= h($s['national_id']) ?></td>
          <td><?= match($s['gender']) { 'male' => 'זכר', 'female' => 'נקבה', default => '—' } ?></td>
          <td><?= formatDate($s['birth_date']) ?></td>
          <td><?= $s['group_name'] ? '<span class="badge badge-primary">' . h($s['group_name']) . '</span>' : '<span class="badge badge-muted">לא משויך</span>' ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:8px">
              <div class="progress-bar" style="width:70px">
                <div class="progress-fill" style="width:<?= $pct ?>%"></div>
              </div>
              <span style="font-size:.8rem;font-weight:600;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
            </div>
          </td>
          <td><?= statusBadge($s['status']) ?></td>
          <td>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $s['id'] ?>" class="btn btn-secondary btn-sm">תיק</a>
              <?php if (!isInstructor()): ?>
                <a href="<?= APP_URL ?>/pages/student_edit.php?id=<?= $s['id'] ?>" class="btn btn-ghost btn-sm">✏️</a>
                <?php if ($s['status'] === 'active'): ?>
                <button class="btn btn-ghost btn-sm" style="color:var(--color-warning)"
                  onclick="freezeStudent(<?= $s['id'] ?>, '<?= h(addslashes($s['full_name'])) ?>')">❄️</button>
                <?php else: ?>
                <form method="POST" style="display:inline">
                  <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                  <input type="hidden" name="action" value="unfreeze_student">
                  <input type="hidden" name="student_id" value="<?= $s['id'] ?>">
                  <button type="submit" class="btn btn-ghost btn-sm" style="color:var(--color-success)">▶️</button>
                </form>
                <?php endif; ?>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><div class="empty-icon">🎒</div><h3>לא נמצאו חניכים</h3></div>
    <?php endif; ?>
  </div>
</div>

<!-- מודל הוספת חניך -->
<div class="modal-overlay" id="modal-add-student" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3 class="modal-title">הוספת חניך</h3>
      <button class="modal-close" data-modal-close>✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="add_student">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">שם מלא <span class="required">*</span></label>
            <input type="text" name="full_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">מספר זהות <span class="required">*</span></label>
            <input type="text" name="national_id" class="form-control" required maxlength="20">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">מין</label>
            <select name="gender" class="form-control">
              <option value="">בחר...</option>
              <option value="male">זכר</option>
              <option value="female">נקבה</option>
              <option value="other">אחר</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">תאריך לידה</label>
            <input type="date" name="birth_date" class="form-control">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">שיוך לקבוצה</label>
          <select name="group_id" class="form-control">
            <option value="">ללא קבוצה</option>
            <?php foreach ($groups as $g): ?>
            <option value="<?= $g['id'] ?>"
              <?= (isInstructor() && $user['group_id'] == $g['id']) ? 'selected' : '' ?>>
              <?= h($g['name']) ?><?= isset($g['prog']) ? ' – ' . h($g['prog']) : '' ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">הוסף</button>
      </div>
    </form>
  </div>
</div>

<!-- מודל הקפאה -->
<div class="modal-overlay" id="modal-freeze" style="display:none">
  <div class="modal">
    <div class="modal-header">
      <h3 class="modal-title">הקפאת חניך</h3>
      <button class="modal-close" data-modal-close>✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="freeze_student">
        <input type="hidden" name="student_id" id="freeze_student_id">
        <p id="freeze_student_name" style="font-weight:600;margin-bottom:12px"></p>
        <div class="form-group">
          <label class="form-label">סיבת הקפאה</label>
          <textarea name="reason" class="form-control" rows="3" placeholder="הסבר קצר..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-danger">הקפא</button>
      </div>
    </form>
  </div>
</div>

<script>
function freezeStudent(id, name) {
  document.getElementById('freeze_student_id').value = id;
  document.getElementById('freeze_student_name').textContent = 'הקפאת: ' + name;
  document.getElementById('modal-freeze').style.display = 'flex';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
