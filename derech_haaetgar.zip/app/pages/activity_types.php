<?php
// pages/activity_types.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
requireRole([ROLE_ADMIN]);
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { flashMessage('בקשה לא תקינה', 'danger'); redirect(APP_URL . '/pages/activity_types.php'); }

    $action = $_POST['action'] ?? '';

    if ($action === 'add_type') {
        $db->prepare("INSERT INTO activity_types (name, sort_order, is_active) VALUES (?,?,1)")
           ->execute([sanitize($_POST['name']), (int)($_POST['sort_order'] ?? 99)]);
        flashMessage('סוג הפעילות נוסף', 'success');
        redirect(APP_URL . '/pages/activity_types.php');
    }
    if ($action === 'edit_type') {
        $db->prepare("UPDATE activity_types SET name=?, sort_order=? WHERE id=?")
           ->execute([sanitize($_POST['name']), (int)$_POST['sort_order'], (int)$_POST['type_id']]);
        flashMessage('עודכן', 'success');
        redirect(APP_URL . '/pages/activity_types.php');
    }
    if ($action === 'toggle_type') {
        $cur = $db->prepare("SELECT is_active FROM activity_types WHERE id=?");
        $cur->execute([(int)$_POST['type_id']]);
        $cur = (int)$cur->fetchColumn();
        $db->prepare("UPDATE activity_types SET is_active=? WHERE id=?")->execute([1-$cur, (int)$_POST['type_id']]);
        flashMessage('סטטוס עודכן', 'success');
        redirect(APP_URL . '/pages/activity_types.php');
    }
}

$types = $db->query("
    SELECT at.*, COUNT(a.id) AS usage_count
    FROM activity_types at
    LEFT JOIN activities a ON a.activity_type_id = at.id AND a.deleted_at IS NULL
    GROUP BY at.id
    ORDER BY at.sort_order, at.name
")->fetchAll();

$pageTitle  = 'סוגי פעילות';
$activePage = 'activity_types';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
  <h2 style="font-size:1.5rem">סוגי פעילות</h2>
  <button class="btn btn-primary" data-modal-open="modal-add-type">➕ סוג חדש</button>
</div>

<div class="card">
  <div class="table-wrapper">
    <table class="data-table">
      <thead><tr><th>שם</th><th>סדר תצוגה</th><th>שימוש</th><th>סטטוס</th><th>פעולות</th></tr></thead>
      <tbody>
        <?php foreach ($types as $t): ?>
        <tr style="<?= !$t['is_active'] ? 'opacity:.55' : '' ?>">
          <td style="font-weight:500"><?= h($t['name']) ?></td>
          <td><?= $t['sort_order'] ?></td>
          <td><span class="badge badge-muted"><?= $t['usage_count'] ?> פעילויות</span></td>
          <td><?= $t['is_active']
              ? '<span class="badge badge-success">פעיל</span>'
              : '<span class="badge badge-muted">מנוטרל</span>' ?></td>
          <td>
            <div style="display:flex;gap:6px">
              <button class="btn btn-ghost btn-sm"
                      onclick="openEdit(<?= htmlspecialchars(json_encode($t), ENT_QUOTES) ?>)">✏️</button>
              <form method="POST" style="display:inline">
                <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                <input type="hidden" name="action" value="toggle_type">
                <input type="hidden" name="type_id" value="<?= $t['id'] ?>">
                <button type="submit" class="btn btn-ghost btn-sm"><?= $t['is_active']?'⏸️':'▶️' ?></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- מודל הוספה -->
<div class="modal-overlay" id="modal-add-type" style="display:none">
  <div class="modal">
    <div class="modal-header"><h3 class="modal-title">סוג פעילות חדש</h3><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="add_type">
        <div class="form-group">
          <label class="form-label">שם הסוג <span class="required">*</span></label>
          <input type="text" name="name" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">סדר תצוגה</label>
          <input type="number" name="sort_order" class="form-control" value="99" min="1">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">הוסף</button>
      </div>
    </form>
  </div>
</div>

<!-- מודל עריכה -->
<div class="modal-overlay" id="modal-edit-type" style="display:none">
  <div class="modal">
    <div class="modal-header"><h3 class="modal-title">עריכת סוג</h3><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="edit_type">
        <input type="hidden" name="type_id" id="et_id">
        <div class="form-group">
          <label class="form-label">שם <span class="required">*</span></label>
          <input type="text" name="name" id="et_name" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">סדר</label>
          <input type="number" name="sort_order" id="et_sort" class="form-control" min="1">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">עדכן</button>
      </div>
    </form>
  </div>
</div>

<script>
function openEdit(t) {
  document.getElementById('et_id').value   = t.id;
  document.getElementById('et_name').value = t.name;
  document.getElementById('et_sort').value = t.sort_order;
  document.getElementById('modal-edit-type').style.display = 'flex';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
