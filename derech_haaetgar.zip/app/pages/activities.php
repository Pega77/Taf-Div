<?php
// pages/activities.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
$user = currentUser();
$db   = getDB();

// ===== POST =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { flashMessage('בקשה לא תקינה', 'danger'); redirect(APP_URL . '/pages/activities.php'); }

    $action = $_POST['action'] ?? '';

    if ($action === 'add_activity') {
        $groupId = (int)$_POST['group_id'];

        // קבל program_id מהקבוצה
        $prog = $db->prepare("SELECT program_id FROM groups WHERE id=?");
        $prog->execute([$groupId]);
        $programId = (int)$prog->fetchColumn();

        $stmt = $db->prepare("
            INSERT INTO activities (program_id, group_id, activity_type_id, activity_date, notes, created_by_user_id)
            VALUES (?,?,?,?,?,?)
        ");
        $stmt->execute([
            $programId,
            $groupId,
            (int)$_POST['activity_type_id'],
            sanitize($_POST['activity_date']),
            sanitize($_POST['notes'] ?? ''),
            $user['id'],
        ]);
        $actId = $db->lastInsertId();

        // יצירת שורות נוכחות לכל חניכי הקבוצה
        $members = $db->prepare("
            SELECT student_id FROM group_student WHERE group_id=? AND is_active=1
        ");
        $members->execute([$groupId]);
        $ins = $db->prepare("INSERT IGNORE INTO activity_students (activity_id, student_id, participation_status) VALUES (?,?,'absent')");
        foreach ($members->fetchAll() as $m) {
            $ins->execute([$actId, $m['student_id']]);
        }

        flashMessage('הפעילות נוצרה – סמן נוכחות', 'success');
        redirect(APP_URL . '/pages/activity_detail.php?id=' . $actId);
    }
}

// ===== Filters =====
$groupFilter   = (int)($_GET['group_id']   ?? ($user['group_id'] ?? 0));
$programFilter = (int)($_GET['program_id'] ?? 0);
$typeFilter    = (int)($_GET['type_id']    ?? 0);
$dateFrom      = sanitize($_GET['date_from'] ?? '');
$dateTo        = sanitize($_GET['date_to']   ?? '');

$where  = ['a.deleted_at IS NULL'];
$params = [];

if ($groupFilter) { $where[] = 'a.group_id=?';         $params[] = $groupFilter; }
if ($programFilter){ $where[] = 'a.program_id=?';      $params[] = $programFilter; }
if ($typeFilter)  { $where[] = 'a.activity_type_id=?'; $params[] = $typeFilter; }
if ($dateFrom)    { $where[] = 'a.activity_date>=?';   $params[] = $dateFrom; }
if ($dateTo)      { $where[] = 'a.activity_date<=?';   $params[] = $dateTo; }

// מדריך רואה רק קבוצה שלו
if (isInstructor() && $user['group_id']) {
    $where[] = 'a.group_id=?';
    $params[] = $user['group_id'];
}

$whereSQL = 'WHERE ' . implode(' AND ', $where);

$activities = $db->prepare("
    SELECT a.*, p.name AS program_name, g.name AS group_name, at.name AS type_name,
           u.full_name AS created_by_name,
           COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS present_count,
           COUNT(acs.id) AS total_count
    FROM activities a
    JOIN programs p ON p.id = a.program_id
    JOIN groups g ON g.id = a.group_id
    JOIN activity_types at ON at.id = a.activity_type_id
    JOIN users u ON u.id = a.created_by_user_id
    LEFT JOIN activity_students acs ON acs.activity_id = a.id
    $whereSQL
    GROUP BY a.id
    ORDER BY a.activity_date DESC, a.created_at DESC
");
$activities->execute($params);
$activities = $activities->fetchAll();

// נתונים לטפסים
$activityTypes = $db->query("SELECT * FROM activity_types WHERE is_active=1 ORDER BY sort_order")->fetchAll();

if (isInstructor() && $user['group_id']) {
    $groupsQ = $db->prepare("SELECT g.*, p.name AS prog FROM groups g JOIN programs p ON p.id=g.program_id WHERE g.id=?");
    $groupsQ->execute([$user['group_id']]);
} else {
    $groupsQ = $db->query("SELECT g.*, p.name AS prog FROM groups g JOIN programs p ON p.id=g.program_id WHERE g.status='active' ORDER BY p.name, g.name");
}
$groups = $groupsQ->fetchAll();

$programs = !isInstructor()
    ? $db->query("SELECT * FROM programs WHERE status='active' ORDER BY name")->fetchAll()
    : [];

// פתיחה ישירה של מודל "פעילות חדשה"
$openNew = !empty($_GET['action']) && $_GET['action'] === 'new';

$pageTitle  = 'פעילויות';
$activePage = 'activities';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
  <div>
    <h2 style="font-size:1.5rem;margin-bottom:4px">פעילויות</h2>
    <p style="color:var(--color-text-muted);font-size:.9rem"><?= count($activities) ?> פעילויות</p>
  </div>
  <button class="btn btn-primary" data-modal-open="modal-add-activity">➕ פעילות חדשה</button>
</div>

<!-- פילטרים -->
<form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px">
  <?php if (!isInstructor()): ?>
  <select name="program_id" class="form-control" style="max-width:170px">
    <option value="">כל התוכניות</option>
    <?php foreach ($programs as $p): ?>
    <option value="<?= $p['id'] ?>" <?= $programFilter == $p['id'] ? 'selected' : '' ?>><?= h($p['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <select name="group_id" class="form-control" style="max-width:180px">
    <option value="">כל הקבוצות</option>
    <?php foreach ($groups as $g): ?>
    <option value="<?= $g['id'] ?>" <?= $groupFilter == $g['id'] ? 'selected' : '' ?>><?= h($g['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <?php endif; ?>
  <select name="type_id" class="form-control" style="max-width:160px">
    <option value="">כל הסוגים</option>
    <?php foreach ($activityTypes as $t): ?>
    <option value="<?= $t['id'] ?>" <?= $typeFilter == $t['id'] ? 'selected' : '' ?>><?= h($t['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <input type="date" name="date_from" class="form-control" style="max-width:145px" value="<?= h($dateFrom) ?>" placeholder="מתאריך">
  <input type="date" name="date_to"   class="form-control" style="max-width:145px" value="<?= h($dateTo) ?>"   placeholder="עד תאריך">
  <button type="submit" class="btn btn-secondary">סנן</button>
</form>

<!-- טבלה -->
<div class="card">
  <div class="table-wrapper">
    <?php if ($activities): ?>
    <table class="data-table" id="activitiesTable">
      <thead>
        <tr>
          <th>תאריך</th>
          <?php if (!isInstructor()): ?><th>תוכנית / קבוצה</th><?php else: ?><th>קבוצה</th><?php endif; ?>
          <th>סוג</th>
          <th>נוכחות</th>
          <th>הערות</th>
          <th>פעולות</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($activities as $a): ?>
        <?php $pct = $a['total_count'] ? round($a['present_count'] / $a['total_count'] * 100) : 0; ?>
        <tr>
          <td style="white-space:nowrap"><?= formatDate($a['activity_date']) ?></td>
          <td>
            <?= h($a['group_name']) ?>
            <?php if (!isInstructor()): ?>
            <div style="font-size:.75rem;color:var(--color-text-muted)"><?= h($a['program_name']) ?></div>
            <?php endif; ?>
          </td>
          <td><span class="badge badge-primary"><?= h($a['type_name']) ?></span></td>
          <td>
            <?php if ($a['total_count']): ?>
            <div style="display:flex;align-items:center;gap:8px">
              <div class="progress-bar" style="width:70px">
                <div class="progress-fill" style="width:<?= $pct ?>%"></div>
              </div>
              <span style="font-size:.8rem;font-weight:600;color:<?= attendanceColor($pct) ?>">
                <?= $a['present_count'] ?>/<?= $a['total_count'] ?> (<?= $pct ?>%)
              </span>
            </div>
            <?php else: ?>
            <span style="color:var(--color-text-muted);font-size:.82rem">לא נרשמו</span>
            <?php endif; ?>
          </td>
          <td style="font-size:.82rem;color:var(--color-text-muted);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            <?= h($a['notes'] ?? '—') ?>
          </td>
          <td>
            <a href="<?= APP_URL ?>/pages/activity_detail.php?id=<?= $a['id'] ?>" class="btn btn-secondary btn-sm">פתח</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><div class="empty-icon">📅</div><h3>אין פעילויות</h3><p>הוסף את הפעילות הראשונה</p></div>
    <?php endif; ?>
  </div>
</div>

<!-- מודל פעילות חדשה -->
<div class="modal-overlay" id="modal-add-activity" style="display:<?= $openNew ? 'flex' : 'none' ?>">
  <div class="modal">
    <div class="modal-header">
      <h3 class="modal-title">פעילות חדשה</h3>
      <button class="modal-close" data-modal-close>✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="add_activity">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">תאריך <span class="required">*</span></label>
            <input type="date" name="activity_date" class="form-control" required value="<?= date('Y-m-d') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">סוג פעילות <span class="required">*</span></label>
            <select name="activity_type_id" class="form-control" required>
              <option value="">בחר...</option>
              <?php foreach ($activityTypes as $t): ?>
              <option value="<?= $t['id'] ?>"><?= h($t['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">קבוצה <span class="required">*</span></label>
          <select name="group_id" class="form-control" required>
            <option value="">בחר קבוצה...</option>
            <?php foreach ($groups as $g): ?>
            <option value="<?= $g['id'] ?>"
              <?= (isInstructor() && $user['group_id'] == $g['id']) ? 'selected' : '' ?>>
              <?= h($g['name']) ?> – <?= h($g['prog']) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">הערות</label>
          <textarea name="notes" class="form-control" rows="3" placeholder="הערות אופציונלי..."></textarea>
        </div>
        <p style="font-size:.82rem;color:var(--color-text-muted)">
          💡 לאחר הוספה תועבר לדף הנוכחות לסמן נוכחות.
        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">צור פעילות</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
