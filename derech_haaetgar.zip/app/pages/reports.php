<?php
// pages/reports.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
requireRole([ROLE_ADMIN, ROLE_COORDINATOR]);
$db = getDB();

// ===== CSV Export =====
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $programId = (int)($_GET['program_id'] ?? 0);
    $groupId   = (int)($_GET['group_id']   ?? 0);
    $dateFrom  = sanitize($_GET['date_from'] ?? date('Y-01-01'));
    $dateTo    = sanitize($_GET['date_to']   ?? date('Y-12-31'));

    $where  = ["a.deleted_at IS NULL AND a.activity_date BETWEEN ? AND ?"];
    $params = [$dateFrom, $dateTo];
    if ($programId) { $where[] = 'a.program_id=?'; $params[] = $programId; }
    if ($groupId)   { $where[] = 'a.group_id=?';   $params[] = $groupId; }
    $whereSQL = 'WHERE ' . implode(' AND ', $where);

    $rows = $db->prepare("
        SELECT s.full_name, s.national_id,
               g.name AS group_name, p.name AS program_name,
               COUNT(DISTINCT a.id) AS total_activities,
               COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS present_count,
               COUNT(acs.id) AS att_total
        FROM students s
        JOIN group_student gs ON gs.student_id = s.id AND gs.is_active = 1
        JOIN groups g ON g.id = gs.group_id
        JOIN programs p ON p.id = g.program_id
        LEFT JOIN activities a ON a.group_id = g.id $whereSQL
        LEFT JOIN activity_students acs ON acs.activity_id = a.id AND acs.student_id = s.id
        WHERE s.deleted_at IS NULL
        GROUP BY s.id, g.id
        ORDER BY p.name, g.name, s.full_name
    ");
    $rows->execute($params);
    $data = $rows->fetchAll();

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="attendance_report_' . date('Ymd') . '.csv"');
    echo "\xEF\xBB\xBF"; // BOM for Excel
    $out = fopen('php://output', 'w');
    fputcsv($out, ['שם', 'ת.ז.', 'תוכנית', 'קבוצה', 'פעילויות', 'נוכחות', 'נעדר', 'אחוז', 'עמידה בקריטריון']);
    foreach ($data as $r) {
        $pct    = $r['att_total'] ? round($r['present_count'] / $r['att_total'] * 100) : 0;
        $absent = $r['att_total'] - $r['present_count'];
        $status = $pct >= 70 ? 'עומד' : ($pct >= 50 ? 'גבולי' : 'לא עומד');
        fputcsv($out, [
            $r['full_name'], $r['national_id'], $r['program_name'], $r['group_name'],
            $r['att_total'], $r['present_count'], $absent, $pct . '%', $status,
        ]);
    }
    fclose($out);
    exit;
}

// ===== Filters =====
$programId = (int)($_GET['program_id'] ?? 0);
$groupId   = (int)($_GET['group_id']   ?? 0);
$dateFrom  = sanitize($_GET['date_from'] ?? date('Y-01-01'));
$dateTo    = sanitize($_GET['date_to']   ?? date('Y-12-31'));

$where  = ["a.deleted_at IS NULL AND a.activity_date BETWEEN ? AND ?"];
$params = [$dateFrom, $dateTo];
if ($programId) { $where[] = 'a.program_id=?'; $params[] = $programId; }
if ($groupId)   { $where[] = 'a.group_id=?';   $params[] = $groupId; }
$whereSQL = 'WHERE ' . implode(' AND ', $where);

$report = $db->prepare("
    SELECT s.id, s.full_name, s.national_id, s.status AS student_status,
           g.id AS group_id, g.name AS group_name,
           p.name AS program_name,
           COUNT(DISTINCT a.id) AS total_activities,
           COUNT(CASE WHEN acs.participation_status='present' THEN 1 END) AS present_count,
           COUNT(acs.id) AS att_total
    FROM students s
    JOIN group_student gs ON gs.student_id = s.id AND gs.is_active = 1
    JOIN groups g ON g.id = gs.group_id
    JOIN programs p ON p.id = g.program_id
    LEFT JOIN activities a ON a.group_id = g.id $whereSQL
    LEFT JOIN activity_students acs ON acs.activity_id = a.id AND acs.student_id = s.id
    WHERE s.deleted_at IS NULL
    GROUP BY s.id, g.id
    ORDER BY p.name, g.name, s.full_name
");
$report->execute($params);
$report = $report->fetchAll();

$programs = $db->query("SELECT * FROM programs WHERE status='active' ORDER BY name")->fetchAll();
$groups   = $db->query("SELECT g.*, p.name AS prog FROM groups g JOIN programs p ON p.id=g.program_id WHERE g.status='active' ORDER BY p.name, g.name")->fetchAll();

// סיכום
$totalStudents = count($report);
$meetCriteria  = count(array_filter($report, fn($r) => $r['att_total'] && ($r['present_count']/$r['att_total']*100) >= 70));
$borderline    = count(array_filter($report, fn($r) => $r['att_total'] && ($p=$r['present_count']/$r['att_total']*100) >= 50 && $p < 70));
$notMeeting    = count(array_filter($report, fn($r) => $r['att_total'] && ($r['present_count']/$r['att_total']*100) < 50));

$pageTitle  = 'דוחות';
$activePage = 'reports';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px">
  <h2 style="font-size:1.5rem">📈 דוח נוכחות</h2>
  <div style="display:flex;gap:8px">
    <a href="?<?= http_build_query(array_merge($_GET, ['export'=>'csv'])) ?>" class="btn btn-secondary">
      📥 ייצוא CSV
    </a>
    <button onclick="window.print()" class="btn btn-ghost">🖨️ הדפסה</button>
  </div>
</div>

<!-- פילטרים -->
<form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px">
  <select name="program_id" class="form-control" style="max-width:180px">
    <option value="">כל התוכניות</option>
    <?php foreach ($programs as $p): ?>
    <option value="<?= $p['id'] ?>" <?= $programId==$p['id']?'selected':'' ?>><?= h($p['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <select name="group_id" class="form-control" style="max-width:180px">
    <option value="">כל הקבוצות</option>
    <?php foreach ($groups as $g): ?>
    <option value="<?= $g['id'] ?>" <?= $groupId==$g['id']?'selected':'' ?>><?= h($g['name']) ?> – <?= h($g['prog']) ?></option>
    <?php endforeach; ?>
  </select>
  <input type="date" name="date_from" class="form-control" style="max-width:145px" value="<?= h($dateFrom) ?>">
  <span style="align-self:center;color:var(--color-text-muted)">עד</span>
  <input type="date" name="date_to" class="form-control" style="max-width:145px" value="<?= h($dateTo) ?>">
  <button type="submit" class="btn btn-primary">הצג דוח</button>
</form>

<!-- סיכום -->
<div class="stats-grid" style="margin-bottom:20px">
  <div class="stat-card">
    <div class="stat-icon">🎒</div>
    <div class="stat-value"><?= $totalStudents ?></div>
    <div class="stat-label">חניכים בדוח</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">✅</div>
    <div class="stat-value" style="color:var(--color-success)"><?= $meetCriteria ?></div>
    <div class="stat-label">עומדים בקריטריון (≥70%)</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">⚠️</div>
    <div class="stat-value" style="color:var(--color-warning)"><?= $borderline ?></div>
    <div class="stat-label">גבולי (50–69%)</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">❌</div>
    <div class="stat-value" style="color:var(--color-danger)"><?= $notMeeting ?></div>
    <div class="stat-label">לא עומדים (&lt;50%)</div>
  </div>
</div>

<!-- טבלת דוח -->
<div class="card">
  <div class="table-wrapper">
    <?php if ($report): ?>
    <table class="data-table" id="reportTable">
      <thead>
        <tr>
          <th>שם</th>
          <th>ת.ז.</th>
          <th>תוכנית / קבוצה</th>
          <th>פעילויות</th>
          <th>נוכח</th>
          <th>נעדר</th>
          <th>אחוז</th>
          <th>עמידה בקריטריון</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($report as $r): ?>
        <?php
          $pct    = $r['att_total'] ? round($r['present_count'] / $r['att_total'] * 100) : 0;
          $absent = $r['att_total'] - $r['present_count'];
          if (!$r['att_total'])       { $criteria = ''; $criteriaClass = 'badge-muted'; }
          elseif ($pct >= 70)         { $criteria = '✓ עומד';    $criteriaClass = 'badge-success'; }
          elseif ($pct >= 50)         { $criteria = '~ גבולי';   $criteriaClass = 'badge-warning'; }
          else                        { $criteria = '✗ לא עומד'; $criteriaClass = 'badge-danger'; }
        ?>
        <tr>
          <td>
            <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $r['id'] ?>" style="font-weight:500">
              <?= h($r['full_name']) ?>
            </a>
          </td>
          <td style="font-size:.82rem;color:var(--color-text-muted)"><?= h($r['national_id']) ?></td>
          <td>
            <?= h($r['group_name']) ?>
            <div style="font-size:.75rem;color:var(--color-text-muted)"><?= h($r['program_name']) ?></div>
          </td>
          <td style="text-align:center"><?= $r['att_total'] ?: '—' ?></td>
          <td style="text-align:center;color:var(--color-success);font-weight:600"><?= $r['present_count'] ?: '—' ?></td>
          <td style="text-align:center;color:var(--color-danger);font-weight:600"><?= $r['att_total'] ? $absent : '—' ?></td>
          <td>
            <?php if ($r['att_total']): ?>
            <div style="display:flex;align-items:center;gap:8px">
              <div class="progress-bar" style="width:70px"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
              <span style="font-weight:700;color:<?= attendanceColor($pct) ?>"><?= $pct ?>%</span>
            </div>
            <?php else: ?>—<?php endif; ?>
          </td>
          <td>
            <?php if ($criteria): ?>
            <span class="badge <?= $criteriaClass ?>"><?= $criteria ?></span>
            <?php else: ?>
            <span style="color:var(--color-text-muted);font-size:.82rem">אין נתונים</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><div class="empty-icon">📊</div><h3>לא נמצאו נתונים</h3><p>שנה את הפילטרים</p></div>
    <?php endif; ?>
  </div>
</div>

<style>
@media print {
  .sidebar, .topbar, form, .btn { display:none !important; }
  .main-area { margin:0 !important; }
  .card { box-shadow:none !important; border:1px solid #ccc !important; }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
