<?php
// pages/programs.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
requireRole([ROLE_ADMIN]);
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { flashMessage('בקשה לא תקינה', 'danger'); redirect(APP_URL . '/pages/programs.php'); }

    $action = $_POST['action'] ?? '';

    if ($action === 'add_program') {
        $db->prepare("INSERT INTO programs (name, status) VALUES (?, 'active')")
           ->execute([sanitize($_POST['name'])]);
        flashMessage('התוכנית נוצרה', 'success');
        redirect(APP_URL . '/pages/programs.php');
    }
    if ($action === 'edit_program') {
        $db->prepare("UPDATE programs SET name=?, status=? WHERE id=?")
           ->execute([sanitize($_POST['name']), sanitize($_POST['status']), (int)$_POST['program_id']]);
        flashMessage('התוכנית עודכנה', 'success');
        redirect(APP_URL . '/pages/programs.php');
    }
}

$programs = $db->query("
    SELECT p.*,
           COUNT(DISTINCT g.id) AS group_count,
           COUNT(DISTINCT gs.student_id) AS student_count,
           COUNT(DISTINCT a.id) AS activity_count
    FROM programs p
    LEFT JOIN groups g ON g.program_id = p.id AND g.status = 'active'
    LEFT JOIN group_student gs ON gs.group_id = g.id AND gs.is_active = 1
    LEFT JOIN activities a ON a.program_id = p.id AND a.deleted_at IS NULL
    GROUP BY p.id
    ORDER BY p.name
")->fetchAll();

$pageTitle  = 'תוכניות';
$activePage = 'programs';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
  <h2 style="font-size:1.5rem">תוכניות</h2>
  <button class="btn btn-primary" data-modal-open="modal-add-program">➕ תוכנית חדשה</button>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px">
  <?php foreach ($programs as $p): ?>
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px">
      <div>
        <div style="font-size:1.1rem;font-weight:700"><?= h($p['name']) ?></div>
        <?= $p['status']==='active'
            ? '<span class="badge badge-success">פעיל</span>'
            : '<span class="badge badge-muted">לא פעיל</span>' ?>
      </div>
      <button class="btn btn-ghost btn-sm btn-icon"
              onclick="openEdit(<?= htmlspecialchars(json_encode($p), ENT_QUOTES) ?>)">✏️</button>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;text-align:center">
      <div style="background:var(--color-surface-2);border-radius:var(--radius-md);padding:10px">
        <div style="font-weight:700;font-size:1.2rem;color:var(--color-primary)"><?= $p['group_count'] ?></div>
        <div style="font-size:.72rem;color:var(--color-text-muted)">קבוצות</div>
      </div>
      <div style="background:var(--color-surface-2);border-radius:var(--radius-md);padding:10px">
        <div style="font-weight:700;font-size:1.2rem;color:var(--color-primary)"><?= $p['student_count'] ?></div>
        <div style="font-size:.72rem;color:var(--color-text-muted)">חניכים</div>
      </div>
      <div style="background:var(--color-surface-2);border-radius:var(--radius-md);padding:10px">
        <div style="font-weight:700;font-size:1.2rem;color:var(--color-accent)"><?= $p['activity_count'] ?></div>
        <div style="font-size:.72rem;color:var(--color-text-muted)">פעילויות</div>
      </div>
    </div>
    <div style="margin-top:12px;display:flex;gap:8px">
      <a href="<?= APP_URL ?>/pages/groups.php" class="btn btn-secondary btn-sm" style="flex:1;justify-content:center">קבוצות</a>
      <a href="<?= APP_URL ?>/pages/metadata.php?program_id=<?= $p['id'] ?>" class="btn btn-ghost btn-sm" style="flex:1;justify-content:center">שדות מותאמים</a>
    </div>
  </div>
  <?php endforeach; ?>
  <?php if (empty($programs)): ?>
  <div class="card"><div class="empty-state"><div class="empty-icon">🗂️</div><h3>אין תוכניות</h3></div></div>
  <?php endif; ?>
</div>

<!-- מודל הוספה -->
<div class="modal-overlay" id="modal-add-program" style="display:none">
  <div class="modal">
    <div class="modal-header"><h3 class="modal-title">תוכנית חדשה</h3><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="add_program">
        <div class="form-group">
          <label class="form-label">שם התוכנית <span class="required">*</span></label>
          <input type="text" name="name" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">שמור</button>
      </div>
    </form>
  </div>
</div>

<!-- מודל עריכה -->
<div class="modal-overlay" id="modal-edit-program" style="display:none">
  <div class="modal">
    <div class="modal-header"><h3 class="modal-title">עריכת תוכנית</h3><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="edit_program">
        <input type="hidden" name="program_id" id="ep_id">
        <div class="form-group">
          <label class="form-label">שם <span class="required">*</span></label>
          <input type="text" name="name" id="ep_name" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">סטטוס</label>
          <select name="status" id="ep_status" class="form-control">
            <option value="active">פעיל</option>
            <option value="inactive">לא פעיל</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">עדכן</button>
      </div>
    </form>
  </div>
</div>

<script>
function openEdit(p) {
  document.getElementById('ep_id').value     = p.id;
  document.getElementById('ep_name').value   = p.name;
  document.getElementById('ep_status').value = p.status;
  document.getElementById('modal-edit-program').style.display = 'flex';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
