<?php
// pages/student_edit.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
requireRole([ROLE_ADMIN, ROLE_COORDINATOR]);
$db = getDB();

$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect(APP_URL . '/pages/students.php');

$student = $db->prepare("SELECT * FROM students WHERE id=? AND deleted_at IS NULL");
$student->execute([$id]);
$student = $student->fetch();
if (!$student) { flashMessage('חניך לא נמצא', 'danger'); redirect(APP_URL . '/pages/students.php'); }

// שדות מטאדטה
$activeGroup = $db->prepare("
    SELECT g.program_id, g.name AS group_name
    FROM group_student gs JOIN groups g ON g.id = gs.group_id
    WHERE gs.student_id = ? AND gs.is_active = 1 LIMIT 1
");
$activeGroup->execute([$id]);
$activeGroup = $activeGroup->fetch();

$metaFields = [];
$metaValues = [];
if ($activeGroup) {
    $mf = $db->prepare("SELECT * FROM metadata_fields WHERE program_id=? AND is_active=1 ORDER BY sort_order");
    $mf->execute([$activeGroup['program_id']]);
    $metaFields = $mf->fetchAll();
    $mv = $db->prepare("SELECT * FROM metadata_values WHERE student_id=?");
    $mv->execute([$id]);
    foreach ($mv->fetchAll() as $v) $metaValues[$v['metadata_field_id']] = $v;
}

// קבוצות
$groups = $db->query("SELECT g.*, p.name AS prog FROM groups g JOIN programs p ON p.id=g.program_id WHERE g.status='active' ORDER BY p.name, g.name")->fetchAll();
$gs = $db->prepare("SELECT group_id FROM group_student WHERE student_id=? AND is_active=1");
$gs->execute([$id]);
$currentGroupId = (int)($gs->fetchColumn() ?: 0);

// ===== POST =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { flashMessage('בקשה לא תקינה', 'danger'); redirect(APP_URL . '/pages/student_edit.php?id=' . $id); }

    $action = $_POST['action'] ?? '';

    if ($action === 'update_student') {
        // בדוק כפילות ת.ז. (מלבד עצמו)
        $dup = $db->prepare("SELECT id FROM students WHERE national_id=? AND id!=?");
        $dup->execute([sanitize($_POST['national_id']), $id]);
        if ($dup->fetch()) {
            flashMessage('מספר זהות זה שייך לחניך אחר', 'danger');
        } else {
            $db->prepare("UPDATE students SET national_id=?, full_name=?, gender=?, birth_date=? WHERE id=?")
               ->execute([
                   sanitize($_POST['national_id']),
                   sanitize($_POST['full_name']),
                   sanitize($_POST['gender'] ?? '') ?: null,
                   sanitize($_POST['birth_date'] ?? '') ?: null,
                   $id,
               ]);

            // עדכון קבוצה
            $newGroup = (int)($_POST['group_id'] ?? 0);
            if ($newGroup !== $currentGroupId) {
                // הסר מהקבוצה הנוכחית
                if ($currentGroupId) {
                    $db->prepare("UPDATE group_student SET is_active=0, left_at=CURDATE() WHERE student_id=? AND group_id=? AND is_active=1")
                       ->execute([$id, $currentGroupId]);
                }
                // הוסף לקבוצה חדשה
                if ($newGroup) {
                    $db->prepare("INSERT INTO group_student (group_id, student_id, is_active, joined_at) VALUES (?,?,1,CURDATE()) ON DUPLICATE KEY UPDATE is_active=1, joined_at=CURDATE(), left_at=NULL")
                       ->execute([$newGroup, $id]);
                }
            }

            // מטאדטה
            foreach ($metaFields as $f) {
                $key  = 'meta_' . $f['id'];
                $rawVal = $_POST[$key] ?? null;
                if ($rawVal === null || $rawVal === '') continue;
                $col = match($f['field_type']) {
                    'text','select' => 'value_text',
                    'number'       => 'value_number',
                    'date'         => 'value_date',
                    'boolean'      => 'value_boolean',
                    default        => 'value_text',
                };
                $ins = $db->prepare("
                    INSERT INTO metadata_values (student_id, metadata_field_id, $col)
                    VALUES (?,?,?)
                    ON DUPLICATE KEY UPDATE $col = ?
                ");
                $ins->execute([$id, $f['id'], $rawVal, $rawVal]);
            }

            flashMessage('פרטי החניך עודכנו', 'success');
        }
        redirect(APP_URL . '/pages/student_edit.php?id=' . $id);
    }

    if ($action === 'delete_student' && isAdmin()) {
        $db->prepare("UPDATE students SET deleted_at=NOW() WHERE id=?")->execute([$id]);
        flashMessage('החניך נמחק', 'success');
        redirect(APP_URL . '/pages/students.php');
    }
}

$pageTitle  = 'עריכת חניך – ' . $student['full_name'];
$activePage = 'students';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
  <div>
    <h2 style="font-size:1.4rem">✏️ עריכת חניך</h2>
    <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $id ?>" style="font-size:.85rem">← חזרה לתיק</a>
  </div>
  <?php if (isAdmin()): ?>
  <button class="btn btn-danger btn-sm" onclick="confirmDelete()">🗑️ מחיקה</button>
  <?php endif; ?>
</div>

<form method="POST">
  <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
  <input type="hidden" name="action" value="update_student">

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start">
    <!-- פרטים אישיים -->
    <div class="card">
      <h4 style="margin-bottom:16px">פרטים אישיים</h4>
      <div class="form-group">
        <label class="form-label">שם מלא <span class="required">*</span></label>
        <input type="text" name="full_name" class="form-control" required value="<?= h($student['full_name']) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">מספר זהות <span class="required">*</span></label>
        <input type="text" name="national_id" class="form-control" required value="<?= h($student['national_id']) ?>" maxlength="20">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">מין</label>
          <select name="gender" class="form-control">
            <option value="">—</option>
            <option value="male"   <?= $student['gender']==='male'   ? 'selected':'' ?>>זכר</option>
            <option value="female" <?= $student['gender']==='female' ? 'selected':'' ?>>נקבה</option>
            <option value="other"  <?= $student['gender']==='other'  ? 'selected':'' ?>>אחר</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">תאריך לידה</label>
          <input type="date" name="birth_date" class="form-control" value="<?= h($student['birth_date'] ?? '') ?>">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">קבוצה</label>
        <select name="group_id" class="form-control">
          <option value="0">ללא קבוצה</option>
          <?php foreach ($groups as $g): ?>
          <option value="<?= $g['id'] ?>" <?= $currentGroupId == $g['id'] ? 'selected' : '' ?>>
            <?= h($g['name']) ?> – <?= h($g['prog']) ?>
          </option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <!-- מטאדטה -->
    <?php if ($metaFields): ?>
    <div class="card" id="meta">
      <h4 style="margin-bottom:16px">מידע נוסף – <?= h($activeGroup['group_name']) ?></h4>
      <?php foreach ($metaFields as $f): ?>
      <?php
        $val = $metaValues[$f['id']] ?? null;
        $cur = match($f['field_type']) {
            'text','select' => $val['value_text']   ?? '',
            'number'        => $val['value_number'] ?? '',
            'date'          => $val['value_date']   ?? '',
            'boolean'       => $val['value_boolean'] ?? '',
            default         => '',
        };
        if ($f['field_type'] === 'select') {
            $j = json_decode($val['value_json'] ?? 'null');
            if (is_string($j)) $cur = $j;
        }
      ?>
      <div class="form-group">
        <label class="form-label">
          <?= h($f['field_label']) ?>
          <?= $f['is_required'] ? '<span class="required">*</span>' : '' ?>
        </label>
        <?php if ($f['field_type'] === 'text'): ?>
          <input type="text" name="meta_<?= $f['id'] ?>" class="form-control" value="<?= h($cur) ?>">
        <?php elseif ($f['field_type'] === 'number'): ?>
          <input type="number" name="meta_<?= $f['id'] ?>" class="form-control" value="<?= h($cur) ?>">
        <?php elseif ($f['field_type'] === 'date'): ?>
          <input type="date" name="meta_<?= $f['id'] ?>" class="form-control" value="<?= h($cur) ?>">
        <?php elseif ($f['field_type'] === 'boolean'): ?>
          <select name="meta_<?= $f['id'] ?>" class="form-control">
            <option value="">—</option>
            <option value="1" <?= $cur == '1' ? 'selected' : '' ?>>כן</option>
            <option value="0" <?= $cur == '0' ? 'selected' : '' ?>>לא</option>
          </select>
        <?php elseif ($f['field_type'] === 'select'): ?>
          <?php $opts = json_decode($f['options_json'] ?? '[]', true) ?: []; ?>
          <select name="meta_<?= $f['id'] ?>" class="form-control">
            <option value="">בחר...</option>
            <?php foreach ($opts as $opt): ?>
            <option value="<?= h($opt) ?>" <?= $cur === $opt ? 'selected' : '' ?>><?= h($opt) ?></option>
            <?php endforeach; ?>
          </select>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <div style="display:flex;gap:10px;margin-top:20px;justify-content:flex-end">
    <a href="<?= APP_URL ?>/pages/student_detail.php?id=<?= $id ?>" class="btn btn-ghost">ביטול</a>
    <button type="submit" class="btn btn-primary">💾 שמור שינויים</button>
  </div>
</form>

<!-- מחיקה -->
<form method="POST" id="form-delete" style="display:none">
  <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
  <input type="hidden" name="action" value="delete_student">
</form>

<script>
function confirmDelete() {
  if (confirm('למחוק את <?= h(addslashes($student['full_name'])) ?>?\nניתן לשחזר מה-DB.')) {
    document.getElementById('form-delete').submit();
  }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
