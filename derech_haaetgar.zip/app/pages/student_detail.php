<?php
// pages/student_detail.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
$user = currentUser();
$db   = getDB();

$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect(APP_URL . '/pages/students.php');

$student = $db->prepare("SELECT * FROM students WHERE id=? AND deleted_at IS NULL");
$student->execute([$id]);
$student = $student->fetch();
if (!$student) { flashMessage('חניך לא נמצא', 'danger'); redirect(APP_URL . '/pages/students.php'); }

// אם מדריך – רק חניכי הקבוצה שלו
if (isInstructor() && $user['group_id']) {
    $check = $db->prepare("SELECT 1 FROM group_student WHERE student_id=? AND group_id=? AND is_active=1");
    $check->execute([$id, $user['group_id']]);
    if (!$check->fetch()) { flashMessage('אין הרשאה לצפות בחניך זה', 'danger'); redirect(APP_URL . '/pages/my_group.php'); }
}

// קבוצות שהחניך משויך אליהן
$groups = $db->prepare("
    SELECT gs.*, g.name AS group_name, p.name AS program_name,
           u.full_name AS instructor_name,
           gs.joined_at, gs.left_at
    FROM group_student gs
    JOIN groups g ON g.id = gs.group_id
    JOIN programs p ON p.id = g.program_id
    LEFT JOIN users u ON u.id = g.instructor_user_id
    WHERE gs.student_id = ?
    ORDER BY gs.is_active DESC, gs.joined_at DESC
");
$groups->execute([$id]);
$groups = $groups->fetchAll();

$activeGroup = null;
foreach ($groups as $g) {
    if ($g['is_active']) { $activeGroup = $g; break; }
}

// היסטוריית נוכחות
$attendance = $db->prepare("
    SELECT a.activity_date, a.notes AS act_notes, at.name AS type_name,
           g.name AS group_name, acs.participation_status
    FROM activity_students acs
    JOIN activities a ON a.id = acs.activity_id AND a.deleted_at IS NULL
    JOIN activity_types at ON at.id = a.activity_type_id
    JOIN groups g ON g.id = a.group_id
    WHERE acs.student_id = ?
    ORDER BY a.activity_date DESC
    LIMIT 50
");
$attendance->execute([$id]);
$attendance = $attendance->fetchAll();

$presentCount = count(array_filter($attendance, fn($r) => $r['participation_status'] === 'present'));
$totalCount   = count($attendance);
$attPct       = $totalCount ? round($presentCount / $totalCount * 100) : 0;

// שדות מטאדטה
$metaFields = [];
$metaValues = [];
if ($activeGroup) {
    $progId = $db->prepare("SELECT program_id FROM groups WHERE id=?");
    $progId->execute([$activeGroup['group_id']]);
    $progId = (int)$progId->fetchColumn();

    $mf = $db->prepare("SELECT * FROM metadata_fields WHERE program_id=? AND is_active=1 ORDER BY sort_order");
    $mf->execute([$progId]);
    $metaFields = $mf->fetchAll();

    $mv = $db->prepare("SELECT * FROM metadata_values WHERE student_id=?");
    $mv->execute([$id]);
    foreach ($mv->fetchAll() as $v) {
        $metaValues[$v['metadata_field_id']] = $v;
    }
}

$pageTitle  = $student['full_name'];
$activePage = 'students';
require_once __DIR__ . '/../includes/header.php';
?>

<!-- כותרת -->
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px">
  <div style="display:flex;align-items:center;gap:16px">
    <div class="user-avatar" style="width:56px;height:56px;font-size:1.1rem">
      <?= h(initials($student['full_name'])) ?>
    </div>
    <div>
      <h2 style="font-size:1.4rem;margin-bottom:4px"><?= h($student['full_name']) ?></h2>
      <div style="display:flex;gap:8px;align-items:center">
        <?= statusBadge($student['status']) ?>
        <?php if ($activeGroup): ?>
        <span class="badge badge-primary"><?= h($activeGroup['group_name']) ?></span>
        <?php endif; ?>
        <span style="font-size:.82rem;color:var(--color-text-muted)">ת.ז. <?= h($student['national_id']) ?></span>
      </div>
    </div>
  </div>
  <?php if (!isInstructor()): ?>
  <a href="<?= APP_URL ?>/pages/student_edit.php?id=<?= $id ?>" class="btn btn-secondary">✏️ עריכה</a>
  <?php endif; ?>
</div>

<!-- Tabs -->
<div class="tabs">
  <button class="tab-btn active" data-tab-group="student" data-tab="tab-info">📋 פרטים</button>
  <button class="tab-btn" data-tab-group="student" data-tab="tab-attendance">✅ נוכחות</button>
  <?php if ($metaFields): ?>
  <button class="tab-btn" data-tab-group="student" data-tab="tab-meta">🔖 מידע נוסף</button>
  <?php endif; ?>
</div>

<!-- טאב: פרטים -->
<div class="tab-panel active" id="tab-info" data-tab-group="student">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
    <div class="card">
      <h4 style="margin-bottom:16px;color:var(--color-text-muted);font-size:.85rem;text-transform:uppercase;letter-spacing:.05em">פרטים אישיים</h4>
      <table style="width:100%;font-size:.9rem">
        <tr><td style="color:var(--color-text-muted);padding:6px 0;width:40%">מספר זהות</td><td style="font-weight:500"><?= h($student['national_id']) ?></td></tr>
        <tr><td style="color:var(--color-text-muted);padding:6px 0">מין</td>
            <td><?= match($student['gender']) { 'male'=>'זכר','female'=>'נקבה','other'=>'אחר',default=>'—' } ?></td></tr>
        <tr><td style="color:var(--color-text-muted);padding:6px 0">תאריך לידה</td><td><?= formatDate($student['birth_date']) ?></td></tr>
        <tr><td style="color:var(--color-text-muted);padding:6px 0">סטטוס</td><td><?= statusBadge($student['status']) ?></td></tr>
        <?php if ($student['status'] === 'frozen' && $student['freeze_reason']): ?>
        <tr><td style="color:var(--color-text-muted);padding:6px 0">סיבת הקפאה</td><td><?= h($student['freeze_reason']) ?></td></tr>
        <?php endif; ?>
        <tr><td style="color:var(--color-text-muted);padding:6px 0">נרשם</td><td><?= formatDate($student['created_at']) ?></td></tr>
      </table>
    </div>

    <div class="card">
      <h4 style="margin-bottom:16px;color:var(--color-text-muted);font-size:.85rem;text-transform:uppercase;letter-spacing:.05em">קבוצות</h4>
      <?php foreach ($groups as $g): ?>
      <div style="margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid var(--color-border)">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-weight:600"><?= h($g['group_name']) ?></span>
          <?= $g['is_active'] ? '<span class="badge badge-success">נוכחי</span>' : '<span class="badge badge-muted">לשעבר</span>' ?>
        </div>
        <div style="font-size:.8rem;color:var(--color-text-muted);margin-top:4px">
          <?= h($g['program_name']) ?>
          <?= $g['instructor_name'] ? ' · מדריך: ' . h($g['instructor_name']) : '' ?>
        </div>
        <div style="font-size:.78rem;color:var(--color-text-light);margin-top:2px">
          הצטרף: <?= formatDate($g['joined_at']) ?>
          <?= $g['left_at'] ? ' · עזב: ' . formatDate($g['left_at']) : '' ?>
        </div>
      </div>
      <?php endforeach; ?>
      <?php if (empty($groups)): ?><p style="color:var(--color-text-muted);font-size:.9rem">לא משויך לקבוצה</p><?php endif; ?>
    </div>
  </div>
</div>

<!-- טאב: נוכחות -->
<div class="tab-panel" id="tab-attendance" data-tab-group="student">
  <div class="card" style="margin-bottom:16px">
    <div style="display:flex;align-items:center;gap:24px;flex-wrap:wrap">
      <div style="text-align:center">
        <div style="font-size:2rem;font-weight:700;color:<?= attendanceColor($attPct) ?>"><?= $attPct ?>%</div>
        <div style="font-size:.8rem;color:var(--color-text-muted)">נוכחות כוללת</div>
      </div>
      <div style="flex:1;min-width:150px">
        <div class="progress-bar" style="height:10px">
          <div class="progress-fill" style="width:<?= $attPct ?>%"></div>
        </div>
      </div>
      <div style="text-align:center">
        <div style="font-size:1.3rem;font-weight:700;color:var(--color-success)"><?= $presentCount ?></div>
        <div style="font-size:.8rem;color:var(--color-text-muted)">נוכח</div>
      </div>
      <div style="text-align:center">
        <div style="font-size:1.3rem;font-weight:700;color:var(--color-danger)"><?= $totalCount - $presentCount ?></div>
        <div style="font-size:.8rem;color:var(--color-text-muted)">נעדר</div>
      </div>
      <div style="text-align:center">
        <div style="font-size:1.3rem;font-weight:700"><?= $totalCount ?></div>
        <div style="font-size:.8rem;color:var(--color-text-muted)">סה"כ מפגשים</div>
      </div>
    </div>
  </div>

  <div class="card">
    <?php if ($attendance): ?>
    <div class="table-wrapper">
      <table class="data-table">
        <thead>
          <tr><th>תאריך</th><th>סוג</th><th>קבוצה</th><th>נוכחות</th><th>הערות</th></tr>
        </thead>
        <tbody>
          <?php foreach ($attendance as $row): ?>
          <tr>
            <td><?= formatDate($row['activity_date']) ?></td>
            <td><span class="badge badge-primary"><?= h($row['type_name']) ?></span></td>
            <td><?= h($row['group_name']) ?></td>
            <td>
              <?php if ($row['participation_status'] === 'present'): ?>
              <span class="badge badge-success">✓ נוכח</span>
              <?php else: ?>
              <span class="badge badge-danger">✗ נעדר</span>
              <?php endif; ?>
            </td>
            <td style="font-size:.82rem;color:var(--color-text-muted)"><?= h($row['act_notes'] ?? '—') ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <div class="empty-state"><div class="empty-icon">📅</div><p>אין נוכחות רשומה</p></div>
    <?php endif; ?>
  </div>
</div>

<!-- טאב: מידע נוסף -->
<?php if ($metaFields): ?>
<div class="tab-panel" id="tab-meta" data-tab-group="student">
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <h3 style="font-size:1rem">שדות מותאמים</h3>
      <?php if (!isInstructor()): ?>
      <a href="<?= APP_URL ?>/pages/student_edit.php?id=<?= $id ?>#meta" class="btn btn-secondary btn-sm">✏️ עריכה</a>
      <?php endif; ?>
    </div>
    <table style="width:100%;font-size:.9rem">
      <?php foreach ($metaFields as $f): ?>
      <?php
        $val = $metaValues[$f['id']] ?? null;
        $display = '—';
        if ($val) {
            switch ($f['field_type']) {
                case 'text':    $display = $val['value_text']    ?? '—'; break;
                case 'number':  $display = $val['value_number']  ?? '—'; break;
                case 'date':    $display = formatDate($val['value_date']); break;
                case 'boolean': $display = $val['value_boolean'] ? 'כן' : 'לא'; break;
                case 'select':
                    $j = json_decode($val['value_json'] ?? 'null');
                    $display = is_string($j) ? $j : ($val['value_text'] ?? '—');
                    break;
            }
        }
      ?>
      <tr>
        <td style="color:var(--color-text-muted);padding:8px 0;width:40%"><?= h($f['field_label']) ?></td>
        <td style="font-weight:500"><?= h($display) ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
