<?php
// pages/metadata.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
requireRole([ROLE_ADMIN]);
$db = getDB();

$programId = (int)($_GET['program_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) { flashMessage('בקשה לא תקינה', 'danger'); redirect(APP_URL . '/pages/metadata.php' . ($programId ? '?program_id=' . $programId : '')); }

    $action = $_POST['action'] ?? '';

    if ($action === 'add_field') {
        $key = preg_replace('/[^a-z0-9_]/', '_', strtolower(sanitize($_POST['field_key'])));
        $optionsJson = null;
        if ($_POST['field_type'] === 'select' && !empty($_POST['options'])) {
            $opts = array_filter(array_map('trim', explode("\n", $_POST['options'])));
            $optionsJson = json_encode(array_values($opts));
        }
        try {
            $db->prepare("
                INSERT INTO metadata_fields (program_id, field_key, field_label, field_type, is_required, options_json, sort_order)
                VALUES (?,?,?,?,?,?,?)
            ")->execute([
                (int)$_POST['program_id'],
                $key,
                sanitize($_POST['field_label']),
                sanitize($_POST['field_type']),
                isset($_POST['is_required']) ? 1 : 0,
                $optionsJson,
                (int)($_POST['sort_order'] ?? 99),
            ]);
            flashMessage('השדה נוסף', 'success');
        } catch (PDOException $e) {
            flashMessage('מפתח שדה זה כבר קיים בתוכנית זו', 'danger');
        }
        redirect(APP_URL . '/pages/metadata.php?program_id=' . (int)$_POST['program_id']);
    }

    if ($action === 'edit_field') {
        $optionsJson = null;
        if ($_POST['field_type'] === 'select' && !empty($_POST['options'])) {
            $opts = array_filter(array_map('trim', explode("\n", $_POST['options'])));
            $optionsJson = json_encode(array_values($opts));
        }
        $db->prepare("UPDATE metadata_fields SET field_label=?, field_type=?, is_required=?, options_json=?, sort_order=? WHERE id=?")
           ->execute([
               sanitize($_POST['field_label']),
               sanitize($_POST['field_type']),
               isset($_POST['is_required']) ? 1 : 0,
               $optionsJson,
               (int)$_POST['sort_order'],
               (int)$_POST['field_id'],
           ]);
        flashMessage('השדה עודכן', 'success');
        redirect(APP_URL . '/pages/metadata.php?program_id=' . $programId);
    }

    if ($action === 'toggle_field') {
        $cur = $db->prepare("SELECT is_active FROM metadata_fields WHERE id=?");
        $cur->execute([(int)$_POST['field_id']]);
        $cur = (int)$cur->fetchColumn();
        $db->prepare("UPDATE metadata_fields SET is_active=? WHERE id=?")->execute([1-$cur, (int)$_POST['field_id']]);
        flashMessage('סטטוס עודכן', 'success');
        redirect(APP_URL . '/pages/metadata.php?program_id=' . $programId);
    }
}

$programs = $db->query("SELECT * FROM programs WHERE status='active' ORDER BY name")->fetchAll();

$fields = [];
if ($programId) {
    $q = $db->prepare("SELECT * FROM metadata_fields WHERE program_id=? ORDER BY sort_order, field_label");
    $q->execute([$programId]);
    $fields = $q->fetchAll();
}

$fieldTypes = [
    'text'    => 'טקסט',
    'number'  => 'מספר',
    'date'    => 'תאריך',
    'boolean' => 'כן/לא',
    'select'  => 'רשימת בחירה',
];

$pageTitle  = 'שדות מותאמים';
$activePage = 'metadata';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px">
  <h2 style="font-size:1.5rem">שדות מותאמים</h2>
  <?php if ($programId): ?>
  <button class="btn btn-primary" data-modal-open="modal-add-field">➕ שדה חדש</button>
  <?php endif; ?>
</div>

<!-- בחירת תוכנית -->
<div class="card" style="margin-bottom:20px">
  <form method="GET" style="display:flex;align-items:center;gap:12px">
    <label class="form-label" style="margin:0;white-space:nowrap">תוכנית:</label>
    <select name="program_id" class="form-control" style="max-width:240px" onchange="this.form.submit()">
      <option value="">בחר תוכנית...</option>
      <?php foreach ($programs as $p): ?>
      <option value="<?= $p['id'] ?>" <?= $programId==$p['id']?'selected':'' ?>><?= h($p['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<?php if ($programId): ?>
<!-- שדות -->
<div class="card">
  <?php if ($fields): ?>
  <div class="table-wrapper">
    <table class="data-table">
      <thead><tr><th>תווית</th><th>מפתח</th><th>סוג</th><th>חובה</th><th>אפשרויות</th><th>סדר</th><th>סטטוס</th><th>פעולות</th></tr></thead>
      <tbody>
        <?php foreach ($fields as $f): ?>
        <?php $opts = json_decode($f['options_json'] ?? '[]', true); ?>
        <tr style="<?= !$f['is_active'] ? 'opacity:.55' : '' ?>">
          <td style="font-weight:500"><?= h($f['field_label']) ?></td>
          <td style="font-family:monospace;font-size:.82rem;color:var(--color-text-muted)"><?= h($f['field_key']) ?></td>
          <td><span class="badge badge-info"><?= h($fieldTypes[$f['field_type']] ?? $f['field_type']) ?></span></td>
          <td><?= $f['is_required'] ? '<span class="badge badge-danger">חובה</span>' : '—' ?></td>
          <td style="font-size:.82rem;max-width:180px">
            <?php if ($opts): ?>
            <?= h(implode(', ', array_slice($opts, 0, 4))) ?><?= count($opts) > 4 ? '...' : '' ?>
            <?php else: ?>—<?php endif; ?>
          </td>
          <td><?= $f['sort_order'] ?></td>
          <td><?= $f['is_active']
              ? '<span class="badge badge-success">פעיל</span>'
              : '<span class="badge badge-muted">מנוטרל</span>' ?></td>
          <td>
            <div style="display:flex;gap:6px">
              <button class="btn btn-ghost btn-sm"
                      onclick="openEdit(<?= htmlspecialchars(json_encode($f), ENT_QUOTES) ?>)">✏️</button>
              <form method="POST" style="display:inline">
                <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                <input type="hidden" name="action" value="toggle_field">
                <input type="hidden" name="field_id" value="<?= $f['id'] ?>">
                <button type="submit" class="btn btn-ghost btn-sm"><?= $f['is_active']?'⏸️':'▶️' ?></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php else: ?>
  <div class="empty-state"><div class="empty-icon">🔖</div><h3>אין שדות מותאמים</h3><p>הוסף שדה ראשון לתוכנית</p></div>
  <?php endif; ?>
</div>
<?php elseif (!empty($programs)): ?>
<div class="card"><div class="empty-state"><div class="empty-icon">🗂️</div><h3>בחר תוכנית מהרשימה למעלה</h3></div></div>
<?php endif; ?>

<!-- מודל הוספה -->
<div class="modal-overlay" id="modal-add-field" style="display:none">
  <div class="modal">
    <div class="modal-header"><h3 class="modal-title">שדה חדש</h3><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="add_field">
        <input type="hidden" name="program_id" value="<?= $programId ?>">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">תווית (כתובת) <span class="required">*</span></label>
            <input type="text" name="field_label" class="form-control" required placeholder="לדוגמה: בית ספר">
          </div>
          <div class="form-group">
            <label class="form-label">מפתח (field_key) <span class="required">*</span></label>
            <input type="text" name="field_key" class="form-control" required placeholder="school_name" pattern="[a-z0-9_]+">
            <span class="form-hint">אותיות לטיניות קטנות, ספרות וקו תחתון בלבד</span>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">סוג שדה <span class="required">*</span></label>
            <select name="field_type" class="form-control" required id="add_field_type" onchange="toggleOptions(this,'add_options_row')">
              <?php foreach ($fieldTypes as $k => $v): ?>
              <option value="<?= $k ?>"><?= h($v) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">סדר תצוגה</label>
            <input type="number" name="sort_order" class="form-control" value="99" min="1">
          </div>
        </div>
        <div id="add_options_row" style="display:none" class="form-group">
          <label class="form-label">אפשרויות (שורה אחת לכל אפשרות)</label>
          <textarea name="options" class="form-control" rows="4" placeholder="אפשרות 1&#10;אפשרות 2&#10;אפשרות 3"></textarea>
        </div>
        <div class="form-group">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
            <input type="checkbox" name="is_required"> שדה חובה
          </label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">הוסף שדה</button>
      </div>
    </form>
  </div>
</div>

<!-- מודל עריכה -->
<div class="modal-overlay" id="modal-edit-field" style="display:none">
  <div class="modal">
    <div class="modal-header"><h3 class="modal-title">עריכת שדה</h3><button class="modal-close" data-modal-close>✕</button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="edit_field">
        <input type="hidden" name="field_id" id="ef_id">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">תווית <span class="required">*</span></label>
            <input type="text" name="field_label" id="ef_label" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">סוג</label>
            <select name="field_type" id="ef_type" class="form-control" onchange="toggleOptions(this,'edit_options_row')">
              <?php foreach ($fieldTypes as $k => $v): ?>
              <option value="<?= $k ?>"><?= h($v) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div id="edit_options_row" class="form-group" style="display:none">
          <label class="form-label">אפשרויות</label>
          <textarea name="options" id="ef_options" class="form-control" rows="4"></textarea>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">סדר</label>
            <input type="number" name="sort_order" id="ef_sort" class="form-control" min="1">
          </div>
          <div class="form-group" style="display:flex;align-items:flex-end">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin-bottom:8px">
              <input type="checkbox" name="is_required" id="ef_required"> שדה חובה
            </label>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-modal-close>ביטול</button>
        <button type="submit" class="btn btn-primary">עדכן</button>
      </div>
    </form>
  </div>
</div>

<script>
function toggleOptions(sel, rowId) {
  document.getElementById(rowId).style.display = sel.value === 'select' ? '' : 'none';
}

function openEdit(f) {
  document.getElementById('ef_id').value      = f.id;
  document.getElementById('ef_label').value   = f.field_label;
  document.getElementById('ef_type').value    = f.field_type;
  document.getElementById('ef_sort').value    = f.sort_order;
  document.getElementById('ef_required').checked = !!f.is_required;

  const opts = JSON.parse(f.options_json || '[]');
  document.getElementById('ef_options').value = opts.join('\n');
  document.getElementById('edit_options_row').style.display = f.field_type === 'select' ? '' : 'none';

  document.getElementById('modal-edit-field').style.display = 'flex';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
