<?php
// pages/audit.php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
requireRole([ROLE_ADMIN]);
$db = getDB();

$userId   = (int)($_GET['user_id']  ?? 0);
$action   = sanitize($_GET['action_filter'] ?? '');
$dateFrom = sanitize($_GET['date_from'] ?? date('Y-m-d', strtotime('-7 days')));
$dateTo   = sanitize($_GET['date_to']   ?? date('Y-m-d'));

$where  = ['al.created_at >= ? AND al.created_at < DATE_ADD(?, INTERVAL 1 DAY)'];
$params = [$dateFrom, $dateTo];
if ($userId) { $where[] = 'al.user_id=?'; $params[] = $userId; }
if ($action) { $where[] = 'al.action LIKE ?'; $params[] = "%$action%"; }
$whereSQL = 'WHERE ' . implode(' AND ', $where);

$logs = $db->prepare("
    SELECT al.*, u.full_name, u.role
    FROM audit_logs al
    JOIN users u ON u.id = al.user_id
    $whereSQL
    ORDER BY al.created_at DESC
    LIMIT 200
");
$logs->execute($params);
$logs = $logs->fetchAll();

$allUsers = $db->query("SELECT id, full_name FROM users WHERE deleted_at IS NULL ORDER BY full_name")->fetchAll();

$actionLabels = [
    'login'   => '🔑 התחברות',
    'logout'  => '🚪 יציאה',
    'create'  => '➕ יצירה',
    'update'  => '✏️ עדכון',
    'delete'  => '🗑️ מחיקה',
    'export'  => '📥 ייצוא',
];

$pageTitle  = 'יומן פעולות';
$activePage = 'audit';
require_once __DIR__ . '/../includes/header.php';
?>

<div style="margin-bottom:20px">
  <h2 style="font-size:1.5rem">📋 יומן פעולות</h2>
  <p style="color:var(--color-text-muted);font-size:.88rem">200 הפעולות האחרונות</p>
</div>

<!-- פילטרים -->
<form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px">
  <select name="user_id" class="form-control" style="max-width:200px">
    <option value="">כל המשתמשים</option>
    <?php foreach ($allUsers as $u): ?>
    <option value="<?= $u['id'] ?>" <?= $userId==$u['id']?'selected':'' ?>><?= h($u['full_name']) ?></option>
    <?php endforeach; ?>
  </select>
  <input type="text" name="action_filter" class="form-control" style="max-width:160px"
         value="<?= h($action) ?>" placeholder="פעולה...">
  <input type="date" name="date_from" class="form-control" style="max-width:145px" value="<?= h($dateFrom) ?>">
  <span style="align-self:center;color:var(--color-text-muted)">עד</span>
  <input type="date" name="date_to"   class="form-control" style="max-width:145px" value="<?= h($dateTo) ?>">
  <button type="submit" class="btn btn-primary">סנן</button>
</form>

<div class="card">
  <div class="table-wrapper">
    <?php if ($logs): ?>
    <table class="data-table">
      <thead>
        <tr><th>זמן</th><th>משתמש</th><th>פעולה</th><th>ישות</th><th>IP</th><th>פרטים</th></tr>
      </thead>
      <tbody>
        <?php foreach ($logs as $log): ?>
        <tr>
          <td style="white-space:nowrap;font-size:.82rem">
            <?= formatDate($log['created_at'], 'd/m/Y H:i') ?>
          </td>
          <td>
            <div style="font-weight:500;font-size:.88rem"><?= h($log['full_name']) ?></div>
            <div style="font-size:.75rem;color:var(--color-text-muted)"><?= h(roleLabel($log['role'])) ?></div>
          </td>
          <td>
            <span class="badge badge-info">
              <?= h($actionLabels[$log['action']] ?? $log['action']) ?>
            </span>
          </td>
          <td style="font-size:.82rem">
            <?= h($log['entity_type']) ?>
            <?= $log['entity_id'] ? ' #' . $log['entity_id'] : '' ?>
          </td>
          <td style="font-size:.78rem;color:var(--color-text-muted)"><?= h($log['ip_address'] ?? '—') ?></td>
          <td style="font-size:.78rem;color:var(--color-text-muted);max-width:200px">
            <?php if ($log['details_json']): ?>
            <details>
              <summary style="cursor:pointer">הצג</summary>
              <pre style="font-size:.72rem;white-space:pre-wrap;word-break:break-all;margin-top:4px"><?= h(json_encode(json_decode($log['details_json']), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) ?></pre>
            </details>
            <?php else: ?>—<?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><div class="empty-icon">📋</div><h3>אין רשומות</h3></div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
