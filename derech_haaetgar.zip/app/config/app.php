<?php
// config/app.php

define('APP_NAME',    'דרך האתגר');
define('APP_VERSION', '2.0.0');
define('APP_URL',     'http://localhost/app');   // שנה לפי הסביבה שלך

// תפקידים
define('ROLE_ADMIN',       'admin');
define('ROLE_COORDINATOR', 'coordinator');
define('ROLE_INSTRUCTOR',  'instructor');

define('ROLE_LABELS', [
    'admin'       => 'מנהל מערכת',
    'coordinator' => 'רכז',
    'instructor'  => 'מדריך',
]);

// עמוד ברירת מחדל לפי תפקיד
define('ROLE_DEFAULT_PAGE', [
    'admin'       => APP_URL . '/dashboard.php',
    'coordinator' => APP_URL . '/dashboard.php',
    'instructor'  => APP_URL . '/pages/my_group.php',
]);

// Timeout סשן – 8 שעות
define('SESSION_TIMEOUT', 3600 * 8);
