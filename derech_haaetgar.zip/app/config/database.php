<?php
// config/database.php

define('DB_HOST', 'localhost');
define('DB_NAME', 'student_mvp');
define('DB_USER', 'root');   // שנה לפי הסביבה שלך
define('DB_PASS', '');        // שנה לפי הסביבה שלך
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die('<div style="font-family:sans-serif;text-align:center;padding:60px;direction:rtl">
                 <h2>שגיאת חיבור למסד הנתונים</h2>
                 <p>' . htmlspecialchars($e->getMessage()) . '</p></div>');
        }
    }
    return $pdo;
}
