<?php
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/includes/auth.php';
startSession();
session_destroy();
header('Location: ' . APP_URL . '/index.php');
exit;
