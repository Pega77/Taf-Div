<?php
// index.php – התחברות

require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

startSession();

// כבר מחובר
if (!empty($_SESSION['user_id'])) {
    redirect(ROLE_DEFAULT_PAGE[$_SESSION['user_role']] ?? APP_URL . '/dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1 AND deleted_at IS NULL LIMIT 1");
        $stmt->execute([$username]);
        $u = $stmt->fetch();

        if ($u && password_verify($password, $u['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user_id']    = $u['id'];
            $_SESSION['user_name']  = $u['full_name'];
            $_SESSION['user_role']  = $u['role'];
            $_SESSION['last_activity'] = time();

            // מדריך – שמור group_id
            if ($u['role'] === ROLE_INSTRUCTOR) {
                $g = $db->prepare("SELECT id, program_id FROM groups WHERE instructor_user_id = ? AND status = 'active' LIMIT 1");
                $g->execute([$u['id']]);
                $g = $g->fetch();
                $_SESSION['group_id']   = $g['id'] ?? null;
                $_SESSION['program_id'] = $g['program_id'] ?? null;
            }

            // לוג
            $db->prepare("INSERT INTO audit_logs (user_id, action, entity_type, entity_id, ip_address) VALUES (?,?,?,?,?)")
               ->execute([$u['id'], 'login', 'user', $u['id'], $_SERVER['REMOTE_ADDR'] ?? '']);

            $redirect = $_GET['redirect'] ?? ROLE_DEFAULT_PAGE[$u['role']] ?? APP_URL . '/dashboard.php';
            redirect($redirect);
        } else {
            $error = 'שם משתמש או סיסמה שגויים';
        }
    } else {
        $error = 'נא למלא את כל השדות';
    }
}

$expired = !empty($_GET['expired']);
?>
<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>התחברות – <?= h(APP_NAME) ?></title>
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/variables.css">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/base.css">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/layout.css">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/components.css">
</head>
<body>
<div class="login-page">
  <div class="login-box">
    <div class="login-logo">🏔️</div>
    <h1 class="login-title"><?= h(APP_NAME) ?></h1>
    <p class="login-sub">מערכת מעקב ושירות</p>

    <?php if ($expired): ?>
    <div class="alert alert-warning">פג תוקף הסשן – אנא התחבר מחדש</div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label class="form-label">שם משתמש</label>
        <input type="text" name="username" class="form-control"
               value="<?= h($_POST['username'] ?? '') ?>"
               placeholder="admin" autofocus autocomplete="username">
      </div>
      <div class="form-group">
        <label class="form-label">סיסמה</label>
        <input type="password" name="password" class="form-control"
               placeholder="••••••••" autocomplete="current-password">
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:12px">
        התחברות
      </button>
    </form>

    <p style="text-align:center;margin-top:20px;font-size:.78rem;color:var(--color-text-muted)">
      גרסה <?= APP_VERSION ?> · כל הזכויות שמורות
    </p>
  </div>
</div>
</body>
</html>
